
package com.example.intouch

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetPlugin

class InTouchWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    companion object {
        fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val widgetData = HomeWidgetPlugin.getData(context)
            val isBirthday = widgetData.getBoolean("is_birthday", false)

            val views = if (isBirthday) {
                val name = widgetData.getString("birthday_name", "User")
                val age = widgetData.getString("birthday_age", "18")
                RemoteViews(context.packageName, R.layout.birthday_widget).apply {
                    setTextViewText(R.id.birthday_message, "🎉 Happy $age${getAgeSuffix(age.toInt())} Birthday, $name! 🎉")
                }
            } else {
                RemoteViews(context.packageName, R.layout.snapshare_widget)
            }
            
            // Set up click intents (for non-birthday widget)
            if (!isBirthday) {
                val cameraIntent = Intent(context, MainActivity::class.java).apply {
                    putExtra("action", "camera")
                }
                val cameraPendingIntent = PendingIntent.getActivity(
                    context, 0, cameraIntent, 
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.camera_button, cameraPendingIntent)
                
                val doodleIntent = Intent(context, MainActivity::class.java).apply {
                    putExtra("action", "doodle")
                }
                val doodlePendingIntent = PendingIntent.getActivity(
                    context, 1, doodleIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.doodle_button, doodlePendingIntent)
                
                val voiceIntent = Intent(context, MainActivity::class.java).apply {
                    putExtra("action", "voice")
                }
                val voicePendingIntent = PendingIntent.getActivity(
                    context, 2, voiceIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.voice_button, voicePendingIntent)
            }
            
            appWidgetManager.updateAppWidget(appWidgetId, views)
        }

        private fun getAgeSuffix(age: Int): String {
            return when {
                age % 10 == 1 && age % 100 != 11 -> "st"
                age % 10 == 2 && age % 100 != 12 -> "nd"
                age % 10 == 3 && age % 100 != 13 -> "rd"
                else -> "th"
            }
        }
    }
}
