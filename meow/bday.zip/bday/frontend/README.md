# InTouch Flutter App

A modern Flutter application for sharing ephemeral content with real-time synchronization, built with clean architecture principles.

## 🚀 Features

### Core Features
- **Anonymous Authentication** - Sign in anonymously with Firebase
- **Real-time Communication** - WebSocket-based real-time updates
- **Ephemeral Content** - Content automatically expires (1h to 24h)
- **Multiple Content Types**:
  - 📸 **Camera Snaps** - Take and share photos
  - 🎨 **Doodles** - Create and share drawings
  - 🎤 **Voice Notes** - Record and share audio messages
  - 📝 **Text Notes** - Write and share text messages

### Advanced Features
- **Home Screen Widget** - Quick access from Android home screen
- **Group Management** - Create and join groups for sharing
- **Real-time Notifications** - Firebase Cloud Messaging
- **Offline Support** - Local storage with sync
- **Modern UI** - Material Design 3 with smooth animations

## 🏗️ Architecture

The app follows **Clean Architecture** principles with clear separation of concerns:

```
lib/
├── features/           # Feature modules
│   ├── auth/          # Authentication
│   ├── home/          # Home screen & groups
│   ├── capture/       # Content creation
│   ├── widget/        # Home screen widget
│   └── realtime/      # Real-time features
├── services/          # External services
│   ├── firebase_service.dart
│   ├── websocket_service.dart
│   └── api_service.dart
├── shared/            # Shared components
│   ├── widgets/       # Reusable widgets
│   ├── constants/     # App constants
│   └── utils/         # Utility functions
└── main.dart         # App entry point
```

### Feature Structure
Each feature follows the same structure:
```
feature/
├── data/              # Data layer
│   ├── datasources/   # External data sources
│   └── repositories/  # Repository implementations
├── domain/            # Domain layer
│   ├── entities/      # Business objects
│   └── repositories/  # Repository interfaces
└── presentation/      # Presentation layer
    ├── pages/         # UI screens
    ├── widgets/       # Feature-specific widgets
    └── providers/     # State management
```

## 🛠️ Tech Stack

### Core
- **Flutter** - Cross-platform UI framework
- **Dart** - Programming language
- **Riverpod** - State management
- **GoRouter** - Navigation

### Backend Integration
- **FastAPI** - REST API backend
- **WebSockets** - Real-time communication
- **Redis** - Ephemeral storage

### Firebase Services
- **Firebase Auth** - Anonymous authentication
- **Firebase Messaging** - Push notifications
- **Firebase Storage** - File storage (optional)

### Media & UI
- **Camera** - Photo capture
- **Image Painter** - Drawing/doodling
- **Flutter Sound** - Audio recording
- **Lottie** - Animations
- **Home Widget** - Android home screen widget

### Development
- **Mockito** - Unit testing
- **Integration Test** - E2E testing
- **Golden Toolkit** - Widget testing
- **Patrol** - Advanced testing

## 📱 Screens

### 1. Onboarding
- Welcome screens with app introduction
- Anonymous sign-in with Firebase
- Feature highlights

### 2. Home Screen
- Group overview with recent items
- Quick access to create content
- Real-time updates
- User profile and settings

### 3. Capture Screen
- Tabbed interface for different content types
- Camera with photo capture
- Drawing canvas with tools
- Voice recorder with visualization
- Rich text editor with formatting

### 4. Widget Settings
- Configure home screen widget
- Set default group and expiry
- Widget preview

## 🔧 Setup & Installation

### Prerequisites
- Flutter SDK (3.0+)
- Dart SDK (3.0+)
- Android Studio / VS Code
- Firebase project setup

### 1. Clone Repository
```bash
git clone <repository-url>
cd flutter_fastapi_app/frontend
```

### 2. Install Dependencies
```bash
flutter pub get
```

### 3. Firebase Setup
1. Create a Firebase project
2. Add Android app to Firebase project
3. Download `google-services.json` to `android/app/`
4. Enable Anonymous Authentication
5. Enable Cloud Messaging

### 4. Configure Backend
Update API endpoints in `lib/shared/constants/app_constants.dart`:
```dart
static const String baseUrl = 'http://your-backend-url/api/v1';
static const String wsUrl = 'ws://your-backend-url/api/v1/ws';
```

### 5. Run the App
```bash
flutter run
```

## 🧪 Testing

### Unit Tests
```bash
flutter test
```

### Integration Tests
```bash
flutter test integration_test/
```

### Widget Tests
```bash
flutter test test/widget_test.dart
```

## 📦 Dependencies

### Core Dependencies
- `flutter_riverpod` - State management
- `go_router` - Navigation
- `camera` - Camera functionality
- `image_painter` - Drawing canvas
- `flutter_sound` - Audio recording
- `home_widget` - Android widgets
- `lottie` - Animations

### Firebase
- `firebase_core` - Firebase initialization
- `firebase_auth` - Authentication
- `firebase_messaging` - Push notifications
- `firebase_storage` - File storage

### Networking
- `web_socket_channel` - WebSocket communication
- `http` - HTTP requests
- `dio` - Advanced HTTP client

### Storage
- `shared_preferences` - Local preferences
- `hive` - Local database

### Development
- `mockito` - Mocking for tests
- `integration_test` - E2E testing
- `golden_toolkit` - Widget testing
- `patrol` - Advanced testing

## 🎨 UI/UX Features

### Design System
- **Material Design 3** - Modern design language
- **Consistent Theming** - Custom color schemes
- **Responsive Layout** - Adaptive to different screen sizes
- **Smooth Animations** - Lottie animations and transitions

### Accessibility
- **Screen Reader Support** - Semantic labels
- **High Contrast** - Accessible color schemes
- **Large Text Support** - Scalable fonts
- **Touch Targets** - Minimum 44dp touch targets

## 🔒 Security

### Data Protection
- **Anonymous Authentication** - No personal data required
- **Ephemeral Storage** - Content automatically expires
- **Secure Communication** - HTTPS/WSS for all API calls
- **Token-based Auth** - Firebase ID tokens

### Privacy
- **No Data Persistence** - Content is not stored permanently
- **Local Processing** - Media processing on device
- **Minimal Permissions** - Only required permissions

## 🚀 Performance

### Optimization
- **Lazy Loading** - Load content on demand
- **Image Caching** - Efficient image handling
- **Background Processing** - Non-blocking operations
- **Memory Management** - Proper disposal of resources

### Monitoring
- **Performance Metrics** - Built-in Flutter performance tools
- **Error Tracking** - Comprehensive error handling
- **Analytics** - User interaction tracking

## 📱 Platform Support

### Android
- **Minimum SDK** - API 21 (Android 5.0)
- **Target SDK** - API 34 (Android 14)
- **Home Widgets** - Native Android widgets
- **Permissions** - Camera, microphone, storage

### iOS (Future)
- **iOS 12+** - Planned support
- **Native Features** - Camera, microphone, widgets

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new features
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the documentation
- Review the code examples

## 🔮 Roadmap

### Phase 1 (Current)
- ✅ Core features implementation
- ✅ Basic UI/UX
- ✅ Firebase integration
- ✅ WebSocket communication

### Phase 2 (Next)
- 🔄 Advanced animations
- 🔄 Enhanced widget features
- 🔄 Offline mode improvements
- 🔄 Performance optimizations

### Phase 3 (Future)
- 📋 iOS support
- 📋 Advanced group features
- 📋 Content moderation
- 📋 Analytics dashboard

---

**Built with ❤️ using Flutter and FastAPI**