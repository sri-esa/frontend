# InTouch Backend API

A FastAPI-based backend for real-time ephemeral content sharing with Redis storage and Firebase integration.

## 🚀 Features

### Core Features
- **Ephemeral Content Sharing**: Snaps, doodles, text notes, and voice notes with TTL
- **Real-time Communication**: WebSocket support for instant updates
- **Redis Storage**: High-performance ephemeral storage with auto-deletion
- **Firebase Integration**: User authentication and push notifications
- **File Upload**: Support for images and audio files with processing

### Content Types
- **Snaps**: Photo sharing with captions and location
- **Doodles**: Annotated images with drawing data
- **Text Notes**: Rich text with custom styling
- **Voice Notes**: Audio recordings with transcription

### Expiry Options
- 1 hour
- 3 hours
- 6 hours
- 12 hours
- 24 hours (default)

## 🏗️ Architecture

```
backend/
├── api/                    # API endpoints
│   ├── items.py           # Content management endpoints
│   ├── websocket.py       # WebSocket endpoints
│   └── health.py          # Health check endpoints
├── services/              # Business logic services
│   ├── redis_service.py   # Redis operations
│   ├── firebase_service.py # Firebase integration
│   └── websocket_service.py # WebSocket management
├── models/                # Data models
│   └── schemas.py         # Pydantic schemas
├── utils/                 # Utility functions
│   ├── ttl_converter.py   # TTL calculations
│   └── file_handler.py    # File operations
├── main.py               # FastAPI application
└── requirements.txt      # Dependencies
```

## 📦 Dependencies

### Core Dependencies
- **FastAPI**: Modern web framework
- **Uvicorn**: ASGI server
- **Redis**: Ephemeral storage
- **Firebase Admin**: Authentication and notifications
- **WebSockets**: Real-time communication

### File Processing
- **Pillow**: Image processing
- **Pydub**: Audio processing
- **aiofiles**: Async file operations

## 🔧 Setup & Installation

### Prerequisites
- Python 3.11+
- Redis server
- Firebase project
- Virtual environment (recommended)

### Installation
```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Copy environment file
cp env.example .env

# Edit .env with your configuration
```

### Environment Configuration
```env
# Redis
REDIS_URL=redis://localhost:6379/0

# Firebase
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_SERVICE_ACCOUNT_PATH=path/to/service-account-key.json

# Server
HOST=0.0.0.0
PORT=8000
```

## 🚀 Running the Application

### Development
```bash
python main.py
```

### Production
```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

### Docker
```bash
docker build -t intouch-backend .
docker run -p 8000:8000 intouch-backend
```

## 📡 API Endpoints

### Content Management

#### Upload Endpoints
- `POST /api/v1/upload/snap` - Upload photo snap
- `POST /api/v1/upload/doodle` - Upload doodled image
- `POST /api/v1/upload/text-note` - Upload text note
- `POST /api/v1/upload/voice-note` - Upload voice note

#### Item Management
- `GET /api/v1/items` - Get all active items
- `GET /api/v1/items/{item_id}` - Get specific item
- `DELETE /api/v1/items/{item_id}` - Delete item
- `POST /api/v1/cleanup` - Cleanup expired items
- `GET /api/v1/stats` - Get user statistics

### WebSocket
- `WS /api/v1/ws` - WebSocket connection
- `GET /api/v1/ws/status` - WebSocket status

### Health
- `GET /api/v1/health` - Overall health check
- `GET /api/v1/health/redis` - Redis health
- `GET /api/v1/health/firebase` - Firebase health

## 🔐 Authentication

### Firebase Token
All API endpoints require Firebase authentication token:
```bash
# Header
Authorization: Bearer <firebase_id_token>

# WebSocket
ws://localhost:8000/api/v1/ws?token=<firebase_id_token>
```

### Token Verification
- Tokens are verified using Firebase Admin SDK
- User ID is extracted from verified token
- Invalid tokens return 401 Unauthorized

## 📁 File Upload

### Supported Formats
- **Images**: JPEG, PNG, GIF, WebP
- **Audio**: MP3, WAV, OGG, AAC

### File Processing
- Images are automatically optimized
- Files are stored in organized directories
- Unique file IDs prevent conflicts

### Upload Limits
- Maximum file size: 10MB
- Automatic image resizing
- Audio duration validation

## 🔄 Real-time Features

### WebSocket Events
- `new_item` - New content received
- `item_deleted` - Content deleted
- `notification` - Push notification
- `ping/pong` - Connection health

### Broadcasting
- New items are broadcast to recipients
- Deletions are broadcast to recipients
- Notifications are sent via FCM

## 🗄️ Data Storage

### Redis Structure
```
item:{item_id}           # Item data
user:{user_id}:items     # User's sent items
recipient:{user_id}:items # User's received items
notification:{user_id}:* # User notifications
```

### TTL Management
- Items automatically expire based on chosen TTL
- Expired items are cleaned up automatically
- Manual cleanup endpoint available

## 🧪 Testing

### Unit Tests
```bash
pytest tests/
```

### Integration Tests
```bash
pytest tests/integration/
```

### Load Testing
```bash
# Install locust
pip install locust

# Run load tests
locust -f tests/load_test.py
```

## 📊 Monitoring

### Health Checks
- Redis connection status
- Firebase service status
- Overall application health

### Logging
- Structured logging with loguru
- Request/response logging
- Error tracking and reporting

### Metrics
- Item creation/deletion rates
- WebSocket connection counts
- File upload statistics

## 🚀 Deployment

### Production Considerations
1. **Redis**: Use Redis Cluster for high availability
2. **Firebase**: Configure production service account
3. **File Storage**: Use cloud storage (S3, GCS)
4. **Load Balancing**: Use nginx or cloud load balancer
5. **Monitoring**: Set up APM and logging

### Docker Deployment
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Environment Variables
- `REDIS_URL`: Redis connection string
- `FIREBASE_PROJECT_ID`: Firebase project ID
- `FIREBASE_SERVICE_ACCOUNT_PATH`: Service account key path
- `HOST`: Server host (default: 0.0.0.0)
- `PORT`: Server port (default: 8000)

## 📚 Documentation

### API Documentation
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **OpenAPI Schema**: http://localhost:8000/openapi.json

### Code Documentation
- Inline docstrings for all functions
- Type hints for better IDE support
- Comprehensive error handling

## 🤝 Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

### Common Issues
1. **Redis Connection**: Ensure Redis is running on correct port
2. **Firebase Auth**: Verify service account key is valid
3. **File Upload**: Check file size and type restrictions
4. **WebSocket**: Ensure proper authentication token

### Debugging
- Enable debug logging: `LOG_LEVEL=DEBUG`
- Check Redis connection: `redis-cli ping`
- Verify Firebase: Check service account permissions
