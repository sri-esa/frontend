"""
Test script for WebSocket functionality
Run with: python test_websocket.py
"""
import asyncio
import json
import logging
from datetime import datetime, timedelta
from services.storage import StorageService, ItemType
from integrations.storage_websocket import StorageWebSocketIntegration

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def test_storage_websocket_integration():
    """Test the integration between StorageService and WebSocket broadcasting"""
    
    # Initialize storage service
    storage = StorageService("redis://localhost:6379/0")
    
    try:
        # Connect to Redis
        await storage.connect()
        print("✅ Connected to Redis")
        
        # Test data
        sender = "test_user_123"
        group_id = "test_group_456"
        
        print("\n🧪 Testing Storage-WebSocket Integration...")
        
        # Test 1: Save snap with broadcast
        print("\n1. Saving snap with broadcast...")
        snap_id = await StorageWebSocketIntegration.save_item_with_broadcast(
            sender=sender,
            group_id=group_id,
            item_type=ItemType.SNAP,
            content="https://example.com/test_snap.jpg",
            ttl_seconds=3600,  # 1 hour
            metadata={"caption": "Test snap!", "location": {"lat": 40.7128, "lng": -74.0060}}
        )
        print(f"   📸 Saved snap with broadcast: {snap_id}")
        
        # Test 2: Save text note with broadcast
        print("\n2. Saving text note with broadcast...")
        text_id = await StorageWebSocketIntegration.save_item_with_broadcast(
            sender=sender,
            group_id=group_id,
            item_type=ItemType.TEXT,
            content="This is a test text note with broadcast!",
            ttl_seconds=7200,  # 2 hours
            metadata={"font_size": 18, "color": "#FF0000"}
        )
        print(f"   📝 Saved text note with broadcast: {text_id}")
        
        # Test 3: Save voice note with broadcast
        print("\n3. Saving voice note with broadcast...")
        voice_id = await StorageWebSocketIntegration.save_item_with_broadcast(
            sender=sender,
            group_id=group_id,
            item_type=ItemType.VOICE,
            content="https://example.com/test_voice.mp3",
            ttl_seconds=1800,  # 30 minutes
            metadata={"duration": 45.5, "transcript": "This is a test voice note!"}
        )
        print(f"   🎤 Saved voice note with broadcast: {voice_id}")
        
        # Test 4: Get group items
        print("\n4. Getting group items...")
        group_items = await storage.get_items(group_id)
        print(f"   Found {len(group_items)} items in group {group_id}")
        
        # Test 5: Delete item with broadcast
        print("\n5. Deleting item with broadcast...")
        deleted = await StorageWebSocketIntegration.delete_item_with_broadcast(voice_id, sender)
        print(f"   Voice note deleted with broadcast: {deleted}")
        
        # Verify deletion
        remaining_items = await storage.get_items(group_id)
        print(f"   Remaining items after deletion: {len(remaining_items)}")
        
        # Test 6: Get group items with metadata
        print("\n6. Getting group items with metadata...")
        group_data = await StorageWebSocketIntegration.get_group_items_with_metadata(group_id)
        print(f"   Group data: {json.dumps(group_data, indent=2)}")
        
        # Test 7: Cleanup expired items with broadcast
        print("\n7. Cleaning up expired items with broadcast...")
        cleaned = await StorageWebSocketIntegration.cleanup_expired_items_with_broadcast()
        print(f"   Cleaned up {cleaned} expired items with broadcasts")
        
        print("\n✅ All integration tests completed successfully!")
        
    except Exception as e:
        print(f"❌ Integration test failed: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Disconnect
        await storage.disconnect()
        print("\n🔌 Disconnected from Redis")


async def test_convenience_functions():
    """Test the convenience functions for different item types"""
    
    from integrations.storage_websocket import (
        save_snap_with_broadcast,
        save_text_note_with_broadcast,
        save_voice_note_with_broadcast,
        save_doodle_with_broadcast
    )
    
    print("\n🧪 Testing Convenience Functions...")
    
    sender = "convenience_test_user"
    group_id = "convenience_test_group"
    
    try:
        # Test snap convenience function
        print("\n1. Testing snap convenience function...")
        snap_id = await save_snap_with_broadcast(
            sender=sender,
            group_id=group_id,
            image_url="https://example.com/convenience_snap.jpg",
            ttl_hours=1,
            caption="Convenience test snap!",
            metadata={"test": True}
        )
        print(f"   📸 Snap saved: {snap_id}")
        
        # Test text note convenience function
        print("\n2. Testing text note convenience function...")
        text_id = await save_text_note_with_broadcast(
            sender=sender,
            group_id=group_id,
            content="Convenience test text note!",
            ttl_hours=2,
            font_size=20,
            color="#00FF00",
            metadata={"test": True}
        )
        print(f"   📝 Text note saved: {text_id}")
        
        # Test voice note convenience function
        print("\n3. Testing voice note convenience function...")
        voice_id = await save_voice_note_with_broadcast(
            sender=sender,
            group_id=group_id,
            audio_url="https://example.com/convenience_voice.mp3",
            duration=30.0,
            ttl_hours=1,
            transcript="Convenience test voice note!",
            metadata={"test": True}
        )
        print(f"   🎤 Voice note saved: {voice_id}")
        
        # Test doodle convenience function
        print("\n4. Testing doodle convenience function...")
        doodle_id = await save_doodle_with_broadcast(
            sender=sender,
            group_id=group_id,
            doodle_data='{"strokes": [{"x": 100, "y": 100, "color": "#FF0000"}]}',
            original_image_url="https://example.com/original.jpg",
            ttl_hours=3,
            metadata={"test": True}
        )
        print(f"   🎨 Doodle saved: {doodle_id}")
        
        print("\n✅ All convenience function tests completed successfully!")
        
    except Exception as e:
        print(f"❌ Convenience function test failed: {e}")
        import traceback
        traceback.print_exc()


async def test_websocket_message_types():
    """Test different WebSocket message types"""
    
    print("\n🧪 Testing WebSocket Message Types...")
    
    # Simulate different message types
    message_types = [
        "new_item",
        "item_deleted", 
        "item_expired",
        "group_joined",
        "group_left",
        "user_joined",
        "user_left",
        "ping",
        "pong",
        "error",
        "notification"
    ]
    
    for msg_type in message_types:
        print(f"   📨 Message type: {msg_type}")
        
        # Create sample message
        sample_message = {
            "type": msg_type,
            "data": {
                "group_id": "test_group",
                "user_id": "test_user",
                "item_id": "test_item_123",
                "message": f"Test {msg_type} message",
                "timestamp": datetime.utcnow().isoformat()
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
        print(f"      Sample: {json.dumps(sample_message, indent=6)}")
    
    print("\n✅ WebSocket message type tests completed!")


async def test_group_management():
    """Test group management functionality"""
    
    print("\n🧪 Testing Group Management...")
    
    # Test group operations
    group_id = "management_test_group"
    user_id = "management_test_user"
    
    try:
        # Simulate joining a group
        print(f"\n1. User {user_id} joining group {group_id}")
        # In real implementation, this would be handled by WebSocket connection
        
        # Simulate getting group items
        print(f"\n2. Getting items for group {group_id}")
        # This would be handled by the WebSocket API
        
        # Simulate leaving a group
        print(f"\n3. User {user_id} leaving group {group_id}")
        # In real implementation, this would be handled by WebSocket disconnection
        
        print("\n✅ Group management tests completed!")
        
    except Exception as e:
        print(f"❌ Group management test failed: {e}")


async def main():
    """Run all WebSocket tests"""
    
    print("🚀 Starting WebSocket Tests...")
    print("=" * 50)
    
    # Test 1: Storage-WebSocket Integration
    await test_storage_websocket_integration()
    
    # Test 2: Convenience Functions
    await test_convenience_functions()
    
    # Test 3: WebSocket Message Types
    await test_websocket_message_types()
    
    # Test 4: Group Management
    await test_group_management()
    
    print("\n🎉 All WebSocket tests completed!")


if __name__ == "__main__":
    asyncio.run(main())
