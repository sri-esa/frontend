from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import uvicorn
import logging
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Import services
from services.redis_service import redis_service
from services.firebase_service import firebase_service
from services.websocket_service import websocket_manager
from services.storage import storage_service

# Import API routers
from api.items import router as items_router
from api.websocket import router as websocket_router
from api.ws import router as ws_router, start_background_tasks
from api.health import router as health_router
from api.birthdays import router as birthdays_router
from api.birthdays_ws import router as birthdays_ws_router
from api.fcm import router as fcm_router

# Import database
from database import init_db

# Import scheduler
from scheduler import init_scheduler, run_missed_jobs, scheduler

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    # Startup
    logger.info("Starting up...")
    
    try:
        # Initialize database
        await init_db()
        logger.info("Database initialized")

        # Connect to Redis
        await redis_service.connect()
        logger.info("Connected to Redis")
        
        # Connect to Storage Service
        await storage_service.connect()
        logger.info("Connected to Storage Service")
        
        # Initialize Firebase (already done in service)
        if firebase_service.app:
            logger.info("Firebase initialized")
        else:
            logger.warning("Firebase not initialized")
        
        # Start WebSocket background tasks
        await start_background_tasks()
        logger.info("Started WebSocket background tasks")

        # Initialize scheduler
        init_scheduler()
        await run_missed_jobs()
        
        logger.info("Application startup complete")
        
    except Exception as e:
        logger.error(f"Startup failed: {e}")
        raise
    
    yield
    
    # Shutdown
    logger.info("Shutting down...")
    
    try:
        # Shutdown scheduler
        if scheduler.running:
            scheduler.shutdown()
            logger.info("Scheduler shut down")

        # Disconnect from services
        await storage_service.disconnect()
        await redis_service.disconnect()
        logger.info("Disconnected from all services")
        
        logger.info("Application shutdown complete")
        
    except Exception as e:
        logger.error(f"Shutdown error: {e}")


# Create FastAPI application
app = FastAPI(
    title="SnapShare API",
    description="Real-time ephemeral content sharing with Redis and Firebase",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8080",
        "http://127.0.0.1:8080",
        "http://localhost:5000",
        "http://127.0.0.1:5000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routers
app.include_router(items_router, prefix="/api/v1", tags=["items"])
app.include_router(websocket_router, prefix="/api/v1", tags=["websocket"])
app.include_router(ws_router, prefix="/api/v1", tags=["ws"])
app.include_router(health_router, prefix="/api/v1", tags=["health"])
app.include_router(birthdays_router, prefix="/api/v1", tags=["birthdays"])
app.include_router(birthdays_ws_router, prefix="/api/v1")
app.include_router(fcm_router, prefix="/api/v1", tags=["fcm"])


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "SnapShare API is running!",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/api/v1/health",
        "storage": "StorageService integrated"
    }


@app.get("/api/v1")
async def api_root():
    """API root endpoint"""
    return {
        "message": "SnapShare API v1",
        "endpoints": {
            "items": "/api/v1/items",
            "websocket": "/api/v1/ws",
            "health": "/api/v1/health"
        },
        "features": {
            "ephemeral_storage": "Redis with TTL",
            "real_time": "WebSocket support",
            "authentication": "Firebase integration",
            "file_upload": "Images and audio"
        }
    }


@app.get("/api/v1/storage/info")
async def get_storage_info():
    """Get storage service information"""
    try:
        info = await storage_service.get_storage_info()
        return {
            "status": "success",
            "data": info
        }
    except Exception as e:
        logger.error(f"Failed to get storage info: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/storage/cleanup")
async def cleanup_storage():
    """Manually trigger storage cleanup"""
    try:
        cleaned_count = await storage_service.cleanup_expired_items()
        return {
            "status": "success",
            "message": f"Cleaned up {cleaned_count} expired items",
            "cleaned_count": cleaned_count
        }
    except Exception as e:
        logger.error(f"Failed to cleanup storage: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    # Get configuration from environment
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8000"))
    reload = os.getenv("RELOAD", "true").lower() == "true"
    
    logger.info(f"Starting server on {host}:{port}")
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info"
    )
