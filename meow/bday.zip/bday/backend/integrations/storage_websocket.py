"""
Integration between StorageService and WebSocket broadcasting
This module provides functions to automatically broadcast events when items are created, updated, or deleted
"""
import logging
from typing import Dict, Any, Optional
from services.storage import storage_service, ItemType
from api.ws import broadcast_new_item, broadcast_item_deleted, broadcast_item_expired

logger = logging.getLogger(__name__)


class StorageWebSocketIntegration:
    """Integration class for StorageService and WebSocket broadcasting"""
    
    @staticmethod
    async def save_item_with_broadcast(
        sender: str,
        group_id: str,
        item_type: ItemType,
        content: str,
        ttl_seconds: int,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Save an item and broadcast to WebSocket clients in the group
        
        Args:
            sender: ID of the user who sent the item
            group_id: ID of the group/channel
            item_type: Type of item (snap, doodle, voice, text)
            content: URL or text content
            ttl_seconds: Time to live in seconds
            metadata: Additional metadata for the item
        
        Returns:
            str: Generated item ID
        """
        try:
            # Save the item using StorageService
            item_id = await storage_service.save_item(
                sender=sender,
                group_id=group_id,
                item_type=item_type,
                content=content,
                ttl_seconds=ttl_seconds,
                metadata=metadata
            )
            
            # Get the saved item data for broadcasting
            item_data = await storage_service.get_item(item_id)
            if item_data:
                # Broadcast to all WebSocket clients in the group
                await broadcast_new_item(group_id, item_data, sender)
                logger.info(f"Broadcasted new {item_type.value} item {item_id} to group {group_id}")
            
            return item_id
            
        except Exception as e:
            logger.error(f"Error saving item with broadcast: {e}")
            raise
    
    @staticmethod
    async def delete_item_with_broadcast(item_id: str, user_id: str) -> bool:
        """
        Delete an item and broadcast to WebSocket clients
        
        Args:
            item_id: ID of the item to delete
            user_id: ID of the user requesting deletion
        
        Returns:
            bool: True if deleted successfully
        """
        try:
            # Get item data before deletion for broadcasting
            item_data = await storage_service.get_item(item_id)
            if not item_data:
                logger.warning(f"Item {item_id} not found for deletion")
                return False
            
            # Check if user has permission to delete
            if item_data.get("sender") != user_id:
                logger.warning(f"User {user_id} not authorized to delete item {item_id}")
                return False
            
            group_id = item_data.get("group_id")
            
            # Delete the item
            success = await storage_service.delete_item(item_id)
            if success:
                # Broadcast deletion to all WebSocket clients in the group
                await broadcast_item_deleted(group_id, item_id, user_id)
                logger.info(f"Broadcasted deletion of item {item_id} to group {group_id}")
            
            return success
            
        except Exception as e:
            logger.error(f"Error deleting item with broadcast: {e}")
            return False
    
    @staticmethod
    async def cleanup_expired_items_with_broadcast() -> int:
        """
        Clean up expired items and broadcast expiration events
        
        Returns:
            int: Number of items cleaned up
        """
        try:
            # Get all groups that have active WebSocket connections
            from api.ws import ws_manager
            connected_users = ws_manager.get_connected_users()
            active_groups = set()
            
            for user_id in connected_users:
                user_connections = ws_manager.active_connections.get(user_id, set())
                for websocket in user_connections:
                    metadata = ws_manager.get_connection_metadata(websocket)
                    groups = metadata.get("groups", set())
                    active_groups.update(groups)
            
            cleaned_count = 0
            
            # Check each active group for expired items
            for group_id in active_groups:
                items = await storage_service.get_items(group_id)
                current_time = __import__('datetime').datetime.utcnow()
                expired_items = []
                
                for item in items:
                    expiry_str = item.get("expiry")
                    if expiry_str:
                        expiry_time = __import__('datetime').datetime.fromisoformat(expiry_str)
                        if current_time > expiry_time:
                            expired_items.append(item)
                
                # Broadcast expiration events and clean up
                for item in expired_items:
                    item_id = item.get("id")
                    await broadcast_item_expired(group_id, item_id)
                    
                    # Clean up the expired item
                    await storage_service.delete_item(item_id)
                    cleaned_count += 1
                    logger.info(f"Broadcasted expiration and cleaned up item {item_id} from group {group_id}")
            
            logger.info(f"Cleaned up {cleaned_count} expired items with broadcasts")
            return cleaned_count
            
        except Exception as e:
            logger.error(f"Error cleaning up expired items with broadcast: {e}")
            return 0
    
    @staticmethod
    async def get_group_items_with_metadata(group_id: str) -> Dict[str, Any]:
        """
        Get group items with additional metadata for WebSocket clients
        
        Args:
            group_id: ID of the group
        
        Returns:
            Dict containing items and metadata
        """
        try:
            items = await storage_service.get_items(group_id)
            stats = await storage_service.get_group_stats(group_id)
            
            return {
                "group_id": group_id,
                "items": items,
                "total_count": len(items),
                "stats": stats,
                "timestamp": __import__('datetime').datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error getting group items with metadata: {e}")
            return {
                "group_id": group_id,
                "items": [],
                "total_count": 0,
                "stats": {},
                "error": str(e)
            }


# Convenience functions for easy integration
async def save_snap_with_broadcast(
    sender: str,
    group_id: str,
    image_url: str,
    ttl_hours: int = 24,
    caption: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> str:
    """Save a snap and broadcast to group"""
    ttl_seconds = ttl_hours * 3600
    snap_metadata = metadata or {}
    if caption:
        snap_metadata["caption"] = caption
    
    return await StorageWebSocketIntegration.save_item_with_broadcast(
        sender=sender,
        group_id=group_id,
        item_type=ItemType.SNAP,
        content=image_url,
        ttl_seconds=ttl_seconds,
        metadata=snap_metadata
    )


async def save_text_note_with_broadcast(
    sender: str,
    group_id: str,
    content: str,
    ttl_hours: int = 24,
    font_size: int = 16,
    color: str = "#000000",
    metadata: Optional[Dict[str, Any]] = None
) -> str:
    """Save a text note and broadcast to group"""
    ttl_seconds = ttl_hours * 3600
    text_metadata = metadata or {}
    text_metadata.update({
        "font_size": font_size,
        "color": color
    })
    
    return await StorageWebSocketIntegration.save_item_with_broadcast(
        sender=sender,
        group_id=group_id,
        item_type=ItemType.TEXT,
        content=content,
        ttl_seconds=ttl_seconds,
        metadata=text_metadata
    )


async def save_voice_note_with_broadcast(
    sender: str,
    group_id: str,
    audio_url: str,
    duration: float,
    ttl_hours: int = 24,
    transcript: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> str:
    """Save a voice note and broadcast to group"""
    ttl_seconds = ttl_hours * 3600
    voice_metadata = metadata or {}
    voice_metadata.update({
        "duration": duration,
        "transcript": transcript
    })
    
    return await StorageWebSocketIntegration.save_item_with_broadcast(
        sender=sender,
        group_id=group_id,
        item_type=ItemType.VOICE,
        content=audio_url,
        ttl_seconds=ttl_seconds,
        metadata=voice_metadata
    )


async def save_doodle_with_broadcast(
    sender: str,
    group_id: str,
    doodle_data: str,
    original_image_url: str,
    ttl_hours: int = 24,
    metadata: Optional[Dict[str, Any]] = None
) -> str:
    """Save a doodle and broadcast to group"""
    ttl_seconds = ttl_hours * 3600
    doodle_metadata = metadata or {}
    doodle_metadata.update({
        "original_image_url": original_image_url,
        "doodle_data": doodle_data
    })
    
    return await StorageWebSocketIntegration.save_item_with_broadcast(
        sender=sender,
        group_id=group_id,
        item_type=ItemType.DOODLE,
        content=doodle_data,
        ttl_seconds=ttl_seconds,
        metadata=doodle_metadata
    )
