import os
import uuid
import aiofiles
from typing import Optional, Tuple
from fastapi import UploadFile
from PIL import Image
import logging

logger = logging.getLogger(__name__)


class FileHandler:
    def __init__(self, upload_dir: str = "uploads"):
        self.upload_dir = upload_dir
        self.ensure_upload_dirs()
    
    def ensure_upload_dirs(self):
        """Create necessary upload directories"""
        dirs = [
            self.upload_dir,
            f"{self.upload_dir}/images",
            f"{self.upload_dir}/audio",
            f"{self.upload_dir}/doodles"
        ]
        for dir_path in dirs:
            os.makedirs(dir_path, exist_ok=True)
    
    async def save_upload_file(self, file: UploadFile, file_type: str) -> Tuple[str, str, int]:
        """Save uploaded file and return (file_id, file_url, file_size)"""
        try:
            # Generate unique file ID
            file_id = str(uuid.uuid4())
            
            # Determine file extension and directory
            file_extension = self.get_file_extension(file.content_type)
            subdir = self.get_subdirectory(file_type)
            
            # Create file path
            filename = f"{file_id}{file_extension}"
            file_path = os.path.join(self.upload_dir, subdir, filename)
            
            # Save file
            async with aiofiles.open(file_path, 'wb') as f:
                content = await file.read()
                await f.write(content)
                file_size = len(content)
            
            # Generate file URL (in production, use CDN URL)
            file_url = f"/uploads/{subdir}/{filename}"
            
            logger.info(f"File saved: {file_path}, size: {file_size} bytes")
            return file_id, file_url, file_size
            
        except Exception as e:
            logger.error(f"Error saving file: {e}")
            raise
    
    def get_file_extension(self, content_type: str) -> str:
        """Get file extension from content type"""
        extension_map = {
            "image/jpeg": ".jpg",
            "image/png": ".png",
            "image/gif": ".gif",
            "image/webp": ".webp",
            "audio/mpeg": ".mp3",
            "audio/wav": ".wav",
            "audio/ogg": ".ogg",
            "audio/aac": ".aac",
            "application/json": ".json"
        }
        return extension_map.get(content_type, ".bin")
    
    def get_subdirectory(self, file_type: str) -> str:
        """Get subdirectory based on file type"""
        if file_type in ["image", "snap", "doodle"]:
            return "images"
        elif file_type in ["audio", "voice_note"]:
            return "audio"
        else:
            return "misc"
    
    async def process_image(self, file_path: str, max_size: Tuple[int, int] = (1920, 1080)) -> str:
        """Process and optimize image"""
        try:
            with Image.open(file_path) as img:
                # Convert to RGB if necessary
                if img.mode in ("RGBA", "P"):
                    img = img.convert("RGB")
                
                # Resize if too large
                if img.size[0] > max_size[0] or img.size[1] > max_size[1]:
                    img.thumbnail(max_size, Image.Resampling.LANCZOS)
                
                # Save optimized image
                optimized_path = file_path.replace(".", "_optimized.")
                img.save(optimized_path, "JPEG", quality=85, optimize=True)
                
                # Replace original with optimized
                os.replace(optimized_path, file_path)
                
            return file_path
            
        except Exception as e:
            logger.error(f"Error processing image: {e}")
            return file_path
    
    async def delete_file(self, file_url: str) -> bool:
        """Delete file from storage"""
        try:
            # Extract file path from URL
            file_path = file_url.replace("/uploads/", f"{self.upload_dir}/")
            if os.path.exists(file_path):
                os.remove(file_path)
                logger.info(f"File deleted: {file_path}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error deleting file: {e}")
            return False
    
    def get_file_info(self, file_path: str) -> Optional[dict]:
        """Get file information"""
        try:
            if os.path.exists(file_path):
                stat = os.stat(file_path)
                return {
                    "size": stat.st_size,
                    "created": stat.st_ctime,
                    "modified": stat.st_mtime
                }
        except Exception as e:
            logger.error(f"Error getting file info: {e}")
        return None


# Global file handler instance
file_handler = FileHandler()
