from models.schemas import ExpiryTime
from datetime import datetime, timedelta


def get_ttl_seconds(expiry: ExpiryTime) -> int:
    """Convert expiry time enum to seconds"""
    expiry_map = {
        ExpiryTime.ONE_HOUR: 3600,  # 1 hour
        ExpiryTime.THREE_HOURS: 10800,  # 3 hours
        ExpiryTime.SIX_HOURS: 21600,  # 6 hours
        ExpiryTime.TWELVE_HOURS: 43200,  # 12 hours
        ExpiryTime.TWENTY_FOUR_HOURS: 86400,  # 24 hours
    }
    return expiry_map.get(expiry, 86400)  # Default to 24 hours


def calculate_expiry_time(expiry: ExpiryTime) -> datetime:
    """Calculate expiry datetime from current time"""
    ttl_seconds = get_ttl_seconds(expiry)
    return datetime.utcnow() + timedelta(seconds=ttl_seconds)


def is_expired(expires_at: datetime) -> bool:
    """Check if an item has expired"""
    return datetime.utcnow() > expires_at
