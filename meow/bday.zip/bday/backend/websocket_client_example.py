"""
WebSocket Client Example for SnapShare API
This demonstrates how to connect and interact with the WebSocket API
"""
import asyncio
import websockets
import json
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SnapShareWebSocketClient:
    def __init__(self, uri: str, token: str):
        self.uri = uri
        self.token = token
        self.websocket = None
        self.connected = False
        self.groups = set()
    
    async def connect(self):
        """Connect to WebSocket server"""
        try:
            # Add token as query parameter
            uri_with_token = f"{self.uri}?token={self.token}"
            self.websocket = await websockets.connect(uri_with_token)
            self.connected = True
            logger.info("Connected to WebSocket server")
            
            # Start listening for messages
            await self.listen_for_messages()
            
        except Exception as e:
            logger.error(f"Failed to connect: {e}")
            self.connected = False
    
    async def disconnect(self):
        """Disconnect from WebSocket server"""
        if self.websocket:
            await self.websocket.close()
            self.connected = False
            logger.info("Disconnected from WebSocket server")
    
    async def listen_for_messages(self):
        """Listen for incoming messages"""
        try:
            async for message in self.websocket:
                await self.handle_message(message)
        except websockets.exceptions.ConnectionClosed:
            logger.info("WebSocket connection closed")
            self.connected = False
        except Exception as e:
            logger.error(f"Error listening for messages: {e}")
            self.connected = False
    
    async def handle_message(self, message: str):
        """Handle incoming WebSocket message"""
        try:
            data = json.loads(message)
            message_type = data.get("type")
            message_data = data.get("data", {})
            timestamp = data.get("timestamp")
            
            logger.info(f"Received {message_type}: {message_data}")
            
            if message_type == "new_item":
                await self.handle_new_item(message_data)
            elif message_type == "item_deleted":
                await self.handle_item_deleted(message_data)
            elif message_type == "item_expired":
                await self.handle_item_expired(message_data)
            elif message_type == "user_joined":
                await self.handle_user_joined(message_data)
            elif message_type == "user_left":
                await self.handle_user_left(message_data)
            elif message_type == "group_items":
                await self.handle_group_items(message_data)
            elif message_type == "online_users":
                await self.handle_online_users(message_data)
            elif message_type == "error":
                await self.handle_error(message_data)
            elif message_type == "pong":
                await self.handle_pong(message_data)
            else:
                logger.warning(f"Unknown message type: {message_type}")
                
        except json.JSONDecodeError:
            logger.error("Invalid JSON received")
        except Exception as e:
            logger.error(f"Error handling message: {e}")
    
    async def handle_new_item(self, data: dict):
        """Handle new item notification"""
        group_id = data.get("group_id")
        item = data.get("item", {})
        sender_id = data.get("sender_id")
        
        logger.info(f"📸 New {item.get('type')} in group {group_id} from {sender_id}")
        logger.info(f"   Content: {item.get('content', '')[:50]}...")
    
    async def handle_item_deleted(self, data: dict):
        """Handle item deletion notification"""
        group_id = data.get("group_id")
        item_id = data.get("item_id")
        sender_id = data.get("sender_id")
        
        logger.info(f"🗑️ Item {item_id} deleted in group {group_id} by {sender_id}")
    
    async def handle_item_expired(self, data: dict):
        """Handle item expiration notification"""
        group_id = data.get("group_id")
        item_id = data.get("item_id")
        
        logger.info(f"⏰ Item {item_id} expired in group {group_id}")
    
    async def handle_user_joined(self, data: dict):
        """Handle user joined notification"""
        group_id = data.get("group_id")
        user_id = data.get("user_id")
        
        logger.info(f"👋 User {user_id} joined group {group_id}")
    
    async def handle_user_left(self, data: dict):
        """Handle user left notification"""
        group_id = data.get("group_id")
        user_id = data.get("user_id")
        
        logger.info(f"👋 User {user_id} left group {group_id}")
    
    async def handle_group_items(self, data: dict):
        """Handle group items response"""
        group_id = data.get("group_id")
        items = data.get("items", [])
        total_count = data.get("total_count", 0)
        
        logger.info(f"📋 Group {group_id} has {total_count} items")
        for item in items[:3]:  # Show first 3 items
            logger.info(f"   - {item.get('type')}: {item.get('content', '')[:30]}...")
    
    async def handle_online_users(self, data: dict):
        """Handle online users response"""
        group_id = data.get("group_id")
        users = data.get("users", [])
        count = data.get("count", 0)
        
        logger.info(f"👥 {count} users online in group {group_id}: {users}")
    
    async def handle_error(self, data: dict):
        """Handle error message"""
        message = data.get("message", "Unknown error")
        logger.error(f"❌ Error: {message}")
    
    async def handle_pong(self, data: dict):
        """Handle pong response"""
        user_id = data.get("user_id")
        logger.info(f"🏓 Pong from user {user_id}")
    
    async def send_message(self, message_type: str, data: dict):
        """Send a message to the server"""
        if not self.connected or not self.websocket:
            logger.error("Not connected to WebSocket server")
            return
        
        try:
            message = {
                "type": message_type,
                "data": data,
                "timestamp": datetime.utcnow().isoformat()
            }
            await self.websocket.send(json.dumps(message))
            logger.info(f"Sent {message_type}: {data}")
        except Exception as e:
            logger.error(f"Error sending message: {e}")
    
    async def join_group(self, group_id: str):
        """Join a group"""
        await self.send_message("join_group", {"group_id": group_id})
        self.groups.add(group_id)
    
    async def leave_group(self, group_id: str):
        """Leave a group"""
        await self.send_message("leave_group", {"group_id": group_id})
        self.groups.discard(group_id)
    
    async def get_group_items(self, group_id: str):
        """Get all items in a group"""
        await self.send_message("get_group_items", {"group_id": group_id})
    
    async def get_online_users(self, group_id: str):
        """Get online users in a group"""
        await self.send_message("get_online_users", {"group_id": group_id})
    
    async def ping(self):
        """Send ping to server"""
        await self.send_message("ping", {})


async def demo_websocket_client():
    """Demonstrate WebSocket client functionality"""
    
    # Configuration
    WEBSOCKET_URI = "ws://localhost:8000/api/v1/ws"
    FIREBASE_TOKEN = "your-firebase-token-here"  # Replace with actual token
    
    # Create client
    client = SnapShareWebSocketClient(WEBSOCKET_URI, FIREBASE_TOKEN)
    
    try:
        # Connect to server
        await client.connect()
        
        if not client.connected:
            logger.error("Failed to connect to WebSocket server")
            return
        
        # Join a group
        group_id = "demo_group"
        await client.join_group(group_id)
        await asyncio.sleep(1)
        
        # Get group items
        await client.get_group_items(group_id)
        await asyncio.sleep(1)
        
        # Get online users
        await client.get_online_users(group_id)
        await asyncio.sleep(1)
        
        # Send ping
        await client.ping()
        await asyncio.sleep(1)
        
        # Simulate staying connected for a while
        logger.info("Staying connected for 30 seconds...")
        await asyncio.sleep(30)
        
        # Leave group
        await client.leave_group(group_id)
        await asyncio.sleep(1)
        
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
    except Exception as e:
        logger.error(f"Demo error: {e}")
    finally:
        await client.disconnect()


async def simulate_multiple_clients():
    """Simulate multiple clients connecting to the same group"""
    
    # Configuration
    WEBSOCKET_URI = "ws://localhost:8000/api/v1/ws"
    TOKENS = [
        "token1",  # Replace with actual tokens
        "token2",
        "token3"
    ]
    GROUP_ID = "multi_client_group"
    
    clients = []
    
    try:
        # Create and connect multiple clients
        for i, token in enumerate(TOKENS):
            client = SnapShareWebSocketClient(WEBSOCKET_URI, token)
            clients.append(client)
            
            # Connect in background
            asyncio.create_task(client.connect())
            await asyncio.sleep(0.5)  # Stagger connections
        
        # Wait for all clients to connect
        await asyncio.sleep(2)
        
        # All clients join the same group
        for i, client in enumerate(clients):
            if client.connected:
                await client.join_group(GROUP_ID)
                await asyncio.sleep(0.5)
        
        # Simulate activity
        logger.info("All clients connected and joined group")
        await asyncio.sleep(10)
        
        # One client leaves
        if clients[0].connected:
            await clients[0].leave_group(GROUP_ID)
            await asyncio.sleep(1)
        
        # Simulate more activity
        await asyncio.sleep(10)
        
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
    except Exception as e:
        logger.error(f"Multi-client demo error: {e}")
    finally:
        # Disconnect all clients
        for client in clients:
            await client.disconnect()


if __name__ == "__main__":
    print("WebSocket Client Examples")
    print("=" * 40)
    print("1. Single client demo")
    print("2. Multiple clients demo")
    
    choice = input("Choose demo (1 or 2): ").strip()
    
    if choice == "1":
        asyncio.run(demo_websocket_client())
    elif choice == "2":
        asyncio.run(simulate_multiple_clients())
    else:
        print("Invalid choice")
