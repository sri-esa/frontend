from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, Query
from typing import Optional
import logging

from services.websocket_service import handle_websocket_connection, websocket_manager
from services.firebase_service import firebase_service

logger = logging.getLogger(__name__)
router = APIRouter()


async def verify_websocket_auth(token: str = Query(...)) -> str:
    """Verify WebSocket authentication token"""
    user_data = await firebase_service.verify_token(token)
    if not user_data:
        raise WebSocketDisconnect(code=1008, reason="Invalid authentication token")
    
    return user_data.get("uid")


@router.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    user_id: str = Depends(verify_websocket_auth)
):
    """WebSocket endpoint for real-time communication"""
    await handle_websocket_connection(websocket, user_id)


@router.get("/ws/status")
async def get_websocket_status():
    """Get WebSocket connection status"""
    connected_users = websocket_manager.get_connected_users()
    total_connections = sum(
        websocket_manager.get_user_connection_count(user_id) 
        for user_id in connected_users
    )
    
    return {
        "connected_users": len(connected_users),
        "total_connections": total_connections,
        "users": connected_users
    }
