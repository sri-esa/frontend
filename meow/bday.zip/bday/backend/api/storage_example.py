"""
Example API endpoints using StorageService
This shows how to integrate StorageService with FastAPI endpoints
"""
from fastapi import APIRouter, HTTPException, Depends
from typing import List, Optional
import logging

from services.storage import storage_service, ItemType
from services.firebase_service import firebase_service

logger = logging.getLogger(__name__)
router = APIRouter()


async def get_current_user(token: str = Depends(lambda: None)) -> str:
    """Dependency to get current user from Firebase token"""
    if not token:
        raise HTTPException(status_code=401, detail="Authentication required")
    
    user_data = await firebase_service.verify_token(token)
    if not user_data:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    return user_data.get("uid")


@router.post("/groups/{group_id}/snaps")
async def create_snap(
    group_id: str,
    content: str,
    ttl_hours: int = 24,
    caption: Optional[str] = None,
    user_id: str = Depends(get_current_user)
):
    """Create a snap in a group using StorageService"""
    try:
        # Convert hours to seconds
        ttl_seconds = ttl_hours * 3600
        
        # Save using StorageService
        item_id = await storage_service.save_item(
            sender=user_id,
            group_id=group_id,
            item_type=ItemType.SNAP,
            content=content,
            ttl_seconds=ttl_seconds,
            metadata={
                "caption": caption,
                "created_via": "api"
            }
        )
        
        return {
            "status": "success",
            "item_id": item_id,
            "message": "Snap created successfully"
        }
        
    except Exception as e:
        logger.error(f"Failed to create snap: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/groups/{group_id}/text-notes")
async def create_text_note(
    group_id: str,
    content: str,
    ttl_hours: int = 24,
    font_size: int = 16,
    color: str = "#000000",
    user_id: str = Depends(get_current_user)
):
    """Create a text note in a group using StorageService"""
    try:
        ttl_seconds = ttl_hours * 3600
        
        item_id = await storage_service.save_item(
            sender=user_id,
            group_id=group_id,
            item_type=ItemType.TEXT,
            content=content,
            ttl_seconds=ttl_seconds,
            metadata={
                "font_size": font_size,
                "color": color,
                "created_via": "api"
            }
        )
        
        return {
            "status": "success",
            "item_id": item_id,
            "message": "Text note created successfully"
        }
        
    except Exception as e:
        logger.error(f"Failed to create text note: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/groups/{group_id}/items")
async def get_group_items(
    group_id: str,
    item_type: Optional[ItemType] = None,
    user_id: str = Depends(get_current_user)
):
    """Get all items in a group using StorageService"""
    try:
        # Get all items for the group
        items = await storage_service.get_items(group_id)
        
        # Filter by type if specified
        if item_type:
            items = [item for item in items if item.get("type") == item_type.value]
        
        return {
            "status": "success",
            "group_id": group_id,
            "total_items": len(items),
            "items": items
        }
        
    except Exception as e:
        logger.error(f"Failed to get group items: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/users/{user_id}/items")
async def get_user_items(
    user_id: str,
    item_type: Optional[ItemType] = None,
    current_user: str = Depends(get_current_user)
):
    """Get all items sent by a user using StorageService"""
    try:
        # Check if user is requesting their own items or has permission
        if user_id != current_user:
            # In a real app, you'd check if current_user has permission to view user_id's items
            raise HTTPException(status_code=403, detail="Permission denied")
        
        # Get items by sender
        items = await storage_service.get_items_by_sender(user_id)
        
        # Filter by type if specified
        if item_type:
            items = [item for item in items if item.get("type") == item_type.value]
        
        return {
            "status": "success",
            "user_id": user_id,
            "total_items": len(items),
            "items": items
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get user items: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/items/{item_id}")
async def delete_item(
    item_id: str,
    user_id: str = Depends(get_current_user)
):
    """Delete an item using StorageService"""
    try:
        # First get the item to check ownership
        item = await storage_service.get_item(item_id)
        if not item:
            raise HTTPException(status_code=404, detail="Item not found")
        
        # Check if user is the sender
        if item.get("sender") != user_id:
            raise HTTPException(status_code=403, detail="Only sender can delete item")
        
        # Delete the item
        success = await storage_service.delete_item(item_id)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to delete item")
        
        return {
            "status": "success",
            "message": "Item deleted successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete item: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/groups/{group_id}/stats")
async def get_group_stats(
    group_id: str,
    user_id: str = Depends(get_current_user)
):
    """Get group statistics using StorageService"""
    try:
        stats = await storage_service.get_group_stats(group_id)
        
        return {
            "status": "success",
            "group_id": group_id,
            "stats": stats
        }
        
    except Exception as e:
        logger.error(f"Failed to get group stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/items/types/{item_type}")
async def get_items_by_type(
    item_type: ItemType,
    user_id: str = Depends(get_current_user)
):
    """Get all items of a specific type using StorageService"""
    try:
        items = await storage_service.get_items_by_type(item_type)
        
        return {
            "status": "success",
            "item_type": item_type.value,
            "total_items": len(items),
            "items": items
        }
        
    except Exception as e:
        logger.error(f"Failed to get items by type: {e}")
        raise HTTPException(status_code=500, detail=str(e))
