from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, Query, HTTPException
from typing import Dict, List, Set, Optional, Any
import json
import logging
import asyncio
from datetime import datetime
from enum import Enum

from services.websocket_service import WebSocketManager, WebSocketMessage
from services.storage import storage_service, ItemType
from services.firebase_service import firebase_service

logger = logging.getLogger(__name__)
router = APIRouter()

# Global WebSocket manager instance
ws_manager = WebSocketManager()


class MessageType(str, Enum):
    NEW_ITEM = "new_item"
    ITEM_DELETED = "item_deleted"
    ITEM_EXPIRED = "item_expired"
    GROUP_JOINED = "group_joined"
    GROUP_LEFT = "group_left"
    USER_JOINED = "user_joined"
    USER_LEFT = "user_left"
    PING = "ping"
    PONG = "pong"
    ERROR = "error"
    NOTIFICATION = "notification"


async def verify_websocket_auth(token: str = Query(...)) -> str:
    """Verify WebSocket authentication token"""
    user_data = await firebase_service.verify_token(token)
    if not user_data:
        raise WebSocketDisconnect(code=1008, reason="Invalid authentication token")
    
    return user_data.get("uid")


@router.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    user_id: str = Depends(verify_websocket_auth)
):
    """Main WebSocket endpoint for real-time communication"""
    await ws_manager.connect(websocket, user_id)
    
    try:
        while True:
            # Wait for messages from client
            data = await websocket.receive_text()
            
            try:
                message_data = json.loads(data)
                await process_websocket_message(websocket, user_id, message_data)
            except json.JSONDecodeError:
                logger.error("Invalid JSON received from websocket")
                await send_error_message(websocket, "Invalid JSON format")
    
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
        logger.info(f"User {user_id} disconnected from WebSocket")
    except Exception as e:
        logger.error(f"WebSocket error for user {user_id}: {e}")
        ws_manager.disconnect(websocket)


async def process_websocket_message(websocket: WebSocket, user_id: str, message_data: dict):
    """Process incoming WebSocket message"""
    message_type = message_data.get("type")
    
    if message_type == MessageType.PING:
        await send_pong_message(websocket, user_id)
    
    elif message_type == "join_group":
        group_id = message_data.get("group_id")
        if group_id:
            await join_group(websocket, user_id, group_id)
        else:
            await send_error_message(websocket, "group_id is required")
    
    elif message_type == "leave_group":
        group_id = message_data.get("group_id")
        if group_id:
            await leave_group(websocket, user_id, group_id)
        else:
            await send_error_message(websocket, "group_id is required")
    
    elif message_type == "get_group_items":
        group_id = message_data.get("group_id")
        if group_id:
            await send_group_items(websocket, user_id, group_id)
        else:
            await send_error_message(websocket, "group_id is required")
    
    elif message_type == "get_online_users":
        group_id = message_data.get("group_id")
        if group_id:
            await send_online_users(websocket, user_id, group_id)
        else:
            await send_error_message(websocket, "group_id is required")
    
    else:
        await send_error_message(websocket, f"Unknown message type: {message_type}")


async def join_group(websocket: WebSocket, user_id: str, group_id: str):
    """Join a group channel"""
    try:
        # Store group membership in connection metadata
        metadata = ws_manager.get_connection_metadata(websocket)
        if "groups" not in metadata:
            metadata["groups"] = set()
        metadata["groups"].add(group_id)
        
        # Send confirmation
        await send_message(websocket, MessageType.GROUP_JOINED, {
            "group_id": group_id,
            "user_id": user_id,
            "message": f"Joined group {group_id}"
        })
        
        # Notify other users in the group
        await broadcast_to_group(group_id, MessageType.USER_JOINED, {
            "group_id": group_id,
            "user_id": user_id,
            "message": f"User {user_id} joined the group"
        }, exclude_user=user_id)
        
        logger.info(f"User {user_id} joined group {group_id}")
        
    except Exception as e:
        logger.error(f"Error joining group: {e}")
        await send_error_message(websocket, "Failed to join group")


async def leave_group(websocket: WebSocket, user_id: str, group_id: str):
    """Leave a group channel"""
    try:
        # Remove group membership from connection metadata
        metadata = ws_manager.get_connection_metadata(websocket)
        if "groups" in metadata:
            metadata["groups"].discard(group_id)
        
        # Send confirmation
        await send_message(websocket, MessageType.GROUP_LEFT, {
            "group_id": group_id,
            "user_id": user_id,
            "message": f"Left group {group_id}"
        })
        
        # Notify other users in the group
        await broadcast_to_group(group_id, MessageType.USER_LEFT, {
            "group_id": group_id,
            "user_id": user_id,
            "message": f"User {user_id} left the group"
        }, exclude_user=user_id)
        
        logger.info(f"User {user_id} left group {group_id}")
        
    except Exception as e:
        logger.error(f"Error leaving group: {e}")
        await send_error_message(websocket, "Failed to leave group")


async def send_group_items(websocket: WebSocket, user_id: str, group_id: str):
    """Send all items in a group to the requesting user"""
    try:
        items = await storage_service.get_items(group_id)
        
        await send_message(websocket, "group_items", {
            "group_id": group_id,
            "items": items,
            "total_count": len(items)
        })
        
    except Exception as e:
        logger.error(f"Error sending group items: {e}")
        await send_error_message(websocket, "Failed to get group items")


async def send_online_users(websocket: WebSocket, user_id: str, group_id: str):
    """Send list of online users in a group"""
    try:
        online_users = await get_online_users_in_group(group_id)
        
        await send_message(websocket, "online_users", {
            "group_id": group_id,
            "users": online_users,
            "count": len(online_users)
        })
        
    except Exception as e:
        logger.error(f"Error sending online users: {e}")
        await send_error_message(websocket, "Failed to get online users")


async def get_online_users_in_group(group_id: str) -> List[str]:
    """Get list of online users in a specific group"""
    try:
        online_users = []
        connected_users = ws_manager.get_connected_users()
        
        for user_id in connected_users:
            # Check if user is in the group
            user_connections = ws_manager.active_connections.get(user_id, set())
            for websocket in user_connections:
                metadata = ws_manager.get_connection_metadata(websocket)
                groups = metadata.get("groups", set())
                if group_id in groups:
                    online_users.append(user_id)
                    break
        
        return online_users
        
    except Exception as e:
        logger.error(f"Error getting online users: {e}")
        return []


async def broadcast_new_item(group_id: str, item_data: dict, sender_id: str):
    """Broadcast new item to all users in the group"""
    try:
        message = WebSocketMessage(
            type=MessageType.NEW_ITEM,
            data={
                "group_id": group_id,
                "item": item_data,
                "sender_id": sender_id,
                "timestamp": datetime.utcnow().isoformat()
            },
            sender_id=sender_id,
            recipient_id="group"
        )
        
        await broadcast_to_group(group_id, MessageType.NEW_ITEM, {
            "group_id": group_id,
            "item": item_data,
            "sender_id": sender_id,
            "timestamp": datetime.utcnow().isoformat()
        })
        
        logger.info(f"Broadcasted new item {item_data.get('id')} to group {group_id}")
        
    except Exception as e:
        logger.error(f"Error broadcasting new item: {e}")


async def broadcast_item_deleted(group_id: str, item_id: str, sender_id: str):
    """Broadcast item deletion to all users in the group"""
    try:
        await broadcast_to_group(group_id, MessageType.ITEM_DELETED, {
            "group_id": group_id,
            "item_id": item_id,
            "sender_id": sender_id,
            "timestamp": datetime.utcnow().isoformat()
        })
        
        logger.info(f"Broadcasted item deletion {item_id} to group {group_id}")
        
    except Exception as e:
        logger.error(f"Error broadcasting item deletion: {e}")


async def broadcast_item_expired(group_id: str, item_id: str):
    """Broadcast item expiration to all users in the group"""
    try:
        await broadcast_to_group(group_id, MessageType.ITEM_EXPIRED, {
            "group_id": group_id,
            "item_id": item_id,
            "timestamp": datetime.utcnow().isoformat()
        })
        
        logger.info(f"Broadcasted item expiration {item_id} to group {group_id}")
        
    except Exception as e:
        logger.error(f"Error broadcasting item expiration: {e}")


async def broadcast_to_group(
    group_id: str, 
    message_type: MessageType, 
    data: dict, 
    exclude_user: Optional[str] = None
):
    """Broadcast message to all users in a group"""
    try:
        connected_users = ws_manager.get_connected_users()
        recipients = []
        
        for user_id in connected_users:
            if exclude_user and user_id == exclude_user:
                continue
                
            user_connections = ws_manager.active_connections.get(user_id, set())
            for websocket in user_connections:
                metadata = ws_manager.get_connection_metadata(websocket)
                groups = metadata.get("groups", set())
                if group_id in groups:
                    recipients.append((user_id, websocket))
                    break
        
        # Send message to all recipients
        for user_id, websocket in recipients:
            try:
                await send_message(websocket, message_type, data)
            except Exception as e:
                logger.error(f"Error sending message to user {user_id}: {e}")
                ws_manager.disconnect(websocket)
        
        logger.info(f"Broadcasted {message_type} to {len(recipients)} users in group {group_id}")
        
    except Exception as e:
        logger.error(f"Error broadcasting to group {group_id}: {e}")


async def send_message(websocket: WebSocket, message_type: MessageType, data: dict):
    """Send a message to a specific WebSocket connection"""
    try:
        message = {
            "type": message_type.value,
            "data": data,
            "timestamp": datetime.utcnow().isoformat()
        }
        await websocket.send_text(json.dumps(message))
    except Exception as e:
        logger.error(f"Error sending message: {e}")
        raise


async def send_error_message(websocket: WebSocket, error_message: str):
    """Send an error message to a WebSocket connection"""
    await send_message(websocket, MessageType.ERROR, {
        "message": error_message,
        "error": True
    })


async def send_pong_message(websocket: WebSocket, user_id: str):
    """Send pong response to ping"""
    await send_message(websocket, MessageType.PONG, {
        "user_id": user_id,
        "timestamp": datetime.utcnow().isoformat()
    })


# Background task for monitoring expired items
async def monitor_expired_items():
    """Background task to monitor and broadcast expired items"""
    while True:
        try:
            # Get all connected users and their groups
            connected_users = ws_manager.get_connected_users()
            all_groups = set()
            
            for user_id in connected_users:
                user_connections = ws_manager.active_connections.get(user_id, set())
                for websocket in user_connections:
                    metadata = ws_manager.get_connection_metadata(websocket)
                    groups = metadata.get("groups", set())
                    all_groups.update(groups)
            
            # Check each group for expired items
            for group_id in all_groups:
                await check_and_broadcast_expired_items(group_id)
            
            # Wait before next check
            await asyncio.sleep(30)  # Check every 30 seconds
            
        except Exception as e:
            logger.error(f"Error in expired items monitor: {e}")
            await asyncio.sleep(60)  # Wait longer on error


async def check_and_broadcast_expired_items(group_id: str):
    """Check for expired items in a group and broadcast expiration events"""
    try:
        items = await storage_service.get_items(group_id)
        current_time = datetime.utcnow()
        expired_items = []
        
        for item in items:
            expiry_str = item.get("expiry")
            if expiry_str:
                expiry_time = datetime.fromisoformat(expiry_str)
                if current_time > expiry_time:
                    expired_items.append(item)
        
        # Broadcast expiration events and clean up
        for item in expired_items:
            item_id = item.get("id")
            await broadcast_item_expired(group_id, item_id)
            
            # Clean up the expired item
            await storage_service.delete_item(item_id)
            logger.info(f"Cleaned up expired item {item_id} from group {group_id}")
        
    except Exception as e:
        logger.error(f"Error checking expired items for group {group_id}: {e}")


# API endpoints for WebSocket management
@router.get("/ws/status")
async def get_websocket_status():
    """Get WebSocket connection status"""
    try:
        connected_users = ws_manager.get_connected_users()
        total_connections = sum(
            ws_manager.get_user_connection_count(user_id) 
            for user_id in connected_users
        )
        
        return {
            "status": "success",
            "connected_users": len(connected_users),
            "total_connections": total_connections,
            "users": connected_users
        }
    except Exception as e:
        logger.error(f"Error getting WebSocket status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/ws/groups/{group_id}/users")
async def get_group_users(group_id: str):
    """Get online users in a specific group"""
    try:
        online_users = await get_online_users_in_group(group_id)
        return {
            "status": "success",
            "group_id": group_id,
            "online_users": online_users,
            "count": len(online_users)
        }
    except Exception as e:
        logger.error(f"Error getting group users: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/ws/groups/{group_id}/broadcast")
async def broadcast_to_group_endpoint(
    group_id: str,
    message_type: str,
    data: dict,
    user_id: str = Depends(verify_websocket_auth)
):
    """Broadcast a message to all users in a group (admin endpoint)"""
    try:
        await broadcast_to_group(group_id, MessageType(message_type), data)
        return {
            "status": "success",
            "message": f"Broadcasted {message_type} to group {group_id}"
        }
    except Exception as e:
        logger.error(f"Error broadcasting to group: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Start background task when module is imported
async def start_background_tasks():
    """Start background tasks for WebSocket management"""
    asyncio.create_task(monitor_expired_items())
    logger.info("Started WebSocket background tasks")


# Export functions for use in other modules
__all__ = [
    "ws_manager",
    "broadcast_new_item",
    "broadcast_item_deleted", 
    "broadcast_item_expired",
    "broadcast_to_group",
    "start_background_tasks"
]
