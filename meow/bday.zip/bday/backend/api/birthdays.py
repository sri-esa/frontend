from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from datetime import date

import database
from models import schemas
from services.birthday_service import birthday_service

router = APIRouter(
    prefix="/birthdays",
    tags=["birthdays"],
)

@router.post("/", response_model=schemas.BirthdayResponse)
async def create_or_update_birthday(
    birthday: schemas.BirthdayCreate, db: AsyncSession = Depends(database.get_db)
):
    db_birthday = await birthday_service.get_birthday(db, user_id=birthday.user_id)
    if db_birthday:
        updated_birthday = await birthday_service.update_birthday(
            db,
            user_id=birthday.user_id,
            birthday_update=schemas.BirthdayUpdate(
                birthday_date=birthday.birthday_date,
                age=birthday.age
            )
        )
        return updated_birthday
    return await birthday_service.create_birthday(db=db, birthday=birthday)

@router.get("/{user_id}", response_model=schemas.BirthdayResponse)
async def get_birthday(user_id: str, db: AsyncSession = Depends(database.get_db)):
    db_birthday = await birthday_service.get_birthday(db, user_id=user_id)
    if db_birthday is None:
        raise HTTPException(status_code=404, detail="Birthday not found")
    return db_birthday

@router.get("/upcoming/", response_model=List[schemas.BirthdayResponse])
async def get_upcoming_birthdays(db: AsyncSession = Depends(database.get_db)):
    return await birthday_service.get_upcoming_birthdays(db)

@router.get("/today/", response_model=List[schemas.BirthdayResponse])
async def get_today_birthdays(db: AsyncSession = Depends(database.get_db)):
    return await birthday_service.get_today_birthdays(db)

@router.get("/widget-data/{user_id}")
async def get_widget_data(user_id: str, db: AsyncSession = Depends(database.get_db)):
    db_birthday = await birthday_service.get_birthday(db, user_id=user_id)
    if db_birthday:
        today = date.today()
        if db_birthday.birthday_date.month == today.month and db_birthday.birthday_date.day == today.day:
            age = db_birthday.age if db_birthday.age else 0
            # A simple way to get the name, assuming user_id might be a name or we can fetch it from another service if needed
            name = user_id
            return {
                "mode": "birthday",
                "message": f"🎉 Happy {age}th Birthday, {name}!"
            }
    return {"mode": "normal"}
