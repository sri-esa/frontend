from fastapi import APIRouter, HTTPException, Depends, UploadFile, File, Form
from typing import List, Optional
import uuid
from datetime import datetime
import logging

from models.schemas import (
    ItemCreate, SnapCreate, DoodleCreate, TextNoteCreate, VoiceNoteCreate,
    ItemResponse, ItemListResponse, FileUploadResponse, ItemType, ExpiryTime
)
from services.redis_service import redis_service
from services.firebase_service import firebase_service
from services.websocket_service import websocket_manager
from utils.file_handler import file_handler
from utils.ttl_converter import get_ttl_seconds, calculate_expiry_time

logger = logging.getLogger(__name__)
router = APIRouter()


async def get_current_user(token: str = Depends(lambda: None)) -> str:
    """Dependency to get current user from Firebase token"""
    if not token:
        raise HTTPException(status_code=401, detail="Authentication required")
    
    user_data = await firebase_service.verify_token(token)
    if not user_data:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    return user_data.get("uid")


@router.post("/upload/snap", response_model=ItemResponse)
async def upload_snap(
    recipient_id: str = Form(...),
    expiry: ExpiryTime = Form(ExpiryTime.TWENTY_FOUR_HOURS),
    caption: Optional[str] = Form(None),
    location: Optional[str] = Form(None),  # JSON string
    file: UploadFile = File(...),
    user_id: str = Depends(get_current_user)
):
    """Upload a snap (photo)"""
    try:
        # Validate file type
        if not file.content_type or not file.content_type.startswith("image/"):
            raise HTTPException(status_code=400, detail="File must be an image")
        
        # Save file
        file_id, file_url, file_size = await file_handler.save_upload_file(file, "snap")
        
        # Process image
        file_path = file_url.replace("/uploads/", "uploads/")
        await file_handler.process_image(file_path)
        
        # Parse location if provided
        location_data = None
        if location:
            import json
            try:
                location_data = json.loads(location)
            except json.JSONDecodeError:
                logger.warning(f"Invalid location data: {location}")
        
        # Create item
        item_id = str(uuid.uuid4())
        expires_at = calculate_expiry_time(expiry)
        ttl_seconds = get_ttl_seconds(expiry)
        
        item_data = {
            "id": item_id,
            "sender_id": user_id,
            "recipient_id": recipient_id,
            "item_type": ItemType.SNAP.value,
            "created_at": datetime.utcnow().isoformat(),
            "expires_at": expires_at.isoformat(),
            "is_active": True,
            "image_url": file_url,
            "caption": caption,
            "location": location_data
        }
        
        # Store in Redis
        success = await redis_service.store_item(item_data, ttl_seconds)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to store item")
        
        # Broadcast to recipient
        await websocket_manager.broadcast_new_item(item_data, user_id, recipient_id)
        
        # Send notification
        await firebase_service.send_notification(
            fcm_token="",  # Get from user's FCM token
            title="New Snap!",
            body=f"You received a snap from {user_id}",
            data={"item_id": item_id, "type": "snap"}
        )
        
        return ItemResponse(**item_data)
        
    except Exception as e:
        logger.error(f"Error uploading snap: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/upload/doodle", response_model=ItemResponse)
async def upload_doodle(
    recipient_id: str = Form(...),
    original_image_url: str = Form(...),
    doodle_data: str = Form(...),
    expiry: ExpiryTime = Form(ExpiryTime.TWENTY_FOUR_HOURS),
    caption: Optional[str] = Form(None),
    user_id: str = Depends(get_current_user)
):
    """Upload a doodle (annotated image)"""
    try:
        # Create item
        item_id = str(uuid.uuid4())
        expires_at = calculate_expiry_time(expiry)
        ttl_seconds = get_ttl_seconds(expiry)
        
        item_data = {
            "id": item_id,
            "sender_id": user_id,
            "recipient_id": recipient_id,
            "item_type": ItemType.DOODLE.value,
            "created_at": datetime.utcnow().isoformat(),
            "expires_at": expires_at.isoformat(),
            "is_active": True,
            "original_image_url": original_image_url,
            "doodle_data": doodle_data,
            "caption": caption
        }
        
        # Store in Redis
        success = await redis_service.store_item(item_data, ttl_seconds)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to store item")
        
        # Broadcast to recipient
        await websocket_manager.broadcast_new_item(item_data, user_id, recipient_id)
        
        return ItemResponse(**item_data)
        
    except Exception as e:
        logger.error(f"Error uploading doodle: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/upload/text-note", response_model=ItemResponse)
async def upload_text_note(
    recipient_id: str = Form(...),
    content: str = Form(...),
    expiry: ExpiryTime = Form(ExpiryTime.TWENTY_FOUR_HOURS),
    font_size: int = Form(16),
    text_color: str = Form("#000000"),
    background_color: str = Form("#FFFFFF"),
    user_id: str = Depends(get_current_user)
):
    """Upload a text note"""
    try:
        # Create item
        item_id = str(uuid.uuid4())
        expires_at = calculate_expiry_time(expiry)
        ttl_seconds = get_ttl_seconds(expiry)
        
        item_data = {
            "id": item_id,
            "sender_id": user_id,
            "recipient_id": recipient_id,
            "item_type": ItemType.TEXT_NOTE.value,
            "created_at": datetime.utcnow().isoformat(),
            "expires_at": expires_at.isoformat(),
            "is_active": True,
            "content": content,
            "font_size": font_size,
            "text_color": text_color,
            "background_color": background_color
        }
        
        # Store in Redis
        success = await redis_service.store_item(item_data, ttl_seconds)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to store item")
        
        # Broadcast to recipient
        await websocket_manager.broadcast_new_item(item_data, user_id, recipient_id)
        
        return ItemResponse(**item_data)
        
    except Exception as e:
        logger.error(f"Error uploading text note: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/upload/voice-note", response_model=ItemResponse)
async def upload_voice_note(
    recipient_id: str = Form(...),
    duration: float = Form(...),
    expiry: ExpiryTime = Form(ExpiryTime.TWENTY_FOUR_HOURS),
    transcript: Optional[str] = Form(None),
    file: UploadFile = File(...),
    user_id: str = Depends(get_current_user)
):
    """Upload a voice note"""
    try:
        # Validate file type
        if not file.content_type or not file.content_type.startswith("audio/"):
            raise HTTPException(status_code=400, detail="File must be an audio file")
        
        # Save file
        file_id, file_url, file_size = await file_handler.save_upload_file(file, "voice_note")
        
        # Create item
        item_id = str(uuid.uuid4())
        expires_at = calculate_expiry_time(expiry)
        ttl_seconds = get_ttl_seconds(expiry)
        
        item_data = {
            "id": item_id,
            "sender_id": user_id,
            "recipient_id": recipient_id,
            "item_type": ItemType.VOICE_NOTE.value,
            "created_at": datetime.utcnow().isoformat(),
            "expires_at": expires_at.isoformat(),
            "is_active": True,
            "audio_url": file_url,
            "duration": duration,
            "transcript": transcript
        }
        
        # Store in Redis
        success = await redis_service.store_item(item_data, ttl_seconds)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to store item")
        
        # Broadcast to recipient
        await websocket_manager.broadcast_new_item(item_data, user_id, recipient_id)
        
        return ItemResponse(**item_data)
        
    except Exception as e:
        logger.error(f"Error uploading voice note: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/items", response_model=ItemListResponse)
async def get_items(
    item_type: Optional[ItemType] = None,
    user_id: str = Depends(get_current_user)
):
    """Get all active items for the current user"""
    try:
        items = await redis_service.get_active_items(user_id)
        
        # Filter by type if specified
        if item_type:
            items = [item for item in items if item.get("item_type") == item_type.value]
        
        # Convert to response format
        item_responses = []
        for item in items:
            item_responses.append(ItemResponse(
                id=item["id"],
                sender_id=item["sender_id"],
                recipient_id=item["recipient_id"],
                item_type=ItemType(item["item_type"]),
                created_at=datetime.fromisoformat(item["created_at"]),
                expires_at=datetime.fromisoformat(item["expires_at"]),
                is_active=item["is_active"],
                data=item
            ))
        
        return ItemListResponse(
            items=item_responses,
            total_count=len(item_responses),
            active_count=len(item_responses)
        )
        
    except Exception as e:
        logger.error(f"Error getting items: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/items/{item_id}", response_model=ItemResponse)
async def get_item(
    item_id: str,
    user_id: str = Depends(get_current_user)
):
    """Get a specific item by ID"""
    try:
        item_data = await redis_service.get_item(item_id)
        if not item_data:
            raise HTTPException(status_code=404, detail="Item not found")
        
        # Check if user has access to this item
        if item_data["sender_id"] != user_id and item_data["recipient_id"] != user_id:
            raise HTTPException(status_code=403, detail="Access denied")
        
        return ItemResponse(
            id=item_data["id"],
            sender_id=item_data["sender_id"],
            recipient_id=item_data["recipient_id"],
            item_type=ItemType(item_data["item_type"]),
            created_at=datetime.fromisoformat(item_data["created_at"]),
            expires_at=datetime.fromisoformat(item_data["expires_at"]),
            is_active=item_data["is_active"],
            data=item_data
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting item: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/items/{item_id}")
async def delete_item(
    item_id: str,
    user_id: str = Depends(get_current_user)
):
    """Delete an item"""
    try:
        # Get item first to check permissions
        item_data = await redis_service.get_item(item_id)
        if not item_data:
            raise HTTPException(status_code=404, detail="Item not found")
        
        # Check if user has permission to delete
        if item_data["sender_id"] != user_id:
            raise HTTPException(status_code=403, detail="Only sender can delete item")
        
        # Delete from Redis
        success = await redis_service.delete_item(item_id)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to delete item")
        
        # Broadcast deletion to recipient
        await websocket_manager.broadcast_item_deleted(
            item_id, user_id, item_data["recipient_id"]
        )
        
        return {"message": "Item deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting item: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/cleanup")
async def cleanup_expired_items(user_id: str = Depends(get_current_user)):
    """Manually trigger cleanup of expired items"""
    try:
        cleaned_count = await redis_service.cleanup_expired_items()
        return {"message": f"Cleaned up {cleaned_count} expired items"}
    except Exception as e:
        logger.error(f"Error cleaning up items: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/stats")
async def get_stats(user_id: str = Depends(get_current_user)):
    """Get user statistics"""
    try:
        stats = await redis_service.get_item_count(user_id)
        return stats
    except Exception as e:
        logger.error(f"Error getting stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))
