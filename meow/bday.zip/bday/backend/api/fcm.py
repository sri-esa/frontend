from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

import database
from models import schemas
from services.fcm_service import fcm_service

router = APIRouter(
    prefix="/fcm",
    tags=["fcm"],
)

@router.post("/register", response_model=schemas.FCMTokenResponse)
async def register_fcm_token(
    token: schemas.FCMTokenCreate, db: AsyncSession = Depends(database.get_db)
):
    # Here you might want to add more logic, e.g., to avoid duplicate tokens for the same user.
    # For now, we'll just create a new token every time.
    return await fcm_service.create_fcm_token(db=db, token=token)
