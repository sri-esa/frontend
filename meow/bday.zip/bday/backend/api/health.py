from fastapi import APIRouter
from datetime import datetime
import logging

from models.schemas import HealthResponse
from services.redis_service import redis_service
from services.firebase_service import firebase_service

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    try:
        # Check Redis connection
        redis_status = await redis_service.ping()
        
        # Check Firebase status
        firebase_status = firebase_service.app is not None
        
        overall_status = "healthy" if redis_status and firebase_status else "unhealthy"
        
        return HealthResponse(
            status=overall_status,
            redis=redis_status,
            firebase=firebase_status,
            timestamp=datetime.utcnow()
        )
        
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return HealthResponse(
            status="unhealthy",
            redis=False,
            firebase=False,
            timestamp=datetime.utcnow()
        )


@router.get("/health/redis")
async def redis_health():
    """Redis-specific health check"""
    try:
        status = await redis_service.ping()
        return {"status": "healthy" if status else "unhealthy", "redis": status}
    except Exception as e:
        logger.error(f"Redis health check failed: {e}")
        return {"status": "unhealthy", "redis": False, "error": str(e)}


@router.get("/health/firebase")
async def firebase_health():
    """Firebase-specific health check"""
    try:
        status = firebase_service.app is not None
        return {"status": "healthy" if status else "unhealthy", "firebase": status}
    except Exception as e:
        logger.error(f"Firebase health check failed: {e}")
        return {"status": "unhealthy", "firebase": False, "error": str(e)}
