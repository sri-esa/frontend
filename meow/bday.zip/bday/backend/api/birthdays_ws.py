from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
import logging

from services.websocket_service import websocket_manager
from .ws import verify_websocket_auth

router = APIRouter()
logger = logging.getLogger(__name__)

@router.websocket("/ws/birthdays")
async def websocket_birthday_endpoint(
    websocket: WebSocket,
    user_id: str = Depends(verify_websocket_auth)
):
    """WebSocket endpoint for birthday notifications."""
    await websocket_manager.connect(websocket, user_id)
    logger.info(f"User {user_id} connected to birthday notifications")
    try:
        while True:
            # This endpoint is for receiving notifications, so we just keep the connection alive.
            # We can implement a ping/pong mechanism if needed.
            await websocket.receive_text()
    except WebSocketDisconnect:
        websocket_manager.disconnect(websocket)
        logger.info(f"User {user_id} disconnected from birthday notifications")
    except Exception as e:
        logger.error(f"Error in birthday websocket for user {user_id}: {e}")
        websocket_manager.disconnect(websocket)
