# WebSocket API Implementation

Real-time WebSocket support for SnapShare with group-based broadcasting and automatic item expiration notifications.

## 🚀 Features

### Core WebSocket Features
- **Group-based Channels**: Users can join/leave specific groups
- **Real-time Broadcasting**: New items broadcast to all group members
- **Automatic Expiration**: Expired items automatically broadcast and cleaned up
- **User Presence**: Track online users in groups
- **Authentication**: Firebase token-based authentication
- **Background Monitoring**: Automatic cleanup of expired items

### Message Types
- `new_item` - New snap/note added to group
- `item_deleted` - Item deleted by sender
- `item_expired` - Item expired and removed
- `group_joined` - User joined group
- `group_left` - User left group
- `user_joined` - User came online in group
- `user_left` - User went offline in group
- `ping/pong` - Connection health check
- `error` - Error messages

## 🔧 WebSocket Endpoints

### Main WebSocket Connection
```
WS /api/v1/ws?token=<firebase_token>
```

### REST Endpoints
- `GET /api/v1/ws/status` - WebSocket connection status
- `GET /api/v1/ws/groups/{group_id}/users` - Online users in group
- `POST /api/v1/ws/groups/{group_id}/broadcast` - Admin broadcast

## 📡 WebSocket Protocol

### Connection
```javascript
const ws = new WebSocket('ws://localhost:8000/api/v1/ws?token=your_firebase_token');
```

### Message Format
```json
{
  "type": "message_type",
  "data": {
    "group_id": "group123",
    "user_id": "user456",
    "item_id": "item789",
    "message": "Hello world!"
  },
  "timestamp": "2024-01-01T12:00:00Z"
}
```

### Client Messages

#### Join Group
```json
{
  "type": "join_group",
  "data": {
    "group_id": "friends_group"
  }
}
```

#### Leave Group
```json
{
  "type": "leave_group",
  "data": {
    "group_id": "friends_group"
  }
}
```

#### Get Group Items
```json
{
  "type": "get_group_items",
  "data": {
    "group_id": "friends_group"
  }
}
```

#### Get Online Users
```json
{
  "type": "get_online_users",
  "data": {
    "group_id": "friends_group"
  }
}
```

#### Ping
```json
{
  "type": "ping",
  "data": {}
}
```

### Server Messages

#### New Item
```json
{
  "type": "new_item",
  "data": {
    "group_id": "friends_group",
    "item": {
      "id": "item123",
      "sender": "user456",
      "type": "snap",
      "content": "https://example.com/snap.jpg",
      "expiry": "2024-01-01T13:00:00Z",
      "metadata": {
        "caption": "Beautiful sunset!"
      }
    },
    "sender_id": "user456",
    "timestamp": "2024-01-01T12:00:00Z"
  }
}
```

#### Item Deleted
```json
{
  "type": "item_deleted",
  "data": {
    "group_id": "friends_group",
    "item_id": "item123",
    "sender_id": "user456",
    "timestamp": "2024-01-01T12:00:00Z"
  }
}
```

#### Item Expired
```json
{
  "type": "item_expired",
  "data": {
    "group_id": "friends_group",
    "item_id": "item123",
    "timestamp": "2024-01-01T12:00:00Z"
  }
}
```

#### User Joined
```json
{
  "type": "user_joined",
  "data": {
    "group_id": "friends_group",
    "user_id": "user456",
    "message": "User user456 joined the group"
  }
}
```

#### Online Users
```json
{
  "type": "online_users",
  "data": {
    "group_id": "friends_group",
    "users": ["user123", "user456", "user789"],
    "count": 3
  }
}
```

## 🏗️ Architecture

### WebSocket Manager
- Manages active connections
- Tracks user group memberships
- Handles broadcasting to groups
- Manages connection metadata

### Group Management
- Users can join multiple groups
- Group membership stored in connection metadata
- Automatic cleanup on disconnection
- Presence tracking per group

### Background Tasks
- **Expired Item Monitor**: Checks for expired items every 30 seconds
- **Automatic Cleanup**: Removes expired items and broadcasts events
- **Group-based Processing**: Only processes groups with active connections

## 🔐 Authentication

### Firebase Token
- All WebSocket connections require Firebase authentication
- Token passed as query parameter: `?token=<firebase_id_token>`
- Invalid tokens result in connection closure
- User ID extracted from verified token

### Permission Model
- Users can only delete their own items
- Group membership required for group operations
- Admin endpoints for broadcasting

## 📊 Integration with StorageService

### Automatic Broadcasting
- New items automatically broadcast to group
- Deletions broadcast to group
- Expirations broadcast to group
- Real-time updates for all group members

### Convenience Functions
```python
# Save snap with broadcast
snap_id = await save_snap_with_broadcast(
    sender="user123",
    group_id="friends",
    image_url="https://example.com/snap.jpg",
    ttl_hours=24,
    caption="Beautiful sunset!"
)

# Delete item with broadcast
success = await delete_item_with_broadcast(item_id, user_id)
```

## 🧪 Testing

### Run Tests
```bash
python test_websocket.py
```

### WebSocket Client Example
```bash
python websocket_client_example.py
```

### Test Scenarios
1. **Single Client**: Connect, join group, send/receive messages
2. **Multiple Clients**: Multiple users in same group
3. **Group Management**: Join/leave groups
4. **Item Lifecycle**: Create, delete, expire items
5. **Error Handling**: Invalid tokens, malformed messages

## 🚀 Usage Examples

### JavaScript Client
```javascript
class SnapShareClient {
  constructor(token) {
    this.ws = new WebSocket(`ws://localhost:8000/api/v1/ws?token=${token}`);
    this.groups = new Set();
    this.setupEventHandlers();
  }
  
  setupEventHandlers() {
    this.ws.onmessage = (event) => {
      const message = JSON.parse(event.data);
      this.handleMessage(message);
    };
  }
  
  handleMessage(message) {
    switch(message.type) {
      case 'new_item':
        this.onNewItem(message.data);
        break;
      case 'item_deleted':
        this.onItemDeleted(message.data);
        break;
      case 'item_expired':
        this.onItemExpired(message.data);
        break;
      // ... other handlers
    }
  }
  
  joinGroup(groupId) {
    this.ws.send(JSON.stringify({
      type: 'join_group',
      data: { group_id: groupId }
    }));
    this.groups.add(groupId);
  }
  
  leaveGroup(groupId) {
    this.ws.send(JSON.stringify({
      type: 'leave_group',
      data: { group_id: groupId }
    }));
    this.groups.delete(groupId);
  }
}
```

### Python Client
```python
import asyncio
import websockets
import json

async def websocket_client():
    uri = "ws://localhost:8000/api/v1/ws?token=your_firebase_token"
    
    async with websockets.connect(uri) as websocket:
        # Join a group
        await websocket.send(json.dumps({
            "type": "join_group",
            "data": {"group_id": "friends_group"}
        }))
        
        # Listen for messages
        async for message in websocket:
            data = json.loads(message)
            print(f"Received: {data['type']} - {data['data']}")

asyncio.run(websocket_client())
```

## 📈 Performance

### Optimization Features
- **Connection Pooling**: Efficient WebSocket management
- **Group-based Broadcasting**: Only send to relevant users
- **Background Processing**: Non-blocking expired item cleanup
- **Memory Management**: Automatic cleanup of disconnected users

### Monitoring
- Connection count tracking
- Group membership statistics
- Message throughput monitoring
- Error rate tracking

## 🔧 Configuration

### Environment Variables
```env
# WebSocket Configuration
WS_HEARTBEAT_INTERVAL=30
WS_MAX_CONNECTIONS=1000
WS_MESSAGE_SIZE_LIMIT=1048576  # 1MB
```

### Redis Configuration
- WebSocket state stored in Redis
- Group memberships cached
- Message queuing for offline users

## 🚨 Error Handling

### Common Issues
1. **Invalid Token**: Connection closed with code 1008
2. **Malformed JSON**: Error message sent to client
3. **Group Not Found**: Error response for invalid groups
4. **Permission Denied**: Error for unauthorized operations

### Error Response Format
```json
{
  "type": "error",
  "data": {
    "message": "Error description",
    "error": true
  }
}
```

## 🚀 Deployment

### Production Considerations
1. **Load Balancing**: Use sticky sessions for WebSocket
2. **Redis Cluster**: For high availability
3. **Monitoring**: Set up WebSocket connection monitoring
4. **Scaling**: Consider horizontal scaling strategies

### Docker
```dockerfile
# WebSocket service
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## 📚 API Documentation

### WebSocket Events
- **Client → Server**: Join/leave groups, get items, ping
- **Server → Client**: New items, deletions, expirations, presence

### REST Endpoints
- **Status**: Get connection statistics
- **Groups**: Manage group operations
- **Broadcast**: Admin broadcasting

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Add tests for new functionality
4. Submit pull request

## 📄 License

This project is licensed under the MIT License.
