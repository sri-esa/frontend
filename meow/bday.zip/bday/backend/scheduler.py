import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import date, timedelta

from database import SessionLocal
from services.birthday_service import birthday_service
from services.websocket_service import websocket_manager
from services.fcm_service import fcm_service
from services.firebase_service import firebase_service
from models import schemas

logger = logging.getLogger(__name__)

async def birthday_rollover_job():
    """
    Checks for birthdays and rolls them over to the next year.
    """
    logger.info("Running daily birthday rollover job...")
    db: AsyncSession = SessionLocal()
    try:
        today_birthdays = await birthday_service.get_today_birthdays(db)
        for birthday in today_birthdays:
            logger.info(f"Processing birthday for {birthday.user_id}")

            # Increment age
            new_age = (birthday.age + 1) if birthday.age is not None else 1

            # Update birthday date to next year
            new_birthday_date = birthday.birthday_date.replace(year=birthday.birthday_date.year + 1)

            update_data = {
                "age": new_age,
                "birthday_date": new_birthday_date,
            }

            updated_birthday = await birthday_service.update_birthday(
                db,
                user_id=birthday.user_id,
                birthday_update=schemas.BirthdayUpdate(**update_data)
            )
            logger.info(f"Updated birthday for {birthday.user_id}. New age: {new_age}, New date: {new_birthday_date}")

            # Broadcast the update via WebSocket
            if updated_birthday:
                await websocket_manager.broadcast_birthday_update({
                    "user_id": updated_birthday.user_id,
                    "age": updated_birthday.age,
                    "birthday_date": updated_birthday.birthday_date.isoformat(),
                })

            # Send push notification
            fcm_tokens = await fcm_service.get_fcm_tokens_by_user(db, user_id=birthday.user_id)
            if fcm_tokens:
                token_strings = [token.token for token in fcm_tokens]
                title = f"🎉 It's {birthday.user_id}'s Birthday Today!"
                body = f"Tap to celebrate {birthday.user_id}’s {new_age}th birthday 🎊"
                await firebase_service.send_multicast_notification(
                    fcm_tokens=token_strings,
                    title=title,
                    body=body,
                    data={"user_id": birthday.user_id}
                )

    except Exception as e:
        logger.error(f"Error in birthday rollover job: {e}")
    finally:
        await db.close()

async def run_missed_jobs():
    """
    Run any jobs that were missed while the application was offline.
    For now, this just runs the birthday rollover job.
    """
    logger.info("Checking for missed jobs on startup...")
    await birthday_rollover_job()

scheduler = AsyncIOScheduler(timezone="UTC")

def init_scheduler():
    """
    Initializes and starts the scheduler.
    """
    scheduler.add_job(birthday_rollover_job, 'cron', hour=0, minute=0, second=5)
    scheduler.start()
    logger.info("Scheduler started.")
