from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import List, Optional

from models import fcm as models
from models import schemas

class FCMService:
    async def create_fcm_token(self, db: AsyncSession, token: schemas.FCMTokenCreate) -> models.FCMToken:
        db_token = models.FCMToken(**token.dict())
        db.add(db_token)
        await db.commit()
        await db.refresh(db_token)
        return db_token

    async def get_fcm_tokens_by_user(self, db: AsyncSession, user_id: str) -> List[models.FCMToken]:
        result = await db.execute(select(models.FCMToken).filter(models.FCMToken.user_id == user_id))
        return result.scalars().all()

fcm_service = FCMService()
