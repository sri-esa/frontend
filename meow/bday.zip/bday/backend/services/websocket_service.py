from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict, List, Set, Optional
import json
import logging
from datetime import datetime
from models.schemas import WebSocketMessage

logger = logging.getLogger(__name__)


class WebSocketManager:
    def __init__(self):
        # Store active connections by user_id
        self.active_connections: Dict[str, Set[WebSocket]] = {}
        # Store user_id by websocket for cleanup
        self.websocket_users: Dict[WebSocket, str] = {}
        # Store connection metadata
        self.connection_metadata: Dict[WebSocket, Dict] = {}
    
    async def connect(self, websocket: WebSocket, user_id: str, metadata: Optional[Dict] = None):
        """Accept websocket connection and associate with user"""
        await websocket.accept()
        
        if user_id not in self.active_connections:
            self.active_connections[user_id] = set()
        
        self.active_connections[user_id].add(websocket)
        self.websocket_users[websocket] = user_id
        self.connection_metadata[websocket] = metadata or {}
        
        logger.info(f"User {user_id} connected via WebSocket")
        
        # Send welcome message
        await self.send_personal_message(
            WebSocketMessage(
                type="connection_established",
                data={"message": "Connected successfully", "user_id": user_id},
                sender_id="system",
                recipient_id=user_id
            ),
            websocket
        )
    
    def disconnect(self, websocket: WebSocket):
        """Remove websocket connection"""
        if websocket in self.websocket_users:
            user_id = self.websocket_users[websocket]
            if user_id in self.active_connections:
                self.active_connections[user_id].discard(websocket)
                if not self.active_connections[user_id]:
                    del self.active_connections[user_id]
            
            del self.websocket_users[websocket]
            if websocket in self.connection_metadata:
                del self.connection_metadata[websocket]
            
            logger.info(f"User {user_id} disconnected from WebSocket")
    
    async def send_personal_message(self, message: WebSocketMessage, websocket: WebSocket):
        """Send message to specific websocket"""
        try:
            await websocket.send_text(message.json())
        except Exception as e:
            logger.error(f"Failed to send personal message: {e}")
            self.disconnect(websocket)
    
    async def send_to_user(self, message: WebSocketMessage, user_id: str):
        """Send message to all websockets of a specific user"""
        if user_id in self.active_connections:
            disconnected = set()
            for websocket in self.active_connections[user_id]:
                try:
                    await websocket.send_text(message.json())
                except Exception as e:
                    logger.error(f"Failed to send message to user {user_id}: {e}")
                    disconnected.add(websocket)
            
            # Clean up disconnected websockets
            for websocket in disconnected:
                self.disconnect(websocket)
    
    async def broadcast_new_item(self, item_data: Dict, sender_id: str, recipient_id: str):
        """Broadcast new item to recipient"""
        message = WebSocketMessage(
            type="new_item",
            data=item_data,
            sender_id=sender_id,
            recipient_id=recipient_id
        )
        
        await self.send_to_user(message, recipient_id)
        logger.info(f"Broadcasted new item from {sender_id} to {recipient_id}")
    
    async def broadcast_item_deleted(self, item_id: str, sender_id: str, recipient_id: str):
        """Broadcast item deletion to recipient"""
        message = WebSocketMessage(
            type="item_deleted",
            data={"item_id": item_id},
            sender_id=sender_id,
            recipient_id=recipient_id
        )
        
        await self.send_to_user(message, recipient_id)
        logger.info(f"Broadcasted item deletion {item_id} to {recipient_id}")
    
    async def broadcast_notification(self, notification_data: Dict, recipient_id: str):
        """Broadcast notification to user"""
        message = WebSocketMessage(
            type="notification",
            data=notification_data,
            sender_id="system",
            recipient_id=recipient_id
        )
        
        await self.send_to_user(message, recipient_id)
        logger.info(f"Broadcasted notification to {recipient_id}")
    
    async def broadcast_to_multiple_users(self, message: WebSocketMessage, user_ids: List[str]):
        """Send message to multiple specific users"""
        for user_id in user_ids:
            await self.send_to_user(message, user_id)
    
    async def broadcast_to_all(self, message: WebSocketMessage):
        """Broadcast message to all connected users"""
        disconnected = set()
        for user_id, websockets in self.active_connections.items():
            for websocket in websockets:
                try:
                    await websocket.send_text(message.json())
                except Exception as e:
                    logger.error(f"Failed to broadcast to user {user_id}: {e}")
                    disconnected.add(websocket)
        
        # Clean up disconnected websockets
        for websocket in disconnected:
            self.disconnect(websocket)

    async def broadcast_birthday_update(self, birthday_data: Dict):
        """Broadcast birthday update to all connected users."""
        message = WebSocketMessage(
            type="BirthdayUpdated",
            data=birthday_data,
            sender_id="system",
            recipient_id="broadcast"
        )
        await self.broadcast_to_all(message)
        logger.info(f"Broadcasted birthday update for user {birthday_data.get('user_id')}")
    
    def get_connected_users(self) -> List[str]:
        """Get list of connected user IDs"""
        return list(self.active_connections.keys())
    
    def get_user_connection_count(self, user_id: str) -> int:
        """Get number of connections for a specific user"""
        return len(self.active_connections.get(user_id, set()))
    
    def get_connection_metadata(self, websocket: WebSocket) -> Dict:
        """Get connection metadata"""
        return self.connection_metadata.get(websocket, {})
    
    def is_user_connected(self, user_id: str) -> bool:
        """Check if user is connected"""
        return user_id in self.active_connections and len(self.active_connections[user_id]) > 0


# Global WebSocket manager instance
websocket_manager = WebSocketManager()


async def handle_websocket_connection(websocket: WebSocket, user_id: str, metadata: Optional[Dict] = None):
    """Handle websocket connection and message processing"""
    await websocket_manager.connect(websocket, user_id, metadata)
    
    try:
        while True:
            # Wait for messages from client
            data = await websocket.receive_text()
            
            try:
                message_data = json.loads(data)
                await process_websocket_message(websocket, message_data)
            except json.JSONDecodeError:
                logger.error("Invalid JSON received from websocket")
                await websocket_manager.send_personal_message(
                    WebSocketMessage(
                        type="error",
                        data={"message": "Invalid JSON format"},
                        sender_id="system",
                        recipient_id=user_id
                    ),
                    websocket
                )
    
    except WebSocketDisconnect:
        websocket_manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        websocket_manager.disconnect(websocket)


async def process_websocket_message(websocket: WebSocket, message_data: dict):
    """Process incoming websocket message"""
    message_type = message_data.get("type")
    user_id = websocket_manager.websocket_users.get(websocket)
    
    if not user_id:
        logger.error("Received message from unknown websocket")
        return
    
    if message_type == "ping":
        # Respond to ping with pong
        await websocket_manager.send_personal_message(
            WebSocketMessage(
                type="pong",
                data={"timestamp": datetime.utcnow().isoformat()},
                sender_id="system",
                recipient_id=user_id
            ),
            websocket
        )
    
    elif message_type == "subscribe":
        # Handle subscription to specific channels
        channel = message_data.get("channel")
        if channel:
            # Store subscription info
            metadata = websocket_manager.get_connection_metadata(websocket)
            metadata["subscriptions"] = metadata.get("subscriptions", set())
            metadata["subscriptions"].add(channel)
            logger.info(f"User {user_id} subscribed to channel: {channel}")
    
    elif message_type == "unsubscribe":
        # Handle unsubscription from channels
        channel = message_data.get("channel")
        if channel:
            metadata = websocket_manager.get_connection_metadata(websocket)
            subscriptions = metadata.get("subscriptions", set())
            subscriptions.discard(channel)
            logger.info(f"User {user_id} unsubscribed from channel: {channel}")
    
    elif message_type == "get_status":
        # Send connection status
        await websocket_manager.send_personal_message(
            WebSocketMessage(
                type="status",
                data={
                    "connected": True,
                    "user_id": user_id,
                    "connection_count": websocket_manager.get_user_connection_count(user_id),
                    "timestamp": datetime.utcnow().isoformat()
                },
                sender_id="system",
                recipient_id=user_id
            ),
            websocket
        )
    
    else:
        # Unknown message type
        await websocket_manager.send_personal_message(
            WebSocketMessage(
                type="error",
                data={"message": f"Unknown message type: {message_type}"},
                sender_id="system",
                recipient_id=user_id
            ),
            websocket
        )
