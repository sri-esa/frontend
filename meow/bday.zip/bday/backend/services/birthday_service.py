from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import update, delete, extract
from datetime import date, datetime
from typing import List, Optional

from models import birthday as models
from models import schemas

class BirthdayService:
    async def create_birthday(self, db: AsyncSession, birthday: schemas.BirthdayCreate) -> models.BirthdayReminder:
        db_birthday = models.BirthdayReminder(**birthday.dict())
        db.add(db_birthday)
        await db.commit()
        await db.refresh(db_birthday)
        return db_birthday

    async def get_birthday(self, db: AsyncSession, user_id: str) -> Optional[models.BirthdayReminder]:
        result = await db.execute(select(models.BirthdayReminder).filter(models.BirthdayReminder.user_id == user_id))
        return result.scalars().first()

    async def get_all_birthdays(self, db: AsyncSession) -> List[models.BirthdayReminder]:
        result = await db.execute(select(models.BirthdayReminder))
        return result.scalars().all()

    async def get_upcoming_birthdays(self, db: AsyncSession) -> List[models.BirthdayReminder]:
        today = date.today()
        result = await db.execute(
            select(models.BirthdayReminder)
            .filter(
                (extract('month', models.BirthdayReminder.birthday_date) > today.month) |
                ((extract('month', models.BirthdayReminder.birthday_date) == today.month) &
                 (extract('day', models.BirthdayReminder.birthday_date) >= today.day))
            )
            .order_by(
                extract('month', models.BirthdayReminder.birthday_date),
                extract('day', models.BirthdayReminder.birthday_date)
            )
        )
        return result.scalars().all()

    async def get_today_birthdays(self, db: AsyncSession) -> List[models.BirthdayReminder]:
        today = date.today()
        result = await db.execute(
            select(models.BirthdayReminder).filter(
                extract('month', models.BirthdayReminder.birthday_date) == today.month,
                extract('day', models.BirthdayReminder.birthday_date) == today.day
            )
        )
        return result.scalars().all()

    async def update_birthday(self, db: AsyncSession, user_id: str, birthday_update: schemas.BirthdayUpdate) -> Optional[models.BirthdayReminder]:
        update_data = birthday_update.dict(exclude_unset=True)
        if not update_data:
            return await self.get_birthday(db, user_id)

        await db.execute(
            update(models.BirthdayReminder)
            .where(models.BirthdayReminder.user_id == user_id)
            .values(**update_data)
        )
        await db.commit()
        return await self.get_birthday(db, user_id)

    async def delete_birthday(self, db: AsyncSession, user_id: str):
        await db.execute(
            delete(models.BirthdayReminder)
            .where(models.BirthdayReminder.user_id == user_id)
        )
        await db.commit()

birthday_service = BirthdayService()
