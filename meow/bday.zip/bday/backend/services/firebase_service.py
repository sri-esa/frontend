import firebase_admin
from firebase_admin import credentials, messaging, auth
import logging
from typing import Optional, Dict, Any, List
import os

logger = logging.getLogger(__name__)


class FirebaseService:
    def __init__(self):
        self.app = None
        self._initialize_firebase()
    
    def _initialize_firebase(self):
        """Initialize Firebase Admin SDK"""
        try:
            if not firebase_admin._apps:
                # Try to use service account key file first
                service_account_path = os.getenv("FIREBASE_SERVICE_ACCOUNT_PATH")
                if service_account_path and os.path.exists(service_account_path):
                    cred = credentials.Certificate(service_account_path)
                else:
                    # Fall back to default credentials
                    cred = credentials.ApplicationDefault()
                
                self.app = firebase_admin.initialize_app(cred)
            else:
                self.app = firebase_admin.get_app()
            
            logger.info("Firebase initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Firebase: {e}")
            self.app = None
    
    async def verify_token(self, id_token: str) -> Optional[Dict[str, Any]]:
        """Verify Firebase ID token and return decoded token"""
        try:
            if not self.app:
                logger.error("Firebase not initialized")
                return None
            
            decoded_token = auth.verify_id_token(id_token)
            return decoded_token
        except Exception as e:
            logger.error(f"Failed to verify token: {e}")
            return None
    
    async def get_user(self, uid: str) -> Optional[Dict[str, Any]]:
        """Get user information from Firebase"""
        try:
            if not self.app:
                logger.error("Firebase not initialized")
                return None
            
            user = auth.get_user(uid)
            return {
                "uid": user.uid,
                "email": user.email,
                "display_name": user.display_name,
                "photo_url": user.photo_url,
                "phone_number": user.phone_number,
                "disabled": user.disabled,
                "email_verified": user.email_verified,
                "created_at": user.user_metadata.get("creation_timestamp"),
                "last_sign_in": user.user_metadata.get("last_sign_in_timestamp")
            }
        except Exception as e:
            logger.error(f"Failed to get user: {e}")
            return None
    
    async def send_notification(
        self, 
        fcm_token: str, 
        title: str, 
        body: str, 
        data: Optional[Dict[str, str]] = None
    ) -> bool:
        """Send push notification to single device"""
        try:
            if not self.app:
                logger.error("Firebase not initialized")
                return False
            
            message = messaging.Message(
                notification=messaging.Notification(
                    title=title,
                    body=body,
                ),
                data=data or {},
                token=fcm_token,
            )
            
            response = messaging.send(message)
            logger.info(f"Successfully sent notification: {response}")
            return True
        except Exception as e:
            logger.error(f"Failed to send notification: {e}")
            return False
    
    async def send_multicast_notification(
        self,
        fcm_tokens: List[str],
        title: str,
        body: str,
        data: Optional[Dict[str, str]] = None
    ) -> Dict[str, int]:
        """Send push notification to multiple devices"""
        try:
            if not self.app:
                logger.error("Firebase not initialized")
                return {"success": 0, "failure": 0}
            
            message = messaging.MulticastMessage(
                notification=messaging.Notification(
                    title=title,
                    body=body,
                ),
                data=data or {},
                tokens=fcm_tokens,
            )
            
            response = messaging.send_multicast(message)
            logger.info(f"Multicast notification sent: {response.success_count} successful, {response.failure_count} failed")
            
            return {
                "success": response.success_count,
                "failure": response.failure_count
            }
        except Exception as e:
            logger.error(f"Failed to send multicast notification: {e}")
            return {"success": 0, "failure": 0}
    
    async def send_topic_notification(
        self,
        topic: str,
        title: str,
        body: str,
        data: Optional[Dict[str, str]] = None
    ) -> bool:
        """Send notification to a topic"""
        try:
            if not self.app:
                logger.error("Firebase not initialized")
                return False
            
            message = messaging.Message(
                notification=messaging.Notification(
                    title=title,
                    body=body,
                ),
                data=data or {},
                topic=topic,
            )
            
            response = messaging.send(message)
            logger.info(f"Successfully sent topic notification: {response}")
            return True
        except Exception as e:
            logger.error(f"Failed to send topic notification: {e}")
            return False
    
    async def subscribe_to_topic(self, fcm_tokens: List[str], topic: str) -> bool:
        """Subscribe devices to a topic"""
        try:
            if not self.app:
                logger.error("Firebase not initialized")
                return False
            
            response = messaging.subscribe_to_topic(fcm_tokens, topic)
            logger.info(f"Successfully subscribed {len(fcm_tokens)} tokens to topic {topic}")
            return True
        except Exception as e:
            logger.error(f"Failed to subscribe to topic: {e}")
            return False
    
    async def unsubscribe_from_topic(self, fcm_tokens: List[str], topic: str) -> bool:
        """Unsubscribe devices from a topic"""
        try:
            if not self.app:
                logger.error("Firebase not initialized")
                return False
            
            response = messaging.unsubscribe_from_topic(fcm_tokens, topic)
            logger.info(f"Successfully unsubscribed {len(fcm_tokens)} tokens from topic {topic}")
            return True
        except Exception as e:
            logger.error(f"Failed to unsubscribe from topic: {e}")
            return False
    
    async def create_custom_token(self, uid: str, additional_claims: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """Create custom token for user"""
        try:
            if not self.app:
                logger.error("Firebase not initialized")
                return None
            
            custom_token = auth.create_custom_token(uid, additional_claims)
            return custom_token.decode('utf-8')
        except Exception as e:
            logger.error(f"Failed to create custom token: {e}")
            return None
    
    async def revoke_refresh_tokens(self, uid: str) -> bool:
        """Revoke all refresh tokens for a user"""
        try:
            if not self.app:
                logger.error("Firebase not initialized")
                return False
            
            auth.revoke_refresh_tokens(uid)
            logger.info(f"Successfully revoked refresh tokens for user {uid}")
            return True
        except Exception as e:
            logger.error(f"Failed to revoke refresh tokens: {e}")
            return False


# Global Firebase service instance
firebase_service = FirebaseService()
