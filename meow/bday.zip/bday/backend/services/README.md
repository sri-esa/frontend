# StorageService

A Redis-based ephemeral storage service for managing temporary content with automatic TTL (Time To Live) expiration.

## 🚀 Features

### Core Functionality
- **Ephemeral Storage**: Items automatically expire based on TTL
- **Redis Integration**: High-performance storage with SETEX for TTL
- **Multiple Indexing**: Items indexed by group, sender, and type
- **Automatic Cleanup**: Expired items are automatically removed
- **Comprehensive Queries**: Get items by various criteria

### Item Structure
Each item contains:
- `id`: Unique identifier (UUID)
- `sender`: ID of the user who created the item
- `group_id`: ID of the group/channel
- `type`: Item type (snap, doodle, voice, text)
- `content`: URL or text content
- `expiry`: ISO timestamp when item expires
- `created_at`: ISO timestamp when item was created
- `metadata`: Additional data (optional)

## 📦 Installation

```bash
pip install redis aioredis
```

## 🔧 Usage

### Basic Setup

```python
from services.storage import StorageService, ItemType

# Initialize service
storage = StorageService("redis://localhost:6379/0")

# Connect to Redis
await storage.connect()

# Use the service...
await storage.disconnect()
```

### Saving Items

```python
# Save a snap
snap_id = await storage.save_item(
    sender="user123",
    group_id="group456",
    item_type=ItemType.SNAP,
    content="https://example.com/snap.jpg",
    ttl_seconds=3600,  # 1 hour
    metadata={"caption": "Beautiful sunset!"}
)

# Save a text note
text_id = await storage.save_item(
    sender="user123",
    group_id="group456",
    item_type=ItemType.TEXT,
    content="This is an important message!",
    ttl_seconds=7200,  # 2 hours
    metadata={"font_size": 18, "color": "#FF0000"}
)
```

### Retrieving Items

```python
# Get all items in a group
group_items = await storage.get_items("group456")

# Get specific item
item = await storage.get_item(snap_id)

# Get items by sender
user_items = await storage.get_items_by_sender("user123")

# Get items by type
snap_items = await storage.get_items_by_type(ItemType.SNAP)
```

### Managing Items

```python
# Delete an item
success = await storage.delete_item(item_id)

# Get group statistics
stats = await storage.get_group_stats("group456")

# Cleanup expired items
cleaned_count = await storage.cleanup_expired_items()
```

## 🏗️ Architecture

### Redis Data Structure

```
item:{item_id}              # Item data (JSON with TTL)
group:{group_id}:items      # Set of item IDs in group
sender:{sender}:items       # Set of item IDs by sender
type:{type}:items          # Set of item IDs by type
```

### TTL Management
- Items are stored with `SETEX` for automatic expiration
- All related sets (group, sender, type) have matching TTL
- Expired items are automatically cleaned up on access
- Manual cleanup available via `cleanup_expired_items()`

## 📊 API Reference

### StorageService Class

#### Constructor
```python
StorageService(redis_url: str = "redis://localhost:6379/0")
```

#### Connection Methods
```python
async def connect() -> None
async def disconnect() -> None
async def ping() -> bool
```

#### Item Management
```python
async def save_item(
    sender: str,
    group_id: str,
    item_type: ItemType,
    content: str,
    ttl_seconds: int,
    metadata: Optional[Dict[str, Any]] = None
) -> str

async def get_item(item_id: str) -> Optional[Dict[str, Any]]
async def delete_item(item_id: str) -> bool
```

#### Query Methods
```python
async def get_items(group_id: str) -> List[Dict[str, Any]]
async def get_items_by_sender(sender: str) -> List[Dict[str, Any]]
async def get_items_by_type(item_type: ItemType) -> List[Dict[str, Any]]
```

#### Utility Methods
```python
async def cleanup_expired_items() -> int
async def get_group_stats(group_id: str) -> Dict[str, Any]
async def get_storage_info() -> Dict[str, Any]
```

## 🧪 Testing

### Run Tests
```bash
python test_storage.py
```

### Example Usage
```bash
python example_usage.py
```

## 🔧 Configuration

### Environment Variables
```env
REDIS_URL=redis://localhost:6379/0
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0
REDIS_PASSWORD=
```

### Redis Configuration
- **Memory**: Ensure sufficient memory for your data
- **Persistence**: Configure based on your needs
- **Replication**: Set up for high availability

## 📈 Performance

### Optimizations
- **Connection Pooling**: Reuse Redis connections
- **Batch Operations**: Use pipelines for multiple operations
- **Memory Management**: Automatic cleanup of expired items
- **Efficient Indexing**: Multiple indexes for fast queries

### Monitoring
```python
# Get storage information
info = await storage.get_storage_info()
print(f"Total items: {info['total_items']}")
print(f"Memory used: {info['redis_memory_used']}")
```

## 🚨 Error Handling

### Common Issues
1. **Redis Connection**: Ensure Redis is running
2. **Memory Limits**: Monitor Redis memory usage
3. **TTL Expiry**: Items automatically expire
4. **Network Issues**: Handle connection timeouts

### Best Practices
- Always check return values
- Handle connection errors gracefully
- Monitor memory usage
- Implement proper logging

## 🔒 Security

### Data Protection
- Items are stored with TTL for automatic cleanup
- No sensitive data in Redis keys
- Proper authentication required for API access

### Access Control
- Items are scoped by group and sender
- Proper permission checks in API layer
- User isolation through sender identification

## 🚀 Deployment

### Production Considerations
1. **Redis Cluster**: Use for high availability
2. **Memory Monitoring**: Set up alerts
3. **Backup Strategy**: Configure Redis persistence
4. **Scaling**: Consider Redis sharding

### Docker
```dockerfile
# Use Redis in Docker
docker run -d --name redis -p 6379:6379 redis:7-alpine
```

## 📚 Examples

### Complete Example
```python
import asyncio
from services.storage import StorageService, ItemType

async def main():
    storage = StorageService()
    await storage.connect()
    
    # Save items
    snap_id = await storage.save_item(
        sender="alice",
        group_id="friends",
        item_type=ItemType.SNAP,
        content="https://example.com/photo.jpg",
        ttl_seconds=3600
    )
    
    # Get items
    items = await storage.get_items("friends")
    print(f"Found {len(items)} items")
    
    # Cleanup
    await storage.cleanup_expired_items()
    await storage.disconnect()

asyncio.run(main())
```

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Add tests for new functionality
4. Submit pull request

## 📄 License

This project is licensed under the MIT License.
