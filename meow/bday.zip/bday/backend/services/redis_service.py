import redis.asyncio as redis
import json
import logging
from typing import Any, Optional, List, Dict
from datetime import datetime
from models.schemas import BaseItem, ItemType
from utils.ttl_converter import get_ttl_seconds, is_expired

logger = logging.getLogger(__name__)


class RedisService:
    def __init__(self, redis_url: str = "redis://localhost:6379/0"):
        self.redis_url = redis_url
        self.redis: Optional[redis.Redis] = None
    
    async def connect(self):
        """Connect to Redis server"""
        try:
            self.redis = redis.from_url(self.redis_url, decode_responses=True)
            await self.redis.ping()
            logger.info("Connected to Redis successfully")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            raise
    
    async def disconnect(self):
        """Disconnect from Redis server"""
        if self.redis:
            await self.redis.close()
            logger.info("Disconnected from Redis")
    
    async def ping(self) -> bool:
        """Check Redis connection"""
        try:
            await self.redis.ping()
            return True
        except Exception:
            return False
    
    async def store_item(self, item: BaseItem, ttl_seconds: int) -> bool:
        """Store item in Redis with TTL"""
        try:
            key = f"item:{item.id}"
            item_data = item.dict()
            item_data["created_at"] = item.created_at.isoformat()
            item_data["expires_at"] = item.expires_at.isoformat()
            
            await self.redis.setex(key, ttl_seconds, json.dumps(item_data))
            
            # Also store in user's item list
            user_key = f"user:{item.sender_id}:items"
            await self.redis.sadd(user_key, item.id)
            await self.redis.expire(user_key, ttl_seconds)
            
            # Store in recipient's inbox
            recipient_key = f"recipient:{item.recipient_id}:items"
            await self.redis.sadd(recipient_key, item.id)
            await self.redis.expire(recipient_key, ttl_seconds)
            
            logger.info(f"Item {item.id} stored with TTL {ttl_seconds}s")
            return True
            
        except Exception as e:
            logger.error(f"Failed to store item: {e}")
            return False
    
    async def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """Get item from Redis"""
        try:
            key = f"item:{item_id}"
            item_data = await self.redis.get(key)
            
            if not item_data:
                return None
            
            item_dict = json.loads(item_data)
            
            # Check if expired
            expires_at = datetime.fromisoformat(item_dict["expires_at"])
            if is_expired(expires_at):
                await self.delete_item(item_id)
                return None
            
            return item_dict
            
        except Exception as e:
            logger.error(f"Failed to get item: {e}")
            return None
    
    async def delete_item(self, item_id: str) -> bool:
        """Delete item from Redis"""
        try:
            key = f"item:{item_id}"
            item_data = await self.redis.get(key)
            
            if item_data:
                item_dict = json.loads(item_data)
                sender_id = item_dict.get("sender_id")
                recipient_id = item_dict.get("recipient_id")
                
                # Delete from all collections
                await self.redis.delete(key)
                
                if sender_id:
                    user_key = f"user:{sender_id}:items"
                    await self.redis.srem(user_key, item_id)
                
                if recipient_id:
                    recipient_key = f"recipient:{recipient_id}:items"
                    await self.redis.srem(recipient_key, item_id)
                
                logger.info(f"Item {item_id} deleted")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to delete item: {e}")
            return False
    
    async def get_user_items(self, user_id: str, item_type: Optional[ItemType] = None) -> List[Dict[str, Any]]:
        """Get all active items for a user"""
        try:
            # Get items from both sent and received
            sent_key = f"user:{user_id}:items"
            received_key = f"recipient:{user_id}:items"
            
            sent_items = await self.redis.smembers(sent_key) or set()
            received_items = await self.redis.smembers(received_key) or set()
            
            all_item_ids = sent_items.union(received_items)
            items = []
            
            for item_id in all_item_ids:
                item_data = await self.get_item(item_id)
                if item_data:
                    if item_type is None or item_data.get("item_type") == item_type.value:
                        items.append(item_data)
            
            # Sort by creation time (newest first)
            items.sort(key=lambda x: x["created_at"], reverse=True)
            return items
            
        except Exception as e:
            logger.error(f"Failed to get user items: {e}")
            return []
    
    async def get_active_items(self, user_id: str) -> List[Dict[str, Any]]:
        """Get all active (non-expired) items for a user"""
        try:
            items = await self.get_user_items(user_id)
            active_items = []
            
            for item in items:
                expires_at = datetime.fromisoformat(item["expires_at"])
                if not is_expired(expires_at):
                    active_items.append(item)
                else:
                    # Clean up expired item
                    await self.delete_item(item["id"])
            
            return active_items
            
        except Exception as e:
            logger.error(f"Failed to get active items: {e}")
            return []
    
    async def cleanup_expired_items(self) -> int:
        """Clean up all expired items"""
        try:
            # Get all item keys
            pattern = "item:*"
            keys = await self.redis.keys(pattern)
            cleaned_count = 0
            
            for key in keys:
                item_data = await self.redis.get(key)
                if item_data:
                    item_dict = json.loads(item_data)
                    expires_at = datetime.fromisoformat(item_dict["expires_at"])
                    
                    if is_expired(expires_at):
                        item_id = item_dict["id"]
                        await self.delete_item(item_id)
                        cleaned_count += 1
            
            logger.info(f"Cleaned up {cleaned_count} expired items")
            return cleaned_count
            
        except Exception as e:
            logger.error(f"Failed to cleanup expired items: {e}")
            return 0
    
    async def get_item_count(self, user_id: str) -> Dict[str, int]:
        """Get item count statistics for a user"""
        try:
            sent_key = f"user:{user_id}:items"
            received_key = f"recipient:{user_id}:items"
            
            sent_count = await self.redis.scard(sent_key) or 0
            received_count = await self.redis.scard(received_key) or 0
            
            return {
                "sent": sent_count,
                "received": received_count,
                "total": sent_count + received_count
            }
            
        except Exception as e:
            logger.error(f"Failed to get item count: {e}")
            return {"sent": 0, "received": 0, "total": 0}
    
    async def store_notification(self, user_id: str, notification_data: Dict[str, Any], ttl_seconds: int = 86400) -> bool:
        """Store notification for user"""
        try:
            key = f"notification:{user_id}:{datetime.utcnow().timestamp()}"
            await self.redis.setex(key, ttl_seconds, json.dumps(notification_data))
            return True
        except Exception as e:
            logger.error(f"Failed to store notification: {e}")
            return False
    
    async def get_notifications(self, user_id: str) -> List[Dict[str, Any]]:
        """Get notifications for user"""
        try:
            pattern = f"notification:{user_id}:*"
            keys = await self.redis.keys(pattern)
            notifications = []
            
            for key in keys:
                notification_data = await self.redis.get(key)
                if notification_data:
                    notifications.append(json.loads(notification_data))
            
            return sorted(notifications, key=lambda x: x.get("timestamp", 0), reverse=True)
            
        except Exception as e:
            logger.error(f"Failed to get notifications: {e}")
            return []


# Global Redis service instance
redis_service = RedisService()
