import redis.asyncio as redis
import json
import uuid
import logging
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
from enum import Enum

logger = logging.getLogger(__name__)


class ItemType(str, Enum):
    SNAP = "snap"
    DOODLE = "doodle"
    VOICE = "voice"
    TEXT = "text"


class StorageService:
    def __init__(self, redis_url: str = "redis://localhost:6379/0"):
        self.redis_url = redis_url
        self.redis: Optional[redis.Redis] = None
        self._connected = False
    
    async def connect(self):
        """Connect to Redis server"""
        try:
            self.redis = redis.from_url(self.redis_url, decode_responses=True)
            await self.redis.ping()
            self._connected = True
            logger.info("Connected to Redis successfully")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            raise
    
    async def disconnect(self):
        """Disconnect from Redis server"""
        if self.redis:
            await self.redis.close()
            self._connected = False
            logger.info("Disconnected from Redis")
    
    async def ping(self) -> bool:
        """Check Redis connection"""
        try:
            if not self._connected or not self.redis:
                return False
            await self.redis.ping()
            return True
        except Exception:
            return False
    
    def _ensure_connected(self):
        """Ensure Redis connection is established"""
        if not self._connected or not self.redis:
            raise ConnectionError("Redis not connected. Call connect() first.")
    
    def _generate_item_id(self) -> str:
        """Generate unique item ID"""
        return str(uuid.uuid4())
    
    def _get_item_key(self, item_id: str) -> str:
        """Get Redis key for item"""
        return f"item:{item_id}"
    
    def _get_group_key(self, group_id: str) -> str:
        """Get Redis key for group items set"""
        return f"group:{group_id}:items"
    
    def _get_sender_key(self, sender: str) -> str:
        """Get Redis key for sender items set"""
        return f"sender:{sender}:items"
    
    def _get_type_key(self, item_type: ItemType) -> str:
        """Get Redis key for item type set"""
        return f"type:{item_type.value}:items"
    
    async def save_item(
        self, 
        sender: str, 
        group_id: str, 
        item_type: ItemType, 
        content: str, 
        ttl_seconds: int,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Save an item to Redis with TTL
        
        Args:
            sender: ID of the user who sent the item
            group_id: ID of the group/channel
            item_type: Type of item (snap, doodle, voice, text)
            content: URL or text content
            ttl_seconds: Time to live in seconds
            metadata: Additional metadata for the item
        
        Returns:
            str: Generated item ID
        """
        self._ensure_connected()
        
        try:
            # Generate unique item ID
            item_id = self._generate_item_id()
            
            # Create item data
            item_data = {
                "id": item_id,
                "sender": sender,
                "group_id": group_id,
                "type": item_type.value,
                "content": content,
                "expiry": (datetime.utcnow() + timedelta(seconds=ttl_seconds)).isoformat(),
                "created_at": datetime.utcnow().isoformat(),
                "metadata": metadata or {}
            }
            
            # Store item with TTL using SETEX
            item_key = self._get_item_key(item_id)
            await self.redis.setex(
                item_key, 
                ttl_seconds, 
                json.dumps(item_data)
            )
            
            # Add to group items set (with same TTL)
            group_key = self._get_group_key(group_id)
            await self.redis.sadd(group_key, item_id)
            await self.redis.expire(group_key, ttl_seconds)
            
            # Add to sender items set (with same TTL)
            sender_key = self._get_sender_key(sender)
            await self.redis.sadd(sender_key, item_id)
            await self.redis.expire(sender_key, ttl_seconds)
            
            # Add to type items set (with same TTL)
            type_key = self._get_type_key(item_type)
            await self.redis.sadd(type_key, item_id)
            await self.redis.expire(type_key, ttl_seconds)
            
            logger.info(f"Item {item_id} saved with TTL {ttl_seconds}s")
            return item_id
            
        except Exception as e:
            logger.error(f"Failed to save item: {e}")
            raise
    
    async def get_item(self, item_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific item by ID
        
        Args:
            item_id: ID of the item to retrieve
        
        Returns:
            Dict containing item data or None if not found/expired
        """
        self._ensure_connected()
        
        try:
            item_key = self._get_item_key(item_id)
            item_data = await self.redis.get(item_key)
            
            if not item_data:
                return None
            
            # Parse JSON data
            item_dict = json.loads(item_data)
            
            # Check if item has expired
            expiry_str = item_dict.get("expiry")
            if expiry_str:
                expiry_time = datetime.fromisoformat(expiry_str)
                if datetime.utcnow() > expiry_time:
                    # Item has expired, clean it up
                    await self.delete_item(item_id)
                    return None
            
            return item_dict
            
        except Exception as e:
            logger.error(f"Failed to get item {item_id}: {e}")
            return None
    
    async def get_items(self, group_id: str) -> List[Dict[str, Any]]:
        """
        Get all items for a specific group
        
        Args:
            group_id: ID of the group to get items for
        
        Returns:
            List of item dictionaries
        """
        self._ensure_connected()
        
        try:
            group_key = self._get_group_key(group_id)
            item_ids = await self.redis.smembers(group_key)
            
            if not item_ids:
                return []
            
            items = []
            expired_items = []
            
            # Get each item and check for expiry
            for item_id in item_ids:
                item_data = await self.get_item(item_id)
                if item_data:
                    items.append(item_data)
                else:
                    # Item was expired and cleaned up
                    expired_items.append(item_id)
            
            # Clean up expired items from group set
            if expired_items:
                await self.redis.srem(group_key, *expired_items)
            
            # Sort by creation time (newest first)
            items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
            
            logger.info(f"Retrieved {len(items)} items for group {group_id}")
            return items
            
        except Exception as e:
            logger.error(f"Failed to get items for group {group_id}: {e}")
            return []
    
    async def get_items_by_sender(self, sender: str) -> List[Dict[str, Any]]:
        """
        Get all items sent by a specific sender
        
        Args:
            sender: ID of the sender
        
        Returns:
            List of item dictionaries
        """
        self._ensure_connected()
        
        try:
            sender_key = self._get_sender_key(sender)
            item_ids = await self.redis.smembers(sender_key)
            
            if not item_ids:
                return []
            
            items = []
            expired_items = []
            
            for item_id in item_ids:
                item_data = await self.get_item(item_id)
                if item_data:
                    items.append(item_data)
                else:
                    expired_items.append(item_id)
            
            # Clean up expired items from sender set
            if expired_items:
                await self.redis.srem(sender_key, *expired_items)
            
            items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
            return items
            
        except Exception as e:
            logger.error(f"Failed to get items for sender {sender}: {e}")
            return []
    
    async def get_items_by_type(self, item_type: ItemType) -> List[Dict[str, Any]]:
        """
        Get all items of a specific type
        
        Args:
            item_type: Type of items to retrieve
        
        Returns:
            List of item dictionaries
        """
        self._ensure_connected()
        
        try:
            type_key = self._get_type_key(item_type)
            item_ids = await self.redis.smembers(type_key)
            
            if not item_ids:
                return []
            
            items = []
            expired_items = []
            
            for item_id in item_ids:
                item_data = await self.get_item(item_id)
                if item_data:
                    items.append(item_data)
                else:
                    expired_items.append(item_id)
            
            # Clean up expired items from type set
            if expired_items:
                await self.redis.srem(type_key, *expired_items)
            
            items.sort(key=lambda x: x.get("created_at", ""), reverse=True)
            return items
            
        except Exception as e:
            logger.error(f"Failed to get items for type {item_type}: {e}")
            return []
    
    async def delete_item(self, item_id: str) -> bool:
        """
        Delete an item by ID
        
        Args:
            item_id: ID of the item to delete
        
        Returns:
            bool: True if deleted, False if not found
        """
        self._ensure_connected()
        
        try:
            # Get item data first to know which sets to clean up
            item_data = await self.get_item(item_id)
            if not item_data:
                return False
            
            # Delete the item
            item_key = self._get_item_key(item_id)
            await self.redis.delete(item_key)
            
            # Remove from all sets
            group_key = self._get_group_key(item_data["group_id"])
            sender_key = self._get_sender_key(item_data["sender"])
            type_key = self._get_type_key(ItemType(item_data["type"]))
            
            await self.redis.srem(group_key, item_id)
            await self.redis.srem(sender_key, item_id)
            await self.redis.srem(type_key, item_id)
            
            logger.info(f"Item {item_id} deleted successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete item {item_id}: {e}")
            return False
    
    async def cleanup_expired_items(self) -> int:
        """
        Manually clean up expired items
        
        Returns:
            int: Number of items cleaned up
        """
        self._ensure_connected()
        
        try:
            # Get all item keys
            pattern = "item:*"
            keys = await self.redis.keys(pattern)
            cleaned_count = 0
            
            for key in keys:
                item_data = await self.redis.get(key)
                if item_data:
                    item_dict = json.loads(item_data)
                    expiry_str = item_dict.get("expiry")
                    
                    if expiry_str:
                        expiry_time = datetime.fromisoformat(expiry_str)
                        if datetime.utcnow() > expiry_time:
                            item_id = item_dict["id"]
                            await self.delete_item(item_id)
                            cleaned_count += 1
            
            logger.info(f"Cleaned up {cleaned_count} expired items")
            return cleaned_count
            
        except Exception as e:
            logger.error(f"Failed to cleanup expired items: {e}")
            return 0
    
    async def get_group_stats(self, group_id: str) -> Dict[str, Any]:
        """
        Get statistics for a group
        
        Args:
            group_id: ID of the group
        
        Returns:
            Dict containing group statistics
        """
        self._ensure_connected()
        
        try:
            items = await self.get_items(group_id)
            
            # Count by type
            type_counts = {}
            for item in items:
                item_type = item.get("type", "unknown")
                type_counts[item_type] = type_counts.get(item_type, 0) + 1
            
            # Count by sender
            sender_counts = {}
            for item in items:
                sender = item.get("sender", "unknown")
                sender_counts[sender] = sender_counts.get(sender, 0) + 1
            
            return {
                "total_items": len(items),
                "type_counts": type_counts,
                "sender_counts": sender_counts,
                "group_id": group_id
            }
            
        except Exception as e:
            logger.error(f"Failed to get group stats for {group_id}: {e}")
            return {"total_items": 0, "type_counts": {}, "sender_counts": {}, "group_id": group_id}
    
    async def get_storage_info(self) -> Dict[str, Any]:
        """
        Get storage service information
        
        Returns:
            Dict containing storage info
        """
        self._ensure_connected()
        
        try:
            # Get Redis info
            info = await self.redis.info()
            
            # Count total items
            pattern = "item:*"
            item_keys = await self.redis.keys(pattern)
            total_items = len(item_keys)
            
            # Count groups
            group_pattern = "group:*:items"
            group_keys = await self.redis.keys(group_pattern)
            total_groups = len(group_keys)
            
            return {
                "connected": self._connected,
                "total_items": total_items,
                "total_groups": total_groups,
                "redis_memory_used": info.get("used_memory_human", "unknown"),
                "redis_connected_clients": info.get("connected_clients", 0),
                "redis_uptime": info.get("uptime_in_seconds", 0)
            }
            
        except Exception as e:
            logger.error(f"Failed to get storage info: {e}")
            return {
                "connected": self._connected,
                "total_items": 0,
                "total_groups": 0,
                "error": str(e)
            }


# Global storage service instance
storage_service = StorageService()
