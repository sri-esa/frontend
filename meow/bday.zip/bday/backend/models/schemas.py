from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime, date
from enum import Enum


class ItemType(str, Enum):
    IMAGE = "image"
    DOODLE = "doodle"
    TEXT_NOTE = "text_note"
    VOICE_NOTE = "voice_note"


class ExpiryTime(str, Enum):
    ONE_HOUR = "1h"
    THREE_HOURS = "3h"
    SIX_HOURS = "6h"
    TWELVE_HOURS = "12h"
    TWENTY_FOUR_HOURS = "24h"


class BaseItem(BaseModel):
    id: str
    sender_id: str
    recipient_id: str
    item_type: ItemType
    created_at: datetime
    expires_at: datetime
    is_active: bool = True


class ImageItem(BaseItem):
    item_type: ItemType = ItemType.IMAGE
    image_url: str
    caption: Optional[str] = None
    location: Optional[Dict[str, float]] = None  # lat, lng


class DoodleItem(BaseItem):
    item_type: ItemType = ItemType.DOODLE
    original_image_url: str
    doodle_data: str  # JSON string of drawing data
    caption: Optional[str] = None


class TextNoteItem(BaseItem):
    item_type: ItemType = ItemType.TEXT_NOTE
    content: str
    font_size: Optional[int] = 16
    text_color: Optional[str] = "#000000"
    background_color: Optional[str] = "#FFFFFF"


class VoiceNoteItem(BaseItem):
    item_type: ItemType = ItemType.VOICE_NOTE
    audio_url: str
    duration: float  # in seconds
    transcript: Optional[str] = None


class ItemCreate(BaseModel):
    recipient_id: str
    item_type: ItemType
    expiry: ExpiryTime = ExpiryTime.TWENTY_FOUR_HOURS
    caption: Optional[str] = None
    location: Optional[Dict[str, float]] = None


class ImageCreate(ItemCreate):
    item_type: ItemType = ItemType.IMAGE


class DoodleCreate(ItemCreate):
    item_type: ItemType = ItemType.DOODLE
    original_image_url: str
    doodle_data: str


class TextNoteCreate(ItemCreate):
    item_type: ItemType = ItemType.TEXT_NOTE
    content: str
    font_size: Optional[int] = 16
    text_color: Optional[str] = "#000000"
    background_color: Optional[str] = "#FFFFFF"


class VoiceNoteCreate(ItemCreate):
    item_type: ItemType = ItemType.VOICE_NOTE
    duration: float
    transcript: Optional[str] = None


class ItemResponse(BaseModel):
    id: str
    sender_id: str
    recipient_id: str
    item_type: ItemType
    created_at: datetime
    expires_at: datetime
    is_active: bool
    data: Dict[str, Any]  # Item-specific data


class ItemListResponse(BaseModel):
    items: List[ItemResponse]
    total_count: int
    active_count: int


class WebSocketMessage(BaseModel):
    type: str
    data: Dict[str, Any]
    sender_id: str
    recipient_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class NotificationData(BaseModel):
    title: str
    body: str
    data: Optional[Dict[str, Any]] = None
    recipient_id: str


class HealthResponse(BaseModel):
    status: str
    redis: bool
    firebase: bool
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class AuthToken(BaseModel):
    token: str
    user_id: str


class FileUploadResponse(BaseModel):
    file_id: str
    file_url: str
    file_size: int
    content_type: str


# Birthday Schemas
class BirthdayBase(BaseModel):
    user_id: str
    birthday_date: date
    age: Optional[int] = None


class BirthdayCreate(BirthdayBase):
    created_by: str


class BirthdayUpdate(BaseModel):
    birthday_date: Optional[date] = None
    age: Optional[int] = None


class BirthdayResponse(BirthdayBase):
    id: int
    created_by: str

    class Config:
        orm_mode = True


# FCM Schemas
class FCMTokenCreate(BaseModel):
    user_id: str
    token: str


class FCMTokenResponse(FCMTokenCreate):
    id: int

    class Config:
        orm_mode = True
