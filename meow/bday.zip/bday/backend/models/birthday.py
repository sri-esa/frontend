from sqlalchemy import Column, Integer, String, Date
from database import Base

class BirthdayReminder(Base):
    __tablename__ = "birthday_reminders"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, unique=True, index=True, nullable=False)
    created_by = Column(String, nullable=False)
    birthday_date = Column(Date, nullable=False)
    age = Column(Integer, nullable=True)
