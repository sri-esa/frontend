from sqlalchemy import Column, Integer, String, ForeignKey
from database import Base

class FCMToken(Base):
    __tablename__ = "fcm_tokens"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, index=True, nullable=False)
    token = Column(String, unique=True, nullable=False)
