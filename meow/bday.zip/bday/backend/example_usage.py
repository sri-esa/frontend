"""
Example usage of StorageService
This demonstrates how to use the StorageService in your application
"""
import asyncio
from services.storage import StorageService, ItemType


async def main():
    """Example usage of StorageService"""
    
    # Initialize the storage service
    storage = StorageService("redis://localhost:6379/0")
    
    try:
        # Connect to Redis
        await storage.connect()
        print("Connected to Redis!")
        
        # Example: Save a snap
        snap_id = await storage.save_item(
            sender="alice123",
            group_id="friends_group",
            item_type=ItemType.SNAP,
            content="https://example.com/sunset.jpg",
            ttl_seconds=3600,  # 1 hour
            metadata={
                "caption": "Beautiful sunset at the beach!",
                "location": {"lat": 40.7128, "lng": -74.0060},
                "filters": ["vintage", "warm"]
            }
        )
        print(f"Saved snap: {snap_id}")
        
        # Example: Save a text note
        text_id = await storage.save_item(
            sender="bob456",
            group_id="friends_group",
            item_type=ItemType.TEXT,
            content="Hey everyone! Just wanted to share this amazing recipe I found...",
            ttl_seconds=7200,  # 2 hours
            metadata={
                "font_size": 18,
                "color": "#2E8B57",
                "background": "#F0F8FF"
            }
        )
        print(f"Saved text note: {text_id}")
        
        # Example: Save a voice note
        voice_id = await storage.save_item(
            sender="charlie789",
            group_id="friends_group",
            item_type=ItemType.VOICE,
            content="https://example.com/voice_notes/morning_greeting.mp3",
            ttl_seconds=1800,  # 30 minutes
            metadata={
                "duration": 23.5,
                "transcript": "Good morning everyone! Hope you all have a great day ahead.",
                "quality": "high"
            }
        )
        print(f"Saved voice note: {voice_id}")
        
        # Example: Get all items in the group
        group_items = await storage.get_items("friends_group")
        print(f"\nFound {len(group_items)} items in friends_group:")
        
        for item in group_items:
            print(f"  - {item['type'].upper()}: {item['content'][:50]}...")
            print(f"    Sender: {item['sender']}, Expires: {item['expiry']}")
            print()
        
        # Example: Get items by sender
        alice_items = await storage.get_items_by_sender("alice123")
        print(f"Alice has {len(alice_items)} items")
        
        # Example: Get items by type
        voice_items = await storage.get_items_by_type(ItemType.VOICE)
        print(f"Found {len(voice_items)} voice notes")
        
        # Example: Get group statistics
        stats = await storage.get_group_stats("friends_group")
        print(f"\nGroup statistics:")
        print(f"  Total items: {stats['total_items']}")
        print(f"  By type: {stats['type_counts']}")
        print(f"  By sender: {stats['sender_counts']}")
        
        # Example: Delete an item
        print(f"\nDeleting text note: {text_id}")
        deleted = await storage.delete_item(text_id)
        print(f"Deleted successfully: {deleted}")
        
        # Verify deletion
        remaining_items = await storage.get_items("friends_group")
        print(f"Remaining items: {len(remaining_items)}")
        
        # Example: Get storage information
        info = await storage.get_storage_info()
        print(f"\nStorage info:")
        print(f"  Total items: {info['total_items']}")
        print(f"  Total groups: {info['total_groups']}")
        print(f"  Redis memory: {info['redis_memory_used']}")
        
    except Exception as e:
        print(f"Error: {e}")
    
    finally:
        # Always disconnect
        await storage.disconnect()
        print("\nDisconnected from Redis")


if __name__ == "__main__":
    print("StorageService Example Usage")
    print("=" * 40)
    asyncio.run(main())
