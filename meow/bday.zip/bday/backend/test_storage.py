"""
Test script for StorageService
Run with: python test_storage.py
"""
import asyncio
import json
from services.storage import StorageService, ItemType
from datetime import datetime, timedelta


async def test_storage_service():
    """Test the StorageService functionality"""
    
    # Initialize storage service
    storage = StorageService("redis://localhost:6379/0")
    
    try:
        # Connect to Redis
        await storage.connect()
        print("✅ Connected to Redis")
        
        # Test data
        sender = "user123"
        group_id = "group456"
        
        print("\n🧪 Testing StorageService...")
        
        # Test 1: Save different types of items
        print("\n1. Saving items...")
        
        snap_id = await storage.save_item(
            sender=sender,
            group_id=group_id,
            item_type=ItemType.SNAP,
            content="https://example.com/snap1.jpg",
            ttl_seconds=3600,  # 1 hour
            metadata={"caption": "Beautiful sunset!", "location": {"lat": 40.7128, "lng": -74.0060}}
        )
        print(f"   📸 Saved snap: {snap_id}")
        
        doodle_id = await storage.save_item(
            sender=sender,
            group_id=group_id,
            item_type=ItemType.DOODLE,
            content="https://example.com/doodle1.json",
            ttl_seconds=7200,  # 2 hours
            metadata={"original_image": "https://example.com/original.jpg", "brush_color": "#FF0000"}
        )
        print(f"   🎨 Saved doodle: {doodle_id}")
        
        voice_id = await storage.save_item(
            sender=sender,
            group_id=group_id,
            item_type=ItemType.VOICE,
            content="https://example.com/voice1.mp3",
            ttl_seconds=1800,  # 30 minutes
            metadata={"duration": 45.5, "transcript": "Hello, this is a voice note!"}
        )
        print(f"   🎤 Saved voice note: {voice_id}")
        
        text_id = await storage.save_item(
            sender=sender,
            group_id=group_id,
            item_type=ItemType.TEXT,
            content="This is a text note with some important information!",
            ttl_seconds=14400,  # 4 hours
            metadata={"font_size": 16, "color": "#000000"}
        )
        print(f"   📝 Saved text note: {text_id}")
        
        # Test 2: Get items by group
        print("\n2. Getting items by group...")
        group_items = await storage.get_items(group_id)
        print(f"   Found {len(group_items)} items in group {group_id}")
        for item in group_items:
            print(f"   - {item['type']}: {item['id']} (expires: {item['expiry']})")
        
        # Test 3: Get specific item
        print("\n3. Getting specific item...")
        snap_item = await storage.get_item(snap_id)
        if snap_item:
            print(f"   📸 Snap details: {json.dumps(snap_item, indent=2)}")
        else:
            print("   ❌ Snap not found")
        
        # Test 4: Get items by sender
        print("\n4. Getting items by sender...")
        sender_items = await storage.get_items_by_sender(sender)
        print(f"   Found {len(sender_items)} items from sender {sender}")
        
        # Test 5: Get items by type
        print("\n5. Getting items by type...")
        snap_items = await storage.get_items_by_type(ItemType.SNAP)
        print(f"   Found {len(snap_items)} snap items")
        
        # Test 6: Group statistics
        print("\n6. Getting group statistics...")
        stats = await storage.get_group_stats(group_id)
        print(f"   Group stats: {json.dumps(stats, indent=2)}")
        
        # Test 7: Storage info
        print("\n7. Getting storage info...")
        info = await storage.get_storage_info()
        print(f"   Storage info: {json.dumps(info, indent=2)}")
        
        # Test 8: Delete an item
        print("\n8. Deleting an item...")
        deleted = await storage.delete_item(voice_id)
        print(f"   Voice note deleted: {deleted}")
        
        # Verify deletion
        voice_item = await storage.get_item(voice_id)
        print(f"   Voice note still exists: {voice_item is not None}")
        
        # Test 9: Get updated group items
        print("\n9. Getting updated group items...")
        updated_items = await storage.get_items(group_id)
        print(f"   Found {len(updated_items)} items after deletion")
        
        # Test 10: Cleanup expired items (if any)
        print("\n10. Cleaning up expired items...")
        cleaned = await storage.cleanup_expired_items()
        print(f"   Cleaned up {cleaned} expired items")
        
        print("\n✅ All tests completed successfully!")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Disconnect
        await storage.disconnect()
        print("\n🔌 Disconnected from Redis")


async def test_ttl_expiry():
    """Test TTL expiry functionality"""
    print("\n⏰ Testing TTL expiry...")
    
    storage = StorageService("redis://localhost:6379/0")
    
    try:
        await storage.connect()
        
        # Save item with very short TTL
        item_id = await storage.save_item(
            sender="test_user",
            group_id="test_group",
            item_type=ItemType.TEXT,
            content="This will expire soon!",
            ttl_seconds=2  # 2 seconds
        )
        
        print(f"   Saved item with 2-second TTL: {item_id}")
        
        # Check immediately
        item = await storage.get_item(item_id)
        print(f"   Item exists immediately: {item is not None}")
        
        # Wait for expiry
        print("   Waiting 3 seconds for expiry...")
        await asyncio.sleep(3)
        
        # Check after expiry
        item = await storage.get_item(item_id)
        print(f"   Item exists after expiry: {item is not None}")
        
        # Cleanup
        await storage.cleanup_expired_items()
        
    except Exception as e:
        print(f"❌ TTL test failed: {e}")
    
    finally:
        await storage.disconnect()


if __name__ == "__main__":
    print("🚀 Starting StorageService tests...")
    
    # Run main tests
    asyncio.run(test_storage_service())
    
    # Run TTL tests
    asyncio.run(test_ttl_expiry())
    
    print("\n🎉 All tests completed!")
