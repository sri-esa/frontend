import asyncio
import httpx
from datetime import date

# It's better to use a test-specific configuration
# For now, we'll assume the main app is running and accessible at localhost:8000
BASE_URL = "http://localhost:8000/api/v1"

async def test_create_birthday():
    print("\n🧪 Testing POST /birthdays/")
    async with httpx.AsyncClient() as client:
        test_birthday = {
            "user_id": "test_user_1",
            "created_by": "test_creator_1",
            "birthday_date": "2000-01-01",
            "age": 24
        }
        response = await client.post(f"{BASE_URL}/birthdays/", json=test_birthday)
        if response.status_code == 200:
            print("✅ Birthday created successfully")
            print(response.json())
        else:
            print(f"❌ Failed to create birthday: {response.status_code}")
            print(response.text)

async def test_get_birthday():
    print("\n🧪 Testing GET /birthdays/{user_id}")
    async with httpx.AsyncClient() as client:
        response = await client.get(f"{BASE_URL}/birthdays/test_user_1")
        if response.status_code == 200:
            print("✅ Birthday retrieved successfully")
            print(response.json())
        else:
            print(f"❌ Failed to retrieve birthday: {response.status_code}")
            print(response.text)

async def main():
    await test_create_birthday()
    await test_get_birthday()

if __name__ == "__main__":
    print("🚀 Starting Birthday API tests...")
    asyncio.run(main())
    print("\n🎉 All tests completed!")
