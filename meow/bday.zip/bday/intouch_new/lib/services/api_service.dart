import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static ApiService? _instance;
  static ApiService get instance => _instance ??= ApiService._();
  
  ApiService._();

  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://localhost:8000/api/v1',
  );
  String? _authToken;

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    _authToken = prefs.getString('auth_token');
  }

  Future<void> setAuthToken(String token) async {
    _authToken = token;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
  }

  Future<void> clearAuthToken() async {
    _authToken = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
  }

  Map<String, String> get _headers {
    final headers = {
      'Content-Type': 'application/json',
    };
    
    if (_authToken != null) {
      headers['Authorization'] = 'Bearer $_authToken';
    }
    
    return headers;
  }

  // Groups API
  Future<List<Map<String, dynamic>>> getGroups() async {
    final response = await http.get(
      Uri.parse('$baseUrl/groups'),
      headers: _headers,
    );
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return List<Map<String, dynamic>>.from(data['groups']);
    } else {
      throw Exception('Failed to load groups: ${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> createGroup(String name, {String? description}) async {
    final response = await http.post(
      Uri.parse('$baseUrl/groups'),
      headers: _headers,
      body: jsonEncode({
        'name': name,
        'description': description,
      }),
    );
    
    if (response.statusCode == 201) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to create group: ${response.statusCode}');
    }
  }

  Future<void> joinGroup(String groupCode) async {
    final response = await http.post(
      Uri.parse('$baseUrl/groups/join'),
      headers: _headers,
      body: jsonEncode({
        'group_code': groupCode,
      }),
    );
    
    if (response.statusCode != 200) {
      throw Exception('Failed to join group: ${response.statusCode}');
    }
  }

  // Items API
  Future<List<Map<String, dynamic>>> getItems(String groupId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/items?group_id=$groupId'),
      headers: _headers,
    );
    
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return List<Map<String, dynamic>>.from(data['items']);
    } else {
      throw Exception('Failed to load items: ${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> uploadImage(
    String groupId,
    File imageFile,
    String ttl,
  ) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/items/image'),
    );
    
    request.headers.addAll(_headers);
    request.fields['group_id'] = groupId;
    request.fields['ttl'] = ttl;
    request.files.add(await http.MultipartFile.fromPath('image', imageFile.path));
    
    final streamedResponse = await request.send();
    final response = await http.Response.fromStream(streamedResponse);
    
    if (response.statusCode == 201) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to upload image: ${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> uploadDoodle(
    String groupId,
    File doodleFile,
    String ttl,
  ) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/items/doodle'),
    );
    
    request.headers.addAll(_headers);
    request.fields['group_id'] = groupId;
    request.fields['ttl'] = ttl;
    request.files.add(await http.MultipartFile.fromPath('image', doodleFile.path));
    
    final streamedResponse = await request.send();
    final response = await http.Response.fromStream(streamedResponse);
    
    if (response.statusCode == 201) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to upload doodle: ${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> uploadVoiceNote(
    String groupId,
    File audioFile,
    String ttl,
  ) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/items/voice'),
    );
    
    request.headers.addAll(_headers);
    request.fields['group_id'] = groupId;
    request.fields['ttl'] = ttl;
    request.files.add(await http.MultipartFile.fromPath('audio', audioFile.path));
    
    final streamedResponse = await request.send();
    final response = await http.Response.fromStream(streamedResponse);
    
    if (response.statusCode == 201) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to upload voice note: ${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> createTextNote(
    String groupId,
    String content,
    String ttl,
  ) async {
    final response = await http.post(
      Uri.parse('$baseUrl/items/text'),
      headers: _headers,
      body: jsonEncode({
        'group_id': groupId,
        'content': content,
        'ttl': ttl,
      }),
    );
    
    if (response.statusCode == 201) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to create text note: ${response.statusCode}');
    }
  }

  Future<void> deleteItem(String itemId) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/items/$itemId'),
      headers: _headers,
    );
    
    if (response.statusCode != 200) {
      throw Exception('Failed to delete item: ${response.statusCode}');
    }
  }

  // Health check
  Future<bool> healthCheck() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/health'),
        headers: _headers,
      );
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }
}
