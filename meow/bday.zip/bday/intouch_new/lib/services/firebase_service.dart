
import 'dart:typed_data';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:go_router/go_router.dart';

class FirebaseService {
  static FirebaseService? _instance;
  static FirebaseService get instance => _instance ??= FirebaseService._();
  
  FirebaseService._();

  late firebase_auth.FirebaseAuth _auth;
  late FirebaseMessaging _messaging;
  late firebase_storage.FirebaseStorage _storage;
  late GoRouter _router;

  Future<void> initialize(GoRouter router) async {
    await Firebase.initializeApp();
    
    _auth = firebase_auth.FirebaseAuth.instance;
    _messaging = FirebaseMessaging.instance;
    _storage = firebase_storage.FirebaseStorage.instance;
    _router = router;
    
    // Configure messaging
    await _configureMessaging();
  }

  Future<void> _configureMessaging() async {
    // Request permission for notifications
    await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    // Configure foreground message handling
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);
    
    // Configure background message handling
    FirebaseMessaging.onBackgroundMessage(_handleBackgroundMessage);
    
    // Configure message opened app
    FirebaseMessaging.onMessageOpenedApp.listen(_handleMessageOpenedApp);
  }

  static Future<void> _handleBackgroundMessage(RemoteMessage message) async {
    // Handle background message
    print('Background message: ${message.messageId}');
  }

  void _handleForegroundMessage(RemoteMessage message) {
    // Handle foreground message
    print('Foreground message: ${message.messageId}');
    _navigateToBirthdayPage(message);
  }

  void _handleMessageOpenedApp(RemoteMessage message) {
    // Handle message opened app
    print('Message opened app: ${message.messageId}');
    _navigateToBirthdayPage(message);
  }

  void _navigateToBirthdayPage(RemoteMessage message) {
    if (message.data['type'] == 'birthday') {
      final String name = message.data['name'] ?? 'User';
      final String age = message.data['age'] ?? '18';
      _router.go('/birthday?name=$name&age=$age');
    }
  }

  // Auth methods
  firebase_auth.FirebaseAuth get auth => _auth;
  
  // Messaging methods
  FirebaseMessaging get messaging => _messaging;
  
  Future<String?> getFCMToken() async {
    return await _messaging.getToken();
  }
  
  Future<void> subscribeToTopic(String topic) async {
    await _messaging.subscribeToTopic(topic);
  }
  
  Future<void> unsubscribeFromTopic(String topic) async {
    await _messaging.unsubscribeFromTopic(topic);
  }
  
  // Storage methods
  firebase_storage.FirebaseStorage get storage => _storage;
  
  Future<String> uploadFile(String path, List<int> data) async {
    final ref = _storage.ref().child(path);
    final uploadTask = ref.putData(Uint8List.fromList(data));
    final snapshot = await uploadTask;
    return await snapshot.ref.getDownloadURL();
  }
  
  Future<void> deleteFile(String path) async {
    final ref = _storage.ref().child(path);
    await ref.delete();
  }
}
