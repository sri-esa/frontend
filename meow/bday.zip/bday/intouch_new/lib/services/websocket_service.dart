import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;

class WebSocketService {
  static WebSocketService? _instance;
  static WebSocketService get instance => _instance ??= WebSocketService._();
  
  WebSocketService._();

  WebSocketChannel? _channel;
  StreamController<Map<String, dynamic>>? _messageController;
  StreamController<bool>? _connectionController;
  Timer? _heartbeatTimer;
  Timer? _reconnectTimer;
  
  bool _isConnected = false;
  String? _token;
  String? _userId;
  Set<String> _joinedGroups = {};

  // Getters
  bool get isConnected => _isConnected;
  Stream<Map<String, dynamic>> get messageStream => 
      _messageController?.stream ?? const Stream.empty();
  Stream<bool> get connectionStream => 
      _connectionController?.stream ?? const Stream.empty();

  Future<void> initialize() async {
    _messageController = StreamController<Map<String, dynamic>>.broadcast();
    _connectionController = StreamController<bool>.broadcast();
  }

  Future<void> connect(String token, String userId) async {
    if (_isConnected) return;
    
    _token = token;
    _userId = userId;
    
    try {
      _channel = WebSocketChannel.connect(
        Uri.parse('ws://localhost:8000/api/v1/ws?token=$token'),
      );
      
      _channel!.stream.listen(
        _handleMessage,
        onError: _handleError,
        onDone: _handleDisconnect,
      );
      
      _isConnected = true;
      _connectionController?.add(true);
      _startHeartbeat();
      
    } catch (e) {
      _handleError(e);
    }
  }

  Future<void> disconnect() async {
    if (!_isConnected) return;
    
    _stopHeartbeat();
    _stopReconnect();
    
    await _channel?.sink.close(status.goingAway);
    _channel = null;
    
    _isConnected = false;
    _connectionController?.add(false);
    _joinedGroups.clear();
  }

  Future<void> joinGroup(String groupId) async {
    if (!_isConnected) return;
    
    _sendMessage({
      'type': 'join_group',
      'data': {'group_id': groupId},
    });
    
    _joinedGroups.add(groupId);
  }

  Future<void> leaveGroup(String groupId) async {
    if (!_isConnected) return;
    
    _sendMessage({
      'type': 'leave_group',
      'data': {'group_id': groupId},
    });
    
    _joinedGroups.remove(groupId);
  }

  Future<void> sendMessage(String type, Map<String, dynamic> data) async {
    if (!_isConnected) return;
    
    _sendMessage({
      'type': type,
      'data': data,
    });
  }

  void _sendMessage(Map<String, dynamic> message) {
    if (_channel != null) {
      _channel!.sink.add(jsonEncode(message));
    }
  }

  void _handleMessage(dynamic message) {
    try {
      final Map<String, dynamic> data = jsonDecode(message);
      _messageController?.add(data);
    } catch (e) {
      print('Error parsing WebSocket message: $e');
    }
  }

  void _handleError(dynamic error) {
    print('WebSocket error: $error');
    _isConnected = false;
    _connectionController?.add(false);
    _startReconnect();
  }

  void _handleDisconnect() {
    print('WebSocket disconnected');
    _isConnected = false;
    _connectionController?.add(false);
    _startReconnect();
  }

  void _startHeartbeat() {
    _heartbeatTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      if (_isConnected) {
        _sendMessage({
          'type': 'ping',
          'data': {},
        });
      }
    });
  }

  void _stopHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = null;
  }

  void _startReconnect() {
    if (_reconnectTimer != null) return;
    
    _reconnectTimer = Timer.periodic(const Duration(seconds: 5), (timer) async {
      if (!_isConnected && _token != null && _userId != null) {
        try {
          await connect(_token!, _userId!);
          
          // Rejoin groups
          for (final groupId in _joinedGroups) {
            await joinGroup(groupId);
          }
          
          timer.cancel();
        } catch (e) {
          print('Reconnect failed: $e');
        }
      }
    });
  }

  void _stopReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = null;
  }

  void dispose() {
    disconnect();
    _messageController?.close();
    _connectionController?.close();
  }
}
