class Validators {
  // Email validation
  static bool isValidEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }
  
  // Phone number validation (basic)
  static bool isValidPhoneNumber(String phone) {
    return RegExp(r'^\+?[1-9]\d{1,14}$').hasMatch(phone.replaceAll(' ', ''));
  }
  
  // Group name validation
  static bool isValidGroupName(String name) {
    return name.trim().isNotEmpty && name.length >= 2 && name.length <= 50;
  }
  
  // Text content validation
  static bool isValidTextContent(String content) {
    return content.trim().isNotEmpty && content.length <= 1000;
  }
  
  // TTL validation
  static bool isValidTTL(String ttl) {
    return ['1h', '6h', '12h', '24h'].contains(ttl);
  }
  
  // Group code validation
  static bool isValidGroupCode(String code) {
    return code.trim().isNotEmpty && code.length >= 4 && code.length <= 10;
  }
  
  // File size validation
  static bool isValidImageSize(int sizeInBytes) {
    const maxSize = 10 * 1024 * 1024; // 10MB
    return sizeInBytes <= maxSize;
  }
  
  static bool isValidAudioSize(int sizeInBytes) {
    const maxSize = 50 * 1024 * 1024; // 50MB
    return sizeInBytes <= maxSize;
  }
  
  // Display name validation
  static bool isValidDisplayName(String name) {
    return name.trim().isNotEmpty && name.length <= 30;
  }
  
  // Password validation (if needed for future features)
  static bool isValidPassword(String password) {
    return password.length >= 8 && password.length <= 128;
  }
  
  // URL validation
  static bool isValidUrl(String url) {
    try {
      Uri.parse(url);
      return true;
    } catch (e) {
      return false;
    }
  }
  
  // Generic string validation
  static bool isNotEmpty(String? value) {
    return value != null && value.trim().isNotEmpty;
  }
  
  // Number validation
  static bool isValidNumber(String value) {
    return double.tryParse(value) != null;
  }
  
  // Positive number validation
  static bool isValidPositiveNumber(String value) {
    final number = double.tryParse(value);
    return number != null && number > 0;
  }
}
