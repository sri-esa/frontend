class AppConstants {
  // API Configuration
  static const String baseUrl = 'http://localhost:8000/api/v1';
  static const String wsUrl = 'ws://localhost:8000/api/v1/ws';
  
  // Storage Keys
  static const String authTokenKey = 'auth_token';
  static const String userIdKey = 'user_id';
  static const String selectedGroupKey = 'selected_group';
  static const String selectedTTLKey = 'selected_ttl';
  
  // TTL Options
  static const List<String> ttlOptions = [
    '1h',
    '6h',
    '12h',
    '24h',
  ];
  
  // TTL Display Names
  static const Map<String, String> ttlDisplayNames = {
    '1h': '1 Hour',
    '6h': '6 Hours',
    '12h': '12 Hours',
    '24h': '24 Hours',
  };
  
  // Item Types
  static const List<String> itemTypes = [
    'snap',
    'doodle',
    'voice',
    'text',
  ];
  
  // File Upload Limits
  static const int maxImageSizeMB = 10;
  static const int maxAudioSizeMB = 50;
  static const int maxTextLength = 1000;
  
  // Animation Durations
  static const Duration shortAnimation = Duration(milliseconds: 200);
  static const Duration mediumAnimation = Duration(milliseconds: 300);
  static const Duration longAnimation = Duration(milliseconds: 500);
  
  // UI Constants
  static const double defaultPadding = 16.0;
  static const double smallPadding = 8.0;
  static const double largePadding = 24.0;
  
  static const double defaultBorderRadius = 8.0;
  static const double cardBorderRadius = 12.0;
  
  // WebSocket
  static const Duration heartbeatInterval = Duration(seconds: 30);
  static const Duration reconnectInterval = Duration(seconds: 5);
  static const int maxReconnectAttempts = 10;
  
  // Widget
  static const String widgetName = 'SnapShareWidget';
  static const String androidWidgetName = 'SnapShareWidgetProvider';
}
