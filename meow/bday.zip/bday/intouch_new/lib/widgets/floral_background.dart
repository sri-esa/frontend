
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class FloralBackground extends StatelessWidget {
  final Widget child;
  final bool enableFlowers;
  final bool enableConfetti;

  const FloralBackground({
    super.key,
    required this.child,
    this.enableFlowers = true,
    this.enableConfetti = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFFFFF3B0), // Pastel Yellow
            Color(0xFFFFFFFF), // Soft White
            Color(0xFFFFD6E0), // Frangipani Pink
          ],
        ),
      ),
      child: Stack(
        children: [
          if (enableFlowers)
            Positioned.fill(
              child: Lottie.asset(
                'assets/animations/floating_flowers.json',
                fit: BoxFit.cover,
              ),
            ),
          if (enableConfetti)
            Positioned.fill(
              child: Lottie.asset(
                'assets/animations/confetti.json',
                fit: BoxFit.cover,
              ),
            ),
          Scaffold(
            backgroundColor: Colors.transparent,
            body: child,
          ),
        ],
      ),
    );
  }
}
