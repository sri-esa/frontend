enum ItemType {
  snap,
  doodle,
  voice,
  text,
}

class Item {
  final String id;
  final String senderId;
  final String groupId;
  final ItemType type;
  final String content;
  final DateTime createdAt;
  final DateTime expiresAt;
  final bool isActive;
  final Map<String, dynamic> metadata;

  const Item({
    required this.id,
    required this.senderId,
    required this.groupId,
    required this.type,
    required this.content,
    required this.createdAt,
    required this.expiresAt,
    this.isActive = true,
    this.metadata = const {},
  });

  factory Item.fromJson(Map<String, dynamic> json) {
    return Item(
      id: json['id'] as String,
      senderId: json['senderId'] as String,
      groupId: json['groupId'] as String,
      type: ItemType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => ItemType.text,
      ),
      content: json['content'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      expiresAt: DateTime.parse(json['expiresAt'] as String),
      isActive: json['isActive'] as bool? ?? true,
      metadata: Map<String, dynamic>.from(json['metadata'] as Map? ?? {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'senderId': senderId,
      'groupId': groupId,
      'type': type.name,
      'content': content,
      'createdAt': createdAt.toIso8601String(),
      'expiresAt': expiresAt.toIso8601String(),
      'isActive': isActive,
      'metadata': metadata,
    };
  }

  bool get isExpired => DateTime.now().isAfter(expiresAt);

  Duration get timeUntilExpiry => expiresAt.difference(DateTime.now());

  String get timeUntilExpiryString {
    final duration = timeUntilExpiry;
    if (duration.isNegative) return 'Expired';
    
    if (duration.inDays > 0) {
      return '${duration.inDays}d ${duration.inHours % 24}h';
    } else if (duration.inHours > 0) {
      return '${duration.inHours}h ${duration.inMinutes % 60}m';
    } else {
      return '${duration.inMinutes}m';
    }
  }

  Item copyWith({
    String? id,
    String? senderId,
    String? groupId,
    ItemType? type,
    String? content,
    DateTime? createdAt,
    DateTime? expiresAt,
    bool? isActive,
    Map<String, dynamic>? metadata,
  }) {
    return Item(
      id: id ?? this.id,
      senderId: senderId ?? this.senderId,
      groupId: groupId ?? this.groupId,
      type: type ?? this.type,
      content: content ?? this.content,
      createdAt: createdAt ?? this.createdAt,
      expiresAt: expiresAt ?? this.expiresAt,
      isActive: isActive ?? this.isActive,
      metadata: metadata ?? this.metadata,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Item && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() {
    return 'Item(id: $id, type: ${type.name}, senderId: $senderId, groupId: $groupId)';
  }
}
