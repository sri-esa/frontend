import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/entities/group.dart';
import '../../domain/entities/item.dart';

// State
class HomeState {
  final List<Group> groups;
  final List<Item> recentItems;
  final bool isLoadingGroups;
  final bool isLoadingItems;
  final String? error;

  const HomeState({
    this.groups = const [],
    this.recentItems = const [],
    this.isLoadingGroups = false,
    this.isLoadingItems = false,
    this.error,
  });

  HomeState copyWith({
    List<Group>? groups,
    List<Item>? recentItems,
    bool? isLoadingGroups,
    bool? isLoadingItems,
    String? error,
  }) {
    return HomeState(
      groups: groups ?? this.groups,
      recentItems: recentItems ?? this.recentItems,
      isLoadingGroups: isLoadingGroups ?? this.isLoadingGroups,
      isLoadingItems: isLoadingItems ?? this.isLoadingItems,
      error: error ?? this.error,
    );
  }
}

// Provider
final homeProvider = StateNotifierProvider<HomeNotifier, HomeState>((ref) {
  return HomeNotifier();
});

// Notifier
class HomeNotifier extends StateNotifier<HomeState> {
  HomeNotifier() : super(const HomeState());

  Future<void> loadGroups() async {
    state = state.copyWith(isLoadingGroups: true, error: null);
    
    try {
      // TODO: Implement actual API call
      await Future.delayed(const Duration(seconds: 1)); // Simulate API call
      
      // Mock data for now
      final groups = [
        Group(
          id: '1',
          name: 'Family',
          description: 'Family group chat',
          memberIds: ['user1', 'user2', 'user3'],
          createdBy: 'user1',
          createdAt: DateTime.now().subtract(const Duration(days: 7)),
          updatedAt: DateTime.now().subtract(const Duration(hours: 2)),
        ),
        Group(
          id: '2',
          name: 'Friends',
          description: 'College friends',
          memberIds: ['user1', 'user4', 'user5'],
          createdBy: 'user1',
          createdAt: DateTime.now().subtract(const Duration(days: 3)),
          updatedAt: DateTime.now().subtract(const Duration(minutes: 30)),
        ),
      ];
      
      state = state.copyWith(groups: groups, isLoadingGroups: false);
    } catch (e) {
      state = state.copyWith(isLoadingGroups: false, error: e.toString());
    }
  }

  Future<void> loadRecentItems() async {
    state = state.copyWith(isLoadingItems: true, error: null);
    
    try {
      // TODO: Implement actual API call
      await Future.delayed(const Duration(seconds: 1)); // Simulate API call
      
      // Mock data for now
      final items = [
        Item(
          id: '1',
          senderId: 'user2',
          groupId: '1',
          type: ItemType.snap,
          content: 'https://example.com/snap1.jpg',
          createdAt: DateTime.now().subtract(const Duration(minutes: 30)),
          expiresAt: DateTime.now().add(const Duration(hours: 23, minutes: 30)),
          metadata: {'caption': 'Beautiful sunset!'},
        ),
        Item(
          id: '2',
          senderId: 'user4',
          groupId: '2',
          type: ItemType.text,
          content: 'Hey everyone! How are you doing?',
          createdAt: DateTime.now().subtract(const Duration(hours: 2)),
          expiresAt: DateTime.now().add(const Duration(hours: 22)),
          metadata: {'fontSize': 16, 'color': '#000000'},
        ),
        Item(
          id: '3',
          senderId: 'user3',
          groupId: '1',
          type: ItemType.voice,
          content: 'https://example.com/voice1.mp3',
          createdAt: DateTime.now().subtract(const Duration(hours: 4)),
          expiresAt: DateTime.now().add(const Duration(hours: 20)),
          metadata: {'duration': 45.5, 'transcript': 'Hello from voice note!'},
        ),
      ];
      
      state = state.copyWith(recentItems: items, isLoadingItems: false);
    } catch (e) {
      state = state.copyWith(isLoadingItems: false, error: e.toString());
    }
  }

  Future<void> refreshData() async {
    await Future.wait([
      loadGroups(),
      loadRecentItems(),
    ]);
  }

  Future<void> deleteItem(String itemId) async {
    try {
      // TODO: Implement actual API call
      await Future.delayed(const Duration(milliseconds: 500)); // Simulate API call
      
      final updatedItems = state.recentItems
          .where((item) => item.id != itemId)
          .toList();
      
      state = state.copyWith(recentItems: updatedItems);
    } catch (e) {
      state = state.copyWith(error: e.toString());
      rethrow;
    }
  }

  void clearError() {
    state = state.copyWith(error: null);
  }
}
