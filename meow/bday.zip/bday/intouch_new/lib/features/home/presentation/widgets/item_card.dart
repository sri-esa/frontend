import 'package:flutter/material.dart';
import '../../domain/entities/item.dart';

class ItemCard extends StatelessWidget {
  final Item item;
  final VoidCallback? onTap;
  final VoidCallback? onDelete;

  const ItemCard({
    super.key,
    required this.item,
    this.onTap,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: [
              // Item type icon
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: _getTypeColor().withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  _getTypeIcon(),
                  color: _getTypeColor(),
                  size: 24,
                ),
              ),
              
              const SizedBox(width: 12),
              
              // Item content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _getTypeDisplayName(),
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: _getTypeColor(),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _getContentPreview(),
                      style: Theme.of(context).textTheme.bodyMedium,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.access_time,
                          size: 14,
                          color: Colors.grey[600],
                        ),
                        const SizedBox(width: 4),
                        Text(
                          item.timeUntilExpiryString,
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: item.isExpired ? Colors.red : Colors.grey[600],
                            fontWeight: item.isExpired ? FontWeight.bold : FontWeight.normal,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          _formatTime(item.createdAt),
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              // Action button
              if (onDelete != null)
                IconButton(
                  onPressed: onDelete,
                  icon: const Icon(Icons.more_vert),
                  color: Colors.grey[600],
                ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _getTypeIcon() {
    switch (item.type) {
      case ItemType.snap:
        return Icons.camera_alt;
      case ItemType.doodle:
        return Icons.brush;
      case ItemType.voice:
        return Icons.mic;
      case ItemType.text:
        return Icons.text_fields;
    }
  }

  Color _getTypeColor() {
    switch (item.type) {
      case ItemType.snap:
        return Colors.blue;
      case ItemType.doodle:
        return Colors.purple;
      case ItemType.voice:
        return Colors.orange;
      case ItemType.text:
        return Colors.green;
    }
  }

  String _getTypeDisplayName() {
    switch (item.type) {
      case ItemType.snap:
        return 'Photo';
      case ItemType.doodle:
        return 'Doodle';
      case ItemType.voice:
        return 'Voice Note';
      case ItemType.text:
        return 'Text Note';
    }
  }

  String _getContentPreview() {
    switch (item.type) {
      case ItemType.snap:
        return '📸 Photo';
      case ItemType.doodle:
        return '🎨 Doodle';
      case ItemType.voice:
        final duration = item.metadata['duration'] as double?;
        return duration != null 
            ? '🎤 Voice note (${duration.toStringAsFixed(1)}s)'
            : '🎤 Voice note';
      case ItemType.text:
        return item.content;
    }
  }

  String _formatTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }
}
