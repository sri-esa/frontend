import '../entities/user.dart';

abstract class AuthRepository {
  /// Get current user
  Future<User?> getCurrentUser();
  
  /// Sign in anonymously
  Future<User> signInAnonymously();
  
  /// Sign in with phone number (OTP)
  Future<void> sendOTP(String phoneNumber);
  Future<User> verifyOTP(String phoneNumber, String otp);
  
  /// Sign out
  Future<void> signOut();
  
  /// Listen to auth state changes
  Stream<User?> get authStateChanges;
  
  /// Check if user is signed in
  Future<bool> isSignedIn();
  
  /// Get Firebase ID token
  Future<String?> getIdToken();
  
  /// Refresh ID token
  Future<String?> refreshIdToken();
}
