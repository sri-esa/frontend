import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;

abstract class FirebaseAuthDataSource {
  Future<firebase_auth.User?> getCurrentUser();
  Future<firebase_auth.User> signInAnonymously();
  Future<void> sendOTP(String phoneNumber);
  Future<firebase_auth.User> verifyOTP(String phoneNumber, String otp);
  Future<void> signOut();
  Stream<firebase_auth.User?> get authStateChanges;
  Future<bool> isSignedIn();
  Future<String?> getIdToken();
  Future<String?> refreshIdToken();
}

class FirebaseAuthDataSourceImpl implements FirebaseAuthDataSource {
  final firebase_auth.FirebaseAuth _firebaseAuth;

  FirebaseAuthDataSourceImpl(this._firebaseAuth);

  @override
  Future<firebase_auth.User?> getCurrentUser() async {
    return _firebaseAuth.currentUser;
  }

  @override
  Future<firebase_auth.User> signInAnonymously() async {
    final userCredential = await _firebaseAuth.signInAnonymously();
    return userCredential.user!;
  }

  @override
  Future<void> sendOTP(String phoneNumber) async {
    await _firebaseAuth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (phoneAuthCredential) {
        // Auto-verification completed
      },
      verificationFailed: (error) {
        throw Exception('Verification failed: ${error.message}');
      },
      codeSent: (verificationId, resendToken) {
        // Store verification ID for later use
        // In a real app, you'd store this in secure storage
      },
      codeAutoRetrievalTimeout: (verificationId) {
        // Auto-retrieval timeout
      },
    );
  }

  @override
  Future<firebase_auth.User> verifyOTP(String phoneNumber, String otp) async {
    // In a real implementation, you'd retrieve the verification ID from storage
    // and use it to create the credential
    final credential = firebase_auth.PhoneAuthProvider.credential(
      verificationId: 'stored_verification_id', // This should be stored securely
      smsCode: otp,
    );
    
    final userCredential = await _firebaseAuth.signInWithCredential(credential);
    return userCredential.user!;
  }

  @override
  Future<void> signOut() async {
    await _firebaseAuth.signOut();
  }

  @override
  Stream<firebase_auth.User?> get authStateChanges {
    return _firebaseAuth.authStateChanges();
  }

  @override
  Future<bool> isSignedIn() async {
    return _firebaseAuth.currentUser != null;
  }

  @override
  Future<String?> getIdToken() async {
    return await _firebaseAuth.currentUser?.getIdToken();
  }

  @override
  Future<String?> refreshIdToken() async {
    return await _firebaseAuth.currentUser?.getIdToken(true);
  }
}
