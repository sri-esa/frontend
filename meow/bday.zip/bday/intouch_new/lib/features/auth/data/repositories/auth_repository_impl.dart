import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import '../../domain/entities/user.dart';
import '../../domain/repositories/auth_repository.dart';
import '../datasources/firebase_auth_datasource.dart';

class AuthRepositoryImpl implements AuthRepository {
  final FirebaseAuthDataSource _dataSource;

  AuthRepositoryImpl(this._dataSource);

  @override
  Future<User?> getCurrentUser() async {
    final firebaseUser = await _dataSource.getCurrentUser();
    return firebaseUser != null ? _mapFirebaseUserToUser(firebaseUser) : null;
  }

  @override
  Future<User> signInAnonymously() async {
    final firebaseUser = await _dataSource.signInAnonymously();
    return _mapFirebaseUserToUser(firebaseUser);
  }

  @override
  Future<void> sendOTP(String phoneNumber) async {
    await _dataSource.sendOTP(phoneNumber);
  }

  @override
  Future<User> verifyOTP(String phoneNumber, String otp) async {
    final firebaseUser = await _dataSource.verifyOTP(phoneNumber, otp);
    return _mapFirebaseUserToUser(firebaseUser);
  }

  @override
  Future<void> signOut() async {
    await _dataSource.signOut();
  }

  @override
  Stream<User?> get authStateChanges {
    return _dataSource.authStateChanges.map((firebaseUser) {
      return firebaseUser != null ? _mapFirebaseUserToUser(firebaseUser) : null;
    });
  }

  @override
  Future<bool> isSignedIn() async {
    return await _dataSource.isSignedIn();
  }

  @override
  Future<String?> getIdToken() async {
    return await _dataSource.getIdToken();
  }

  @override
  Future<String?> refreshIdToken() async {
    return await _dataSource.refreshIdToken();
  }

  User _mapFirebaseUserToUser(firebase_auth.User firebaseUser) {
    return User(
      id: firebaseUser.uid,
      email: firebaseUser.email,
      displayName: firebaseUser.displayName,
      photoUrl: firebaseUser.photoURL,
      isAnonymous: firebaseUser.isAnonymous,
      createdAt: firebaseUser.metadata.creationTime ?? DateTime.now(),
      lastSignInAt: firebaseUser.metadata.lastSignInTime,
    );
  }
}
