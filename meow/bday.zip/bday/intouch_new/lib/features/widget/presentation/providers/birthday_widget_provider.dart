
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:home_widget/home_widget.dart';

final birthdayWidgetProvider = StateNotifierProvider<BirthdayWidgetNotifier, bool>((ref) {
  return BirthdayWidgetNotifier();
});

class BirthdayWidgetNotifier extends StateNotifier<bool> {
  BirthdayWidgetNotifier() : super(false);

  Future<void> updateBirthday(String name, int age) async {
    await HomeWidget.saveWidgetData('birthday_name', name);
    await HomeWidget.saveWidgetData('birthday_age', age.toString());
    await HomeWidget.saveWidgetData('is_birthday', true);
    await HomeWidget.updateWidget(
      name: 'InTouchWidget',
      androidName: 'InTouchWidgetProvider',
    );
    state = true;
  }

  Future<void> clearBirthday() async {
    await HomeWidget.saveWidgetData('is_birthday', false);
    await HomeWidget.updateWidget(
      name: 'InTouchWidget',
      androidName: 'InTouchWidgetProvider',
    );
    state = false;
  }
}
