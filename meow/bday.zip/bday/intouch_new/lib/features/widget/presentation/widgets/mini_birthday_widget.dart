
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import '../../../../../widgets/floral_background.dart';
import '../../../home/domain/entities/birthday.dart';

class MiniBirthdayWidget extends StatelessWidget {
  final Birthday birthday;

  const MiniBirthdayWidget({super.key, required this.birthday});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final birthdayDate = birthday.date;
    final isBirthdayToday = now.day == birthdayDate.day && now.month == birthdayDate.month;
    final daysUntilBirthday = birthdayDate.isBefore(now)
        ? DateTime(now.year + 1, birthdayDate.month, birthdayDate.day).difference(now).inDays
        : birthdayDate.difference(now).inDays;

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: isBirthdayToday
          ? _CelebrationView(name: birthday.name)
          : _CountdownView(name: birthday.name, days: daysUntilBirthday),
    );
  }
}

class _CountdownView extends StatelessWidget {
  final String name;
  final int days;

  const _CountdownView({required this.name, required this.days});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            '$days',
            style: const TextStyle(
              fontSize: 48,
              fontWeight: FontWeight.bold,
              color: Colors.pink,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'days until', 
            style: const TextStyle(fontSize: 16),
          ),
          Text(
            '$name\'s birthday',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _CelebrationView extends StatelessWidget {
  final String name;

  const _CelebrationView({required this.name});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: FloralBackground(
        enableConfetti: true,
        child: Stack(
          children: [
            Lottie.asset(
              'assets/animations/balloons.json',
              fit: BoxFit.cover,
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Happy Birthday',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    name,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {},
                    child: const Text('Send a Gift'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

