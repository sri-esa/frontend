
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:home_widget/home_widget.dart';

import '../providers/birthday_widget_provider.dart';

class WidgetSettingsPage extends ConsumerStatefulWidget {
  const WidgetSettingsPage({super.key});

  @override
  ConsumerState<WidgetSettingsPage> createState() => _WidgetSettingsPageState();
}

class _WidgetSettingsPageState extends ConsumerState<WidgetSettingsPage> {
  bool _isWidgetEnabled = false;
  String _selectedGroup = 'family';
  String _selectedTTL = '24h';

  @override
  void initState() {
    super.initState();
    _loadWidgetSettings();
  }

  Future<void> _loadWidgetSettings() async {
    try {
      final isEnabled = await HomeWidget.getWidgetData<bool>('is_enabled', defaultValue: false);
      final group = await HomeWidget.getWidgetData<String>('selected_group', defaultValue: 'family');
      final ttl = await HomeWidget.getWidgetData<String>('selected_ttl', defaultValue: '24h');
      
      setState(() {
        _isWidgetEnabled = isEnabled;
        _selectedGroup = group;
        _selectedTTL = ttl;
      });
    } catch (e) {
      print('Error loading widget settings: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isBirthday = ref.watch(birthdayWidgetProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Widget Settings'),
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.arrow_back),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Widget preview
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.widgets,
                          color: Theme.of(context).primaryColor,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Home Screen Widget',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Add a widget to your home screen for quick access to create and share content.',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.grey[600],
                      ),
                    ),
                    const SizedBox(height: 16),
                    isBirthday ? _buildBirthdayWidgetPreview() : _buildWidgetPreview(),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 24),
            
            // Settings
            Text(
              'Widget Settings',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Enable widget toggle
            SwitchListTile(
              title: const Text('Enable Home Screen Widget'),
              subtitle: const Text('Add widget to home screen for quick access'),
              value: _isWidgetEnabled,
              onChanged: (value) {
                setState(() {
                  _isWidgetEnabled = value;
                });
                _saveWidgetSettings();
              },
            ),
            
            const Divider(),
            
            // Group selection
            ListTile(
              title: const Text('Default Group'),
              subtitle: Text('Share to: $_selectedGroup'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: _showGroupSelector,
            ),
            
            const Divider(),
            
            // TTL selection
            ListTile(
              title: const Text('Default Expiry'),
              subtitle: Text('Content expires in: $_selectedTTL'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: _showTTLSelector,
            ),

            const Divider(),

            // Test birthday button
            ListTile(
              title: const Text('Test Birthday'),
              subtitle: const Text('Simulate a birthday event'),
              trailing: const Icon(Icons.cake),
              onTap: () {
                ref.read(birthdayWidgetProvider.notifier).updateBirthday('Alex', 25);
              },
            ),
            
            const Spacer(),
            
            // Instructions
            Card(
              color: Colors.blue.withOpacity(0.1),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.info,
                          color: Colors.blue[700],
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'How to add widget',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.blue[700],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '1. Long press on your home screen\n'
                      '2. Tap "Widgets" or the "+" button\n'
                      '3. Find "InTouch" and add it\n'
                      '4. Configure the widget settings',
                      style: TextStyle(
                        color: Colors.blue[700],
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWidgetPreview() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                Icons.camera_alt,
                color: Colors.grey[600],
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Quick Snap',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(
                Icons.brush,
                color: Colors.grey[600],
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Quick Doodle',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(
                Icons.mic,
                color: Colors.grey[600],
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Quick Voice',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[700],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBirthdayWidgetPreview() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFFFFFDE7), // Pastel Yellow
            Colors.white,
            Color(0xFFFFEBEE), // Soft Pink
          ],
        ),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.pink.shade100),
      ),
      child: const Center(
        child: Text(
          '🎉 Happy 25th Birthday, Alex! 🎉',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.pink,
          ),
        ),
      ),
    );
  }

  void _showGroupSelector() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Default Group'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile<String>(
              title: const Text('Family'),
              value: 'family',
              groupValue: _selectedGroup,
              onChanged: (value) {
                setState(() {
                  _selectedGroup = value!;
                });
                Navigator.of(context).pop();
                _saveWidgetSettings();
              },
            ),
            RadioListTile<String>(
              title: const Text('Friends'),
              value: 'friends',
              groupValue: _selectedGroup,
              onChanged: (value) {
                setState(() {
                  _selectedGroup = value!;
                });
                Navigator.of(context).pop();
                _saveWidgetSettings();
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showTTLSelector() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Default Expiry'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile<String>(
              title: const Text('1 Hour'),
              value: '1h',
              groupValue: _selectedTTL,
              onChanged: (value) {
                setState(() {
                  _selectedTTL = value!;
                });
                Navigator.of(context).pop();
                _saveWidgetSettings();
              },
            ),
            RadioListTile<String>(
              title: const Text('6 Hours'),
              value: '6h',
              groupValue: _selectedTTL,
              onChanged: (value) {
                setState(() {
                  _selectedTTL = value!;
                });
                Navigator.of(context).pop();
                _saveWidgetSettings();
              },
            ),
            RadioListTile<String>(
              title: const Text('12 Hours'),
              value: '12h',
              groupValue: _selectedTTL,
              onChanged: (value) {
                setState(() {
                  _selectedTTL = value!;
                });
                Navigator.of(context).pop();
                _saveWidgetSettings();
              },
            ),
            RadioListTile<String>(
              title: const Text('24 Hours'),
              value: '24h',
              groupValue: _selectedTTL,
              onChanged: (value) {
                setState(() {
                  _selectedTTL = value!;
                });
                Navigator.of(context).pop();
                _saveWidgetSettings();
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _saveWidgetSettings() async {
    try {
      await HomeWidget.saveWidgetData('is_enabled', _isWidgetEnabled);
      await HomeWidget.saveWidgetData('selected_group', _selectedGroup);
      await HomeWidget.saveWidgetData('selected_ttl', _selectedTTL);
      
      // Update the widget
      await HomeWidget.updateWidget(
        name: 'InTouchWidget',
        androidName: 'InTouchWidgetProvider',
      );
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Widget settings saved!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save settings: $e')),
        );
      }
    }
  }
}
