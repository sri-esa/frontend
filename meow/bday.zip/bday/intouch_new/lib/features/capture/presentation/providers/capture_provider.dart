import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:io';

// State
class CaptureState {
  final String? imagePath;
  final String? doodlePath;
  final String? voicePath;
  final String? textContent;
  final String selectedTTL;
  final String selectedGroupId;
  final bool isRecording;
  final bool isProcessing;
  final String? error;

  const CaptureState({
    this.imagePath,
    this.doodlePath,
    this.voicePath,
    this.textContent,
    this.selectedTTL = '24h',
    this.selectedGroupId = 'family',
    this.isRecording = false,
    this.isProcessing = false,
    this.error,
  });

  bool get hasContent => 
      imagePath != null || 
      doodlePath != null || 
      voicePath != null || 
      (textContent != null && textContent!.isNotEmpty);

  CaptureState copyWith({
    String? imagePath,
    String? doodlePath,
    String? voicePath,
    String? textContent,
    String? selectedTTL,
    String? selectedGroupId,
    bool? isRecording,
    bool? isProcessing,
    String? error,
  }) {
    return CaptureState(
      imagePath: imagePath ?? this.imagePath,
      doodlePath: doodlePath ?? this.doodlePath,
      voicePath: voicePath ?? this.voicePath,
      textContent: textContent ?? this.textContent,
      selectedTTL: selectedTTL ?? this.selectedTTL,
      selectedGroupId: selectedGroupId ?? this.selectedGroupId,
      isRecording: isRecording ?? this.isRecording,
      isProcessing: isProcessing ?? this.isProcessing,
      error: error ?? this.error,
    );
  }
}

// Provider
final captureProvider = StateNotifierProvider<CaptureNotifier, CaptureState>((ref) {
  return CaptureNotifier();
});

// Notifier
class CaptureNotifier extends StateNotifier<CaptureState> {
  CaptureNotifier() : super(const CaptureState());

  void setImagePath(String? path) {
    state = state.copyWith(imagePath: path);
  }

  void setDoodlePath(String? path) {
    state = state.copyWith(doodlePath: path);
  }

  void setVoicePath(String? path) {
    state = state.copyWith(voicePath: path);
  }

  void setTextContent(String? content) {
    state = state.copyWith(textContent: content);
  }

  void setTTL(String ttl) {
    state = state.copyWith(selectedTTL: ttl);
  }

  void setGroup(String groupId) {
    state = state.copyWith(selectedGroupId: groupId);
  }

  void setRecording(bool recording) {
    state = state.copyWith(isRecording: recording);
  }

  void setProcessing(bool processing) {
    state = state.copyWith(isProcessing: processing);
  }

  void clearContent() {
    state = state.copyWith(
      imagePath: null,
      doodlePath: null,
      voicePath: null,
      textContent: null,
      error: null,
    );
  }

  Future<void> shareContent() async {
    if (!state.hasContent) {
      throw Exception('No content to share');
    }

    state = state.copyWith(isProcessing: true, error: null);

    try {
      // TODO: Implement actual API call to upload content
      await Future.delayed(const Duration(seconds: 2)); // Simulate upload
      
      // Reset state after successful upload
      state = state.copyWith(
        isProcessing: false,
        imagePath: null,
        doodlePath: null,
        voicePath: null,
        textContent: null,
      );
    } catch (e) {
      state = state.copyWith(isProcessing: false, error: e.toString());
      rethrow;
    }
  }

  void clearError() {
    state = state.copyWith(error: null);
  }
}
