
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_painter/image_painter.dart';
import 'dart:typed_data';
import 'dart:ui' as ui;
import '../providers/capture_provider.dart';

class DoodleCanvas extends ConsumerStatefulWidget {
  const DoodleCanvas({super.key});

  @override
  ConsumerState<DoodleCanvas> createState() => _DoodleCanvasState();
}

class _DoodleCanvasState extends ConsumerState<DoodleCanvas> {
  final ImagePainterController _imageController = ImagePainterController();
  Color _color = Colors.black;
  double _brushSize = 3.0;

  @override
  void initState() {
    super.initState();
    _imageController.setColor(_color);
    _imageController.setStrokeWidth(_brushSize);
  }

  @override
  void dispose() {
    _imageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Toolbar
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // Brush size
              Column(
                children: [
                  const Text('Brush Size'),
                  Slider(
                    value: _brushSize,
                    min: 1.0,
                    max: 10.0,
                    divisions: 9,
                    onChanged: (value) {
                      setState(() {
                        _brushSize = value;
                        _imageController.setStrokeWidth(value);
                      });
                    },
                  ),
                ],
              ),
              
              // Color picker
              Column(
                children: [
                  const Text('Color'),
                  Row(
                    children: [
                      _buildColorButton(Colors.black),
                      _buildColorButton(Colors.red),
                      _buildColorButton(Colors.blue),
                      _buildColorButton(Colors.green),
                      _buildColorButton(Colors.orange),
                      _buildColorButton(Colors.purple),
                    ],
                  ),
                ],
              ),
              
              // Tools
              Row(
                children: [
                  IconButton(
                    onPressed: _clearCanvas,
                    icon: const Icon(Icons.clear),
                    tooltip: 'Clear',
                  ),
                  IconButton(
                    onPressed: _undo,
                    icon: const Icon(Icons.undo),
                    tooltip: 'Undo',
                  ),
                ],
              ),
            ],
          ),
        ),
        
        // Canvas
        Expanded(
          child: Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: ImagePainter.asset(
                'assets/images/blank_canvas.png', // You'll need to add this asset
                controller: _imageController,
              ),
            ),
          ),
        ),
        
        // Action buttons
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _loadImage,
                  icon: const Icon(Icons.image),
                  label: const Text('Load Image'),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () async {
                      final imageData = await _imageController.exportImage();
                      _saveDoodle(imageData);
                    },
                  icon: const Icon(Icons.save),
                  label: const Text('Save Doodle'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildColorButton(Color color) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _color = color;
          _imageController.setColor(color);
        });
      },
      child: Container(
        width: 32,
        height: 32,
        margin: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(
            color: _color == color ? Colors.black : Colors.grey[400]!,
            width: 2,
          ),
        ),
      ),
    );
  }

  void _clearCanvas() {
    _imageController.clear();
  }

  void _undo() {
    _imageController.undo();
  }

  void _loadImage() {
    // TODO: Implement image picker
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Image picker coming soon')),
    );
  }

  Future<void> _saveDoodle([Uint8List? imageData]) async {
    try {
      if (imageData != null) {
        // Save the doodle data to the provider
        ref.read(captureProvider.notifier).setDoodlePath('doodle_${DateTime.now().millisecondsSinceEpoch}.png');
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Doodle saved successfully!')),
          );
        }
      } else {
         if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Nothing to save. Draw something first!')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save doodle: $e')),
        );
      }
    }
  }
}
