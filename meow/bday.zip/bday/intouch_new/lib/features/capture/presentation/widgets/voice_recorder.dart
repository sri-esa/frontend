import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'dart:io';
import '../providers/capture_provider.dart';

class VoiceRecorder extends ConsumerStatefulWidget {
  const VoiceRecorder({super.key});

  @override
  ConsumerState<VoiceRecorder> createState() => _VoiceRecorderState();
}

class _VoiceRecorderState extends ConsumerState<VoiceRecorder> {
  FlutterSoundRecorder? _recorder;
  FlutterSoundPlayer? _player;
  bool _isRecording = false;
  bool _isPlaying = false;
  Duration _recordingDuration = Duration.zero;
  String? _recordingPath;
  double _recordingLevel = 0.0;

  @override
  void initState() {
    super.initState();
    _initializeRecorder();
  }

  @override
  void dispose() {
    _recorder?.closeRecorder();
    _player?.closePlayer();
    super.dispose();
  }

  Future<void> _initializeRecorder() async {
    _recorder = FlutterSoundRecorder();
    _player = FlutterSoundPlayer();
    
    await _recorder!.openRecorder();
    await _player!.openPlayer();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Recording visualization
          Container(
            width: 200,
            height: 200,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _isRecording 
                  ? Colors.red.withOpacity(0.1)
                  : Colors.grey.withOpacity(0.1),
              border: Border.all(
                color: _isRecording ? Colors.red : Colors.grey,
                width: 3,
              ),
            ),
            child: Center(
              child: Icon(
                _isRecording ? Icons.mic : Icons.mic_none,
                size: 80,
                color: _isRecording ? Colors.red : Colors.grey,
              ),
            ),
          ),
          
          const SizedBox(height: 32),
          
          // Recording duration
          Text(
            _formatDuration(_recordingDuration),
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: _isRecording ? Colors.red : Colors.grey[600],
            ),
          ),
          
          const SizedBox(height: 16),
          
          // Recording level indicator
          if (_isRecording) ...[
            Text(
              'Recording Level: ${(_recordingLevel * 100).toInt()}%',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: _recordingLevel,
              backgroundColor: Colors.grey[300],
              valueColor: AlwaysStoppedAnimation<Color>(
                _recordingLevel > 0.8 ? Colors.red : Colors.green,
              ),
            ),
            const SizedBox(height: 24),
          ],
          
          // Control buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              // Record/Stop button
              GestureDetector(
                onTap: _isRecording ? _stopRecording : _startRecording,
                child: Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _isRecording ? Colors.red : Colors.blue,
                    boxShadow: [
                      BoxShadow(
                        color: (_isRecording ? Colors.red : Colors.blue).withOpacity(0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Icon(
                    _isRecording ? Icons.stop : Icons.mic,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
              ),
              
              // Play/Pause button
              if (_recordingPath != null)
                GestureDetector(
                  onTap: _isPlaying ? _stopPlaying : _startPlaying,
                  child: Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _isPlaying ? Colors.orange : Colors.green,
                    ),
                    child: Icon(
                      _isPlaying ? Icons.stop : Icons.play_arrow,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                ),
            ],
          ),
          
          const SizedBox(height: 32),
          
          // Recording info
          if (_recordingPath != null) ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.green.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  const Icon(
                    Icons.check_circle,
                    color: Colors.green,
                    size: 32,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Recording saved!',
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Duration: ${_formatDuration(_recordingDuration)}',
                    style: const TextStyle(
                      color: Colors.green,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Action buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _deleteRecording,
                    icon: const Icon(Icons.delete),
                    label: const Text('Delete'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _saveRecording,
                    icon: const Icon(Icons.save),
                    label: const Text('Save'),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _startRecording() async {
    try {
      await _recorder!.startRecorder(
        toFile: 'recording_${DateTime.now().millisecondsSinceEpoch}.aac',
        codec: Codec.aacADTS,
        sampleRate: 44100,
      );
      
      setState(() {
        _isRecording = true;
        _recordingDuration = Duration.zero;
      });
      
      // Start duration timer
      _startDurationTimer();
      
      // Start level monitoring
      _startLevelMonitoring();
      
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to start recording: $e')),
        );
      }
    }
  }

  Future<void> _stopRecording() async {
    try {
      final path = await _recorder!.stopRecorder();
      
      setState(() {
        _isRecording = false;
        _recordingPath = path;
      });
      
      // Save the recording path to the provider
      ref.read(captureProvider.notifier).setVoicePath(path);
      
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to stop recording: $e')),
        );
      }
    }
  }

  Future<void> _startPlaying() async {
    if (_recordingPath == null) return;
    
    try {
      await _player!.startPlayer(
        fromURI: _recordingPath!,
        codec: Codec.aacADTS,
      );
      
      setState(() {
        _isPlaying = true;
      });
      
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to start playing: $e')),
        );
      }
    }
  }

  Future<void> _stopPlaying() async {
    try {
      await _player!.stopPlayer();
      
      setState(() {
        _isPlaying = false;
      });
      
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to stop playing: $e')),
        );
      }
    }
  }

  void _startDurationTimer() {
    Future.delayed(const Duration(seconds: 1), () {
      if (_isRecording && mounted) {
        setState(() {
          _recordingDuration = Duration(seconds: _recordingDuration.inSeconds + 1);
        });
        _startDurationTimer();
      }
    });
  }

  void _startLevelMonitoring() {
    // In a real implementation, you'd monitor the recording level
    // For now, we'll simulate it
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_isRecording && mounted) {
        setState(() {
          _recordingLevel = (DateTime.now().millisecondsSinceEpoch % 100) / 100.0;
        });
        _startLevelMonitoring();
      }
    });
  }

  void _deleteRecording() {
    setState(() {
      _recordingPath = null;
      _recordingDuration = Duration.zero;
      _isPlaying = false;
    });
    
    ref.read(captureProvider.notifier).setVoicePath(null);
  }

  void _saveRecording() {
    if (_recordingPath != null) {
      ref.read(captureProvider.notifier).setVoicePath(_recordingPath);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Voice note saved successfully!')),
        );
      }
    }
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$minutes:$seconds';
  }
}
