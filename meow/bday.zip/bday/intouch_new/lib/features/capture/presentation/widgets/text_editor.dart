import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/capture_provider.dart';

class TextEditor extends ConsumerStatefulWidget {
  const TextEditor({super.key});

  @override
  ConsumerState<TextEditor> createState() => _TextEditorState();
}

class _TextEditorState extends ConsumerState<TextEditor> {
  final TextEditingController _textController = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  double _fontSize = 16.0;
  Color _textColor = Colors.black;
  TextAlign _textAlign = TextAlign.left;
  FontWeight _fontWeight = FontWeight.normal;
  FontStyle _fontStyle = FontStyle.normal;

  @override
  void initState() {
    super.initState();
    _textController.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    _textController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onTextChanged() {
    ref.read(captureProvider.notifier).setTextContent(_textController.text);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Toolbar
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              // Font size slider
              Row(
                children: [
                  const Text('Font Size: '),
                  Expanded(
                    child: Slider(
                      value: _fontSize,
                      min: 12.0,
                      max: 32.0,
                      divisions: 20,
                      onChanged: (value) {
                        setState(() {
                          _fontSize = value;
                        });
                      },
                    ),
                  ),
                  Text('${_fontSize.toInt()}'),
                ],
              ),
              
              // Text alignment
              Row(
                children: [
                  const Text('Alignment: '),
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildAlignmentButton(Icons.format_align_left, TextAlign.left),
                        _buildAlignmentButton(Icons.format_align_center, TextAlign.center),
                        _buildAlignmentButton(Icons.format_align_right, TextAlign.right),
                        _buildAlignmentButton(Icons.format_align_justify, TextAlign.justify),
                      ],
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 8),
              
              // Text style options
              Row(
                children: [
                  const Text('Style: '),
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildStyleButton('Bold', Icons.format_bold, () {
                          setState(() {
                            _fontWeight = _fontWeight == FontWeight.bold 
                                ? FontWeight.normal 
                                : FontWeight.bold;
                          });
                        }),
                        _buildStyleButton('Italic', Icons.format_italic, () {
                          setState(() {
                            _fontStyle = _fontStyle == FontStyle.italic 
                                ? FontStyle.normal 
                                : FontStyle.italic;
                          });
                        }),
                        _buildStyleButton('Underline', Icons.format_underlined, () {
                          // TODO: Implement underline
                        }),
                      ],
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 8),
              
              // Color picker
              Row(
                children: [
                  const Text('Color: '),
                  Expanded(
                    child: Row(
                      children: [
                        _buildColorButton(Colors.black),
                        _buildColorButton(Colors.red),
                        _buildColorButton(Colors.blue),
                        _buildColorButton(Colors.green),
                        _buildColorButton(Colors.orange),
                        _buildColorButton(Colors.purple),
                        _buildColorButton(Colors.grey),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        
        // Text editor
        Expanded(
          child: Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(8),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: TextField(
              controller: _textController,
              focusNode: _focusNode,
              maxLines: null,
              expands: true,
              textAlign: _textAlign,
              style: TextStyle(
                fontSize: _fontSize,
                color: _textColor,
                fontWeight: _fontWeight,
                fontStyle: _fontStyle,
              ),
              decoration: const InputDecoration(
                hintText: 'Type your message here...',
                border: InputBorder.none,
                hintStyle: TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                ),
              ),
            ),
          ),
        ),
        
        // Action buttons
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _clearText,
                  icon: const Icon(Icons.clear),
                  label: const Text('Clear'),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _textController.text.isNotEmpty ? _saveText : null,
                  icon: const Icon(Icons.save),
                  label: const Text('Save Text'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAlignmentButton(IconData icon, TextAlign alignment) {
    final isSelected = _textAlign == alignment;
    return GestureDetector(
      onTap: () {
        setState(() {
          _textAlign = alignment;
        });
      },
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: isSelected ? Theme.of(context).primaryColor : Colors.transparent,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Icon(
          icon,
          color: isSelected ? Colors.white : Colors.grey[600],
          size: 20,
        ),
      ),
    );
  }

  Widget _buildStyleButton(String label, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: Colors.grey[300]!),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: Colors.grey[600]),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildColorButton(Color color) {
    final isSelected = _textColor == color;
    return GestureDetector(
      onTap: () {
        setState(() {
          _textColor = color;
        });
      },
      child: Container(
        width: 32,
        height: 32,
        margin: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(
            color: isSelected ? Colors.black : Colors.grey[400]!,
            width: isSelected ? 3 : 2,
          ),
        ),
        child: isSelected
            ? const Icon(
                Icons.check,
                color: Colors.white,
                size: 16,
              )
            : null,
      ),
    );
  }

  void _clearText() {
    _textController.clear();
    ref.read(captureProvider.notifier).setTextContent(null);
  }

  void _saveText() {
    if (_textController.text.isNotEmpty) {
      ref.read(captureProvider.notifier).setTextContent(_textController.text);
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Text note saved successfully!')),
      );
    }
  }
}
