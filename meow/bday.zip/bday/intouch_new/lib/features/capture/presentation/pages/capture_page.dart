import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/capture_provider.dart';
import '../widgets/camera_view.dart';
import '../widgets/doodle_canvas.dart';
import '../widgets/voice_recorder.dart';
import '../widgets/text_editor.dart';

class CapturePage extends ConsumerStatefulWidget {
  const CapturePage({super.key});

  @override
  ConsumerState<CapturePage> createState() => _CapturePageState();
}

class _CapturePageState extends ConsumerState<CapturePage>
    with TickerProviderStateMixin {
  late TabController _tabController;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _selectedIndex = _tabController.index;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final captureState = ref.watch(captureProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Content'),
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.close),
        ),
        actions: [
          if (captureState.hasContent)
            TextButton(
              onPressed: () => _shareContent(),
              child: const Text('Share'),
            ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.camera_alt), text: 'Camera'),
            Tab(icon: Icon(Icons.brush), text: 'Doodle'),
            Tab(icon: Icon(Icons.mic), text: 'Voice'),
            Tab(icon: Icon(Icons.text_fields), text: 'Text'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          CameraView(),
          DoodleCanvas(),
          VoiceRecorder(),
          TextEditor(),
        ],
      ),
      bottomNavigationBar: _buildBottomBar(),
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: [
          // TTL selector
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Expires in:'),
                const SizedBox(height: 4),
                DropdownButton<String>(
                  value: ref.watch(captureProvider).selectedTTL,
                  isExpanded: true,
                  items: const [
                    DropdownMenuItem(value: '1h', child: Text('1 Hour')),
                    DropdownMenuItem(value: '6h', child: Text('6 Hours')),
                    DropdownMenuItem(value: '12h', child: Text('12 Hours')),
                    DropdownMenuItem(value: '24h', child: Text('24 Hours')),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      ref.read(captureProvider.notifier).setTTL(value);
                    }
                  },
                ),
              ],
            ),
          ),
          
          const SizedBox(width: 16),
          
          // Group selector
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Share to:'),
                const SizedBox(height: 4),
                DropdownButton<String>(
                  value: ref.watch(captureProvider).selectedGroupId,
                  isExpanded: true,
                  items: const [
                    DropdownMenuItem(value: 'family', child: Text('Family')),
                    DropdownMenuItem(value: 'friends', child: Text('Friends')),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      ref.read(captureProvider.notifier).setGroup(value);
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _shareContent() async {
    try {
      await ref.read(captureProvider.notifier).shareContent();
      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Content shared successfully!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to share content: $e')),
        );
      }
    }
  }
}
