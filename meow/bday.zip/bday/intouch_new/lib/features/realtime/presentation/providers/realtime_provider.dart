import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:async';
import '../../home/domain/entities/item.dart';
import '../../../services/websocket_service.dart';

// State
class RealtimeState {
  final Map<String, List<Item>> groupItems;
  final Set<String> onlineUsers;
  final bool isConnected;
  final String? error;

  const RealtimeState({
    this.groupItems = const {},
    this.onlineUsers = const {},
    this.isConnected = false,
    this.error,
  });

  RealtimeState copyWith({
    Map<String, List<Item>>? groupItems,
    Set<String>? onlineUsers,
    bool? isConnected,
    String? error,
  }) {
    return RealtimeState(
      groupItems: groupItems ?? this.groupItems,
      onlineUsers: onlineUsers ?? this.onlineUsers,
      isConnected: isConnected ?? this.isConnected,
      error: error ?? this.error,
    );
  }

  List<Item> getItemsForGroup(String groupId) {
    return groupItems[groupId] ?? [];
  }
}

// Provider
final realtimeProvider = StateNotifierProvider<RealtimeNotifier, RealtimeState>((ref) {
  return RealtimeNotifier();
});

// Notifier
class RealtimeNotifier extends StateNotifier<RealtimeState> {
  StreamSubscription? _messageSubscription;
  StreamSubscription? _connectionSubscription;

  RealtimeNotifier() : super(const RealtimeState()) {
    _initializeWebSocket();
  }

  void _initializeWebSocket() {
    final wsService = WebSocketService.instance;
    
    // Listen to connection changes
    _connectionSubscription = wsService.connectionStream.listen((isConnected) {
      state = state.copyWith(isConnected: isConnected);
    });
    
    // Listen to messages
    _messageSubscription = wsService.messageStream.listen(_handleMessage);
  }

  void _handleMessage(Map<String, dynamic> message) {
    final type = message['type'] as String;
    final data = message['data'] as Map<String, dynamic>;

    switch (type) {
      case 'new_item':
        _handleNewItem(data);
        break;
      case 'item_deleted':
        _handleItemDeleted(data);
        break;
      case 'item_expired':
        _handleItemExpired(data);
        break;
      case 'user_joined':
        _handleUserJoined(data);
        break;
      case 'user_left':
        _handleUserLeft(data);
        break;
      case 'pong':
        // Handle ping response
        break;
      case 'error':
        _handleError(data);
        break;
    }
  }

  void _handleNewItem(Map<String, dynamic> data) {
    final groupId = data['group_id'] as String;
    final itemData = data['item'] as Map<String, dynamic>;
    
    try {
      final item = Item.fromJson(itemData);
      
      final currentItems = List<Item>.from(state.groupItems[groupId] ?? []);
      currentItems.insert(0, item); // Add to beginning
      
      final updatedGroupItems = Map<String, List<Item>>.from(state.groupItems);
      updatedGroupItems[groupId] = currentItems;
      
      state = state.copyWith(groupItems: updatedGroupItems);
    } catch (e) {
      state = state.copyWith(error: 'Failed to parse new item: $e');
    }
  }

  void _handleItemDeleted(Map<String, dynamic> data) {
    final groupId = data['group_id'] as String;
    final itemId = data['item_id'] as String;
    
    final currentItems = List<Item>.from(state.groupItems[groupId] ?? []);
    currentItems.removeWhere((item) => item.id == itemId);
    
    final updatedGroupItems = Map<String, List<Item>>.from(state.groupItems);
    updatedGroupItems[groupId] = currentItems;
    
    state = state.copyWith(groupItems: updatedGroupItems);
  }

  void _handleItemExpired(Map<String, dynamic> data) {
    final groupId = data['group_id'] as String;
    final itemId = data['item_id'] as String;
    
    final currentItems = List<Item>.from(state.groupItems[groupId] ?? []);
    currentItems.removeWhere((item) => item.id == itemId);
    
    final updatedGroupItems = Map<String, List<Item>>.from(state.groupItems);
    updatedGroupItems[groupId] = currentItems;
    
    state = state.copyWith(groupItems: updatedGroupItems);
  }

  void _handleUserJoined(Map<String, dynamic> data) {
    final userId = data['user_id'] as String;
    final onlineUsers = Set<String>.from(state.onlineUsers);
    onlineUsers.add(userId);
    state = state.copyWith(onlineUsers: onlineUsers);
  }

  void _handleUserLeft(Map<String, dynamic> data) {
    final userId = data['user_id'] as String;
    final onlineUsers = Set<String>.from(state.onlineUsers);
    onlineUsers.remove(userId);
    state = state.copyWith(onlineUsers: onlineUsers);
  }

  void _handleError(Map<String, dynamic> data) {
    final error = data['message'] as String? ?? 'Unknown error';
    state = state.copyWith(error: error);
  }

  Future<void> joinGroup(String groupId) async {
    try {
      await WebSocketService.instance.joinGroup(groupId);
    } catch (e) {
      state = state.copyWith(error: 'Failed to join group: $e');
    }
  }

  Future<void> leaveGroup(String groupId) async {
    try {
      await WebSocketService.instance.leaveGroup(groupId);
    } catch (e) {
      state = state.copyWith(error: 'Failed to leave group: $e');
    }
  }

  void clearError() {
    state = state.copyWith(error: null);
  }

  @override
  void dispose() {
    _messageSubscription?.cancel();
    _connectionSubscription?.cancel();
    super.dispose();
  }
}
