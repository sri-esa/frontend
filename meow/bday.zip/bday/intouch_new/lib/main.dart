
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:go_router/go_router.dart';

import 'features/auth/presentation/pages/onboarding_page.dart';
import 'features/home/presentation/pages/home_page.dart';
import 'features/capture/presentation/pages/capture_page.dart';
import 'features/home/presentation/pages/birthday_celebration_page.dart';
import 'features/auth/presentation/providers/auth_provider.dart';
import 'services/firebase_service.dart';
import 'services/api_service.dart';
import 'services/websocket_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Firebase
  await Firebase.initializeApp();
  
  // Initialize services
  await ApiService.instance.initialize();
  await WebSocketService.instance.initialize();
  
  runApp(const ProviderScope(child: InTouchApp()));
}

class InTouchApp extends ConsumerWidget {
  const InTouchApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authProvider);
    final _router = GoRouter(
      initialLocation: '/onboarding',
      routes: [
        GoRoute(
          path: '/onboarding',
          builder: (context, state) => const OnboardingPage(),
        ),
        GoRoute(
          path: '/home',
          builder: (context, state) => const HomePage(),
        ),
        GoRoute(
          path: '/capture',
          builder: (context, state) => const CapturePage(),
        ),
        GoRoute(
          path: '/birthday',
          builder: (context, state) {
            final String name = state.uri.queryParameters['name'] ?? 'User';
            final int age = int.tryParse(state.uri.queryParameters['age'] ?? '18') ?? 18;
            return BirthdayCelebrationPage(name: name, age: age);
          },
        ),
      ],
      redirect: (context, state) {
        // Add authentication logic here if needed
        return null;
      },
    );

    FirebaseService.instance.initialize(_router);

    return MaterialApp.router(
      title: 'InTouch',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
        cardTheme: CardThemeData(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      routerConfig: _router,
    );
  }
}
